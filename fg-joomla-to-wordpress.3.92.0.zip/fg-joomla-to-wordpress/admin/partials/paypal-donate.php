		<p><?php printf(__('If you found this plugin useful and it saved you many hours or days, please rate it on %s.', 'fg-joomla-to-wordpress'), '<a href="https://wordpress.org/support/plugin/fg-joomla-to-wordpress/reviews/#new-post" target="_blank">WordPress.org</a>'); ?> <?php _e('You can also make a donation using the button below.', 'fg-joomla-to-wordpress'); ?></p>
		
		<div id="fgj2wp_paypal_donate" class="center">
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="9VTD6AB2KKGHN">
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/fr_FR/i/scr/pixel.gif" width="1" height="1">
			</form>
		</div>
