<?php
/**
 * Lawyer Lite Theme Customizer
 *
 * @package lawyer-lite
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function lawyer_lite_customize_register( $wp_customize ) {	

	//add home page setting pannel
	$wp_customize->add_panel( 'lawyer_lite_panel_id', array(
	    'priority' => 10,
	    'capability' => 'edit_theme_options',
	    'theme_supports' => '',
	    'title' => __( 'Theme Settings', 'lawyer-lite' ),
	    'description' => __( 'Description of what this panel does.', 'lawyer-lite' ),
	) );

	//Layouts
	$wp_customize->add_section( 'lawyer_lite_left_right', array(
    	'title'      => __( 'Layout Settings', 'lawyer-lite' ),
		'priority'   => 30,
		'panel' => 'lawyer_lite_panel_id'
	) );

	// Add Settings and Controls for Layout
	$wp_customize->add_setting('lawyer_lite_layout_options',array(
	        'default' => __('Right Sidebar','lawyer-lite'),
	        'sanitize_callback' => 'lawyer_lite_sanitize_choices'	        
	)  );
	$wp_customize->add_control('lawyer_lite_layout_options',
	    array(
	        'type' => 'radio',
	        'label' => __('Change Layouts','lawyer-lite'),
	        'section' => 'lawyer_lite_left_right',
	        'choices' => array(
	            'Left Sidebar' => __('Left Sidebar','lawyer-lite'),
	            'Right Sidebar' => __('Right Sidebar','lawyer-lite'),
	            'One Column' => __('One Column','lawyer-lite'),
	            'Three Columns' => __('Three Columns','lawyer-lite'),
	            'Four Columns' => __('Four Columns','lawyer-lite'),
	            'Grid Layout' => __('Grid Layout','lawyer-lite')
	        ),
	) );

	//Top Bar
	$wp_customize->add_section('lawyer_lite_topbar_header',array(
		'title'	=> __('Top Bar Section','lawyer-lite'),
		'description'	=> __('Add Top Bar Content here','lawyer-lite'),
		'priority'	=> null,
		'panel' => 'lawyer_lite_panel_id',
	) );

	$wp_customize->add_setting('lawyer_lite_youtube_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('lawyer_lite_youtube_url',array(
		'label'	=> __('Add Youtube link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_youtube_url',
		'type'		=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_facebook_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );
	$wp_customize->add_control('lawyer_lite_facebook_url',array(
		'label'	=> __('Add Facebook link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_facebook_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_twitter_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('lawyer_lite_twitter_url',array(
		'label'	=> __('Add Twitter link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_twitter_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_linkdin_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('lawyer_lite_linkdin_url',array(
		'label'	=> __('Add Linkdin link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_linkdin_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_google_plus_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('lawyer_lite_google_plus_url',array(
		'label'	=> __('Add Google Plus link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_google_plus_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_pint_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('lawyer_lite_pint_url',array(
		'label'	=> __('Add Pintrest link','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_pint_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('lawyer_lite_mail',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('lawyer_lite_mail',array(
		'label'	=> __('Email Text','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_email',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('lawyer_lite_email',array(
		'label'	=> __('Add Email','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_email',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_call',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('lawyer_lite_call',array(
		'label'	=> __('Phone Text','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'type'		=> 'text'
	));


	$wp_customize->add_setting('lawyer_lite_call1',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('lawyer_lite_call1',array(
		'label'	=> __('Add Phone Number','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_call',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_location',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('lawyer_lite_location',array(
		'label'	=> __('Location','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_location1',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('lawyer_lite_location1',array(
		'label'	=> __('Add address','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_time',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_time',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('lawyer_lite_time',array(
		'label'	=> __('Timing','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('lawyer_lite_time1',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('lawyer_lite_time1',array(
		'label'	=> __('Add Time','lawyer-lite'),
		'section'	=> 'lawyer_lite_topbar_header',
		'setting'	=> 'lawyer_lite_time',
		'type'		=> 'text'
	));

	//Slider
	$wp_customize->add_section( 'lawyer_lite_slidersettings' , array(
    	'title'      => __( 'Slider Settings', 'lawyer-lite' ),
		'priority'   => null,
		'panel' => 'lawyer_lite_panel_id'
	) );

	for ( $count = 1; $count <= 4; $count++ ) {

		// Add color scheme setting and control.
		$wp_customize->add_setting( 'lawyer_lite_slider_page' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );

		$wp_customize->add_control( 'lawyer_lite_slider_page' . $count, array(
			'label'    => __( 'Select Slide Image Page', 'lawyer-lite' ),
			'section'  => 'lawyer_lite_slidersettings',
			'type'     => 'dropdown-pages'
		) );
	}
	
	//About
	$wp_customize->add_section('lawyer_lite_about',array(
		'title'	=> __('About Section','lawyer-lite'),
		'description'	=> __('Add About sections below.','lawyer-lite'),
		'panel' => 'lawyer_lite_panel_id',
	));

	$post_list = get_posts();
	$i = 0;
	foreach($post_list as $post){
		$posts[$post->post_title] = $post->post_title;
	}

	$wp_customize->add_setting('lawyer_lite_about_setting',array(
		'sanitize_callback' => 'lawyer_lite_sanitize_choices',
	));
	$wp_customize->add_control('lawyer_lite_about_setting',array(
		'type'    => 'select',
		'choices' => $posts,
		'label' => __('Select post','lawyer-lite'),
		'section' => 'lawyer_lite_about',
	));

	//footer
	$wp_customize->add_section('lawyer_lite_footer_section',array(
		'title'	=> __('Footer Text','lawyer-lite'),
		'description'	=> __('Add some text for footer like copyright etc.','lawyer-lite'),
		'priority'	=> null,
		'panel' => 'lawyer_lite_panel_id',
	));
	
	$wp_customize->add_setting('lawyer_lite_footer_copy',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field',
	));	
	$wp_customize->add_control('lawyer_lite_footer_copy',array(
		'label'	=> __('Copyright Text','lawyer-lite'),
		'section'	=> 'lawyer_lite_footer_section',
		'type'		=> 'text'
	));
}
add_action( 'customize_register', 'lawyer_lite_customize_register' );	


/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class Lawyer_Lite_Customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	 */
	public function sections( $manager ) {

		// Load custom sections.
		load_template( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'Lawyer_Lite_Customize_Section_Pro' );

		// Register sections.
		$manager->add_section(
			new Lawyer_Lite_Customize_Section_Pro(
				$manager,
				'example_1',
				array(
					'priority'   => 9,
					'title'    => esc_html__( 'Lawyer Pro Theme', 'lawyer-lite' ),
					'pro_text' => esc_html__( 'Go Pro',         'lawyer-lite' ),
					'pro_url'  => esc_url('https://www.themeshopy.com/themes/premium-lawyer-wordpress-theme/'),
				)
			)
		);
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'lawyer-lite-customize-controls', trailingslashit( get_template_directory_uri() ) . '/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'lawyer-lite-customize-controls', trailingslashit( get_template_directory_uri() ) . '/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
Lawyer_Lite_Customize::get_instance();