<?php
/**
 * Template Name: Custom home
 */

get_header(); ?>

<section id="slider">  
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel"> 
      <?php $pages = array();
        for ( $count = 0; $count <= 3; $count++ ) {
          $mod = intval( get_theme_mod( 'lawyer_lite_slider_page' . $count ));
          if ( 'page-none-selected' != $mod ) {
            $pages[] = $mod;
          }
        }
        if( !empty($pages) ) :
          $args = array(
            'post_type' => 'page',
            'post__in' => $pages,
            'orderby' => 'post__in'
          );
          $query = new WP_Query( $args );
          if ( $query->have_posts() ) :
            $count = 3;
      ?>     

      <div class="carousel-inner" role="listbox">
        <?php  while ( $query->have_posts() ) : $query->the_post(); ?>
          <div <?php if($count == 3){echo 'class="carousel-item active"';} else{ echo 'class="carousel-item"';}?>>
            <img src="<?php the_post_thumbnail_url('full'); ?>"/>
            <div class="carousel-caption d-none d-md-block">
              <div class="inner_carousel">
                <h2><?php the_title(); ?></h2>
                <div class="horizontal">
                  <hr>
                </div>
                <div class="consultant">
                  <a class="free-consultant" href="#">FREE CONSULTATIONS <i class="fas fa-arrow-right"></i></a>
                </div>                
              </div>
            </div>
          </div>
        <?php $count++; endwhile; 
        wp_reset_postdata();?>
      </div>
      <?php else : ?>
          <div class="no-postfound"></div>
        <?php endif;
      endif;?>    
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"><?php esc_html_e('Previous','lawyer-lite'); ?></span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"><?php esc_html_e('Next','lawyer-lite'); ?></span>
      </a>
    </div>    
    <div class="clearfix"></div>
</section>

<section class="about-section">
    <div class="container">
      <?php
          $args = array( 'name' => get_theme_mod('lawyer_lite_about_setting',''));
          $query = new WP_Query( $args );
          if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post(); ?>
            <div class="row">
              <div class="col-md-6 col-sm-6 content-sec">
                <h3><?php the_title(); ?></h3>
                <p><?php the_excerpt(); ?></p> 
                <hr>            
                <div class ="about-btn">
                  <a href="<?php echo esc_url( the_permalink() ); ?>"><span><?php echo esc_html(get_theme_mod('lawyer_lite_about_name',__('Discover More','lawyer-lite'))); ?><i class="fas fa-arrow-right"></i></span></a>
                </div>                  
              </div>
              <div class="col-md-6 col-sm-6 abt-image">
                <img src="<?php the_post_thumbnail_url('full'); ?>"/>                  
              </div>  
            </div>          
        <?php endwhile; 
        wp_reset_postdata();?>
        <?php else : ?>
          <div class="no-postfound"></div>
        <?php
      endif; ?>
    </div>
</section>

<?php get_footer(); ?>