/*-----------------------------------------------------------------------------------*/
/* Lawyer Lite Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Lawyer Lite
Theme URI       :   https://www.themeshopy.com/themes/free-lawyer-wordpress-theme/
Version         :   0.2
Tested up to    :   WP 4.9.6
Author          :   Themeshopy
Author URI      :   https://www.themeshopy.com/
license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       	:   support@themeshopy.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Lawyer Lite WordPress Theme, Copyright 2018 Themeshopy
Lawyer Lite is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Lawyer Lite WordPress Theme, Copyright 2018 Themeshopy
Lawyer Lite is distributed under the terms of the GNU GPL

Lawyer Lite WordPress Theme is derived from Twenty Sixteen WordPress Theme, Copyright 2014-2015 WordPress.org
Twenty Sixteen is distributed under the terms of the GNU GPL

Theme is Built using the following resource bundles.

1 - PT Sans font - https://www.google.com/fonts/specimen/Open+Sans
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html

2 - bootstrap.js
		Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  		Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

3 - bootstrap.css
        Code and documentation copyright 2011-2016 Twitter, Inc. Code released under the MIT license. Docs released under Creative Commons.

4 - The Font Awesome font is licensed under the SIL OFL 1.1:
	http://scripts.sil.org/OFL
	Font Awesome CSS, LESS, and Sass files are licensed under the MIT License:
	https://opensource.org/licenses/mit-license.html

5 - Customizer Licence
    All code, unless otherwise noted, is licensed under the GNU GPL, version 2 or later.
    2016 © Justin Tadlock.

6 - Images used from pixabay.

	Copyright 12019 
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/ohio-statehouse-capitol-columbus-1937448/
	
	Copyright espartgraphic
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/office-attorney-reading-read-laws-2820890/

7 - SmoothScroll
	Sources: http://www.smoothscroll.net/
	License: Licensed under the terms of the MIT license.
		
All the icons taken from genericons licensed under GPL License v2.0.
http://genericons.com/ 

/*-----------------------------------------------------------------------------------*/
/* Steps to Setup Theme */
/*-----------------------------------------------------------------------------------*/

Below are the following step to setup theme static page.
=========================================================
Step 1. Add new page named as "home page" and select the template "Custom Home Page".
Step 2. Go to customizer >> static front page >> check Static page, then select the page which you have added example "home page".

For Layout Settings
======================
Step 1. Go to customizer >> Theme Settings >> Layout Settings >> here you can change the layout of the blog post.

For Topbar Section
======================
Step 1. Go to customizer >> Theme Settings >> Topbar Section >> here you can add your socail links and contact details.

For SLider
==============
Step 1. Add new page, add title, content and featured image and then publish it.
Step 2. Go to customizer >> Theme Settings >> Slider settings >> here you can select the page which you have add for slider.

About Section 
======================
Step 1. Add new category, then add the post and assign that category to the post, add title, content and featured image and publish it.
Step 2. Go to customizer >> Theme Settings >> About Section >> here you can select the post which you have added.

Footer Text 
======================
Step 1. Go to customizer >> Theme Settings >> Footer Text >> here you can add your footer text like copyright etc.

/*-----------------------------------------------------------------------------------*/
/* Changelog */
/*-----------------------------------------------------------------------------------*/

Version 0.1
	i) Initial version Released.

Version 0.2
	i) Error resolved.

Lawyer Lite Free version
==========================================================
Lawyer Lite Free version is compatible with GPL licensed.
For any help you can mail us at support[at]themeshopy.com