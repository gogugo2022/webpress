<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content-ts">
 *
 * @package lawyer-lite
 */

?><!DOCTYPE html>

<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width">
  <link rel="profile" href="<?php echo esc_url( __( 'http://gmpg.org/xfn/11', 'lawyer-lite' ) ); ?>">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  
  <div class="topbar">
    <div class="container">
      <div class="row">
        <div class="logo col-md-3 col-sm-3">
          <?php if( has_custom_logo() ){ lawyer_lite_the_custom_logo();
           }else{ ?>
          <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
          <?php $description = get_bloginfo( 'description', 'display' );
          if ( $description || is_customize_preview() ) : ?> 
            <p class="site-description"><?php echo esc_html($description); ?></p>       
          <?php endif; }?>
        </div>
        <div class="contact col-md-9 col-sm-9">
          <div class="row topbar-section">
            <div class="col-md-3 col-sm-3">
              <div class="row top-data">
                <?php if( get_theme_mod( 'lawyer_lite_email','' ) != '') { ?>
                  <div class="col-md-2 icon">
                    <i class="fas fa-at"></i>
                  </div>
                  <div class="col-md-10">
                    <p><?php echo esc_html( get_theme_mod( 'lawyer_lite_mail','Email Text' ) ); ?></p>
                    <p><?php echo esc_html( get_theme_mod('lawyer_lite_email',__('example@123.com','lawyer-lite') )); ?></p>             
                  </div>
                <?php }?>
              </div>
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="row top-data">
                <?php if( get_theme_mod( 'lawyer_lite_call1','' ) != '') { ?>
                  <div class="col-md-2 icon">
                    <i class="fas fa-phone"></i>
                  </div>
                  <div class="col-md-10">
                    <p><?php echo esc_html( get_theme_mod('lawyer_lite_call','') ); ?></p>
                    <p><?php echo esc_html( get_theme_mod('lawyer_lite_call1',__('520-565-5896','lawyer-lite') )); ?></p>
                  </div>
                <?php }?>
              </div>
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="row top-data">
                <?php if( get_theme_mod( 'lawyer_lite_location1','' ) != '') { ?>
                  <div class="col-md-2 icon">
                    <i class="fas fa-map-marker-alt"></i>
                  </div>
                  <div class="col-md-10">
                    <p><?php echo esc_html( get_theme_mod( 'lawyer_lite_location','' ) ); ?></p>
                    <p><?php echo esc_html( get_theme_mod('lawyer_lite_location1',__('area name,city name','lawyer-lite') )); ?></p>
                  </div>
                <?php }?>
              </div>             
            </div>
            <div class="col-md-3 col-sm-3">
              <div class="row top-data">
                <?php if( get_theme_mod( 'lawyer_lite_time1','' ) != '') { ?>
                  <div class="col-md-2 icon">
                    <i class="fas fa-at"></i>
                  </div>
                  <div class="col-md-10">
                    <p><?php echo esc_html( get_theme_mod( 'lawyer_lite_time','' ) ); ?></p>
                    <p><?php echo esc_html( get_theme_mod('lawyer_lite_time1',__('Mon-Fri 8:00am to 2:00pm','lawyer-lite') )); ?></p> 
                  </div>
                <?php }?>
              </div>               
            </div>
          </div>                   
        </div>      
      </div>
    </div>
  </div>
  <div class="toggle"><a class="toggleMenu" href="#"><?php esc_attr_e('Menu','lawyer-lite'); ?></a></div>
  <div class="container">
    <div id="header">
      <div class="row">
        <div class="col-md-9 col-sm-9">
          <div class="nav">
            <?php wp_nav_menu( array('theme_location'  => 'primary') ); ?>
          </div>
        </div>
        <div class="search-box col-md-1 col-sm-1">
          <span><i class="fas fa-search"></i></span>
        </div>
        <div class="social-media col-md-2 col-sm-2">
          <?php if( get_theme_mod( 'lawyer_lite_facebook_url','' ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'lawyer_lite_facebook_url','' ) ); ?>"><i class="fab fa-facebook-f"></i></a>
          <?php } ?>
          <?php if( get_theme_mod( 'lawyer_lite_twitter_url','' ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'lawyer_lite_twitter_url','' ) ); ?>"><i class="fab fa-twitter"></i></a>
          <?php } ?>
          <?php if( get_theme_mod( 'lawyer_lite_linkdin_url','' ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'lawyer_lite_linkdin_url','' ) ); ?>"><i class="fab fa-linkedin-in"></i></a>
          <?php } ?>
          <?php if( get_theme_mod( 'lawyer_lite_google_plus_url','' ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'lawyer_lite_google_plus_url','' ) ); ?>"><i class="fab fa-google-plus-g"></i></a>
          <?php } ?>
          <?php if( get_theme_mod( 'lawyer_lite_youtube_url','' ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'lawyer_lite_youtube_url','' ) ); ?>"><i class="fab fa-youtube"></i></a>
          <?php } ?> 
        </div>
      </div>
      <div class="serach_outer">
        <div class="closepop"><i class="far fa-window-close"></i></div>
        <div class="serach_inner">
          <?php get_search_form(); ?>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>