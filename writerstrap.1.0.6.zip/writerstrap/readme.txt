------- WriterStrap 1.0.2 -------

-- Basanta Moharana, http://crayonux.com/

-----* Copyright & License *-------
WriterStrap, Copyright 2013 Basanta Moharana - crayonux.com
http://www.gnu.org/licenses/gpl-3.0.html
WriterStrap is distributed under the terms of the GNU GPL

WriterStrap is based on Underscores http://underscores.me/, (C) 2012-2013 Automattic, Inc.

* FontAwesome (http://fontawesome.io) licensed under the SIL OFL 1.1 (http://scripts.sil.org/OFL)
* Bootstrap (http://getbootstrap.com/) licensed under MIT license (https://github.com/twbs/bootstrap/blob/master/LICENSE)
* WP-Bootstrap-NavWalker licensed under the GPLv2 license (http://www.gnu.org/licenses/gpl-2.0.html)
* Options Framework by WP Theming licensed under the GPLv2 license (http://www.gnu.org/licenses/gpl-2.0.html)

-------* ABOUT WriterStrap 1.0.2 *-------

Requires at least:	3.6.0
Tested up to:		3.7.1
Stable tag:			1.0.0

Description: WriterStrap is a flat and minimal design theme powered by TwitterBootstrap 3.0. It has unique designed for SEO optimization with faster page loading. The flat look blog theme having a lot of theme functionality to manage logo fav icon and social media profile etc. web Admin can change any colour theme for its website. This is fully responsive theme, works perfectly with any mobile devices or tablet. By using this any kind of responsive blog can be done. Demo can be look here http://demo.crayonux.com/writerstrap/ Support here http://crayonux.com/questions/

WriterStrap adds all the bootstrap 3.0 feature to the blog. 
More options and features will be add in next release.
