/**
 * Education Xpert Theme Custom Js
*/
jQuery(document).ready( function($){

    /**
     * AboutUs Section Accordion
     */
    $( "#edu-accordion" ).accordion({
        heightStyle: "content"
    });

});