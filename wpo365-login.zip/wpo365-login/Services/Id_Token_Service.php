<?php
    
    namespace Wpo\Services;

    use \Wpo\Services\Authentication_Service;
    use \Wpo\Services\Error_Service;
    use \Wpo\Services\Log_Service;
    use \Wpo\Services\Options_Service;
    use \Wpo\Services\Request_Service;
    
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die( );

    if ( !class_exists( '\Wpo\Services\Id_Token_Service' ) ) {
    
        class Id_Token_Service {

            /**
             * Allow the current timestamp to be specified.
             * Useful for fixing a value within unit testing.
             *
             * Will default to PHP time() value if null.
             */
            public static $timestamp = null;

            /**
             * Constructs the oauth authorize URL that is the end point where the user will be sent for authorization.
             * 
             * @since 4.0
             * 
             * @since 11.0 Dropped support for the v1 endpoint.
             * 
             * @param $login_hint string Login hint that will be added to Open Connect ID link
             * @param $redirect_to string Link where the user will be redirected to
             * 
             * @return string if everthing is configured OK a valid authorization URL
             */
            public static function get_openidconnect_url( $login_hint = null, $redirect_to = null ) {
                Log_Service::write_log( 'DEBUG', '##### -> ' . __METHOD__ );

                $redirect_to = !empty( $redirect_to )
                    ? $redirect_to
                    : ( isset( $_SERVER[ 'HTTP_REFERER' ] ) 
                        ? $_SERVER[ 'HTTP_REFERER' ]
                        : $GLOBALS[ 'WPO_CONFIG' ][ 'url_info' ][ 'wp_site_url' ] );

                /**
                 * @since   16.0    Filters the redirect_to url
                 */
                $redirect_to = apply_filters( 'wpo365/cookie/remove/url', $redirect_to );

                $params = array( 
                    'client_id'     => Options_Service::get_aad_option( 'application_id' ),
                    'response_type' => 'id_token code',
                    'redirect_uri'  => Options_Service::get_aad_option( 'redirect_url' ),
                    'response_mode' => 'form_post',
                    'scope'         => 'openid email profile',
                    'state'         => $redirect_to,
                    'nonce'         => wp_create_nonce( 'oidc' ),
                );
                
                /**
                 * @since 9.4
                 * 
                 * Add ability to configure a domain hint to prevent Microsoft from
                 * signing in users that are already logged in to a different O365 tenant.
                 */
                $domain_hint = Options_Service::get_global_string_var( 'domain_hint' );

                if ( !empty( $domain_hint ) ) {
                    $params[ 'domain_hint' ] = $domain_hint;
                }
                
                if ( !empty( $login_hint ) ) {
                    $params[ 'login_hint' ] = $login_hint;
                }

                if ( true === Options_Service::get_global_boolean_var( 'add_select_account_prompt' ) ) {
                    $params[ 'prompt' ] = 'select_account';
                }
                else if ( true === Options_Service::get_global_boolean_var( 'add_create_account_prompt' ) ) {
                    $params[ 'prompt' ] = 'create';
                } 

                $directory_id = Options_Service::get_aad_option( 'tenant_id' );
                $multi_tenanted = Options_Service::get_global_boolean_var( 'multi_tenanted' );
                
                if ( true === $multi_tenanted ) {
                    $directory_id = 'common';
                }

                $auth_url = 'https://login.microsoftonline.com/' 
                    . $directory_id 
                    . '/oauth2' 
                    . '/v2.0' 
                    . '/authorize?' 
                    . http_build_query( $params, '', '&' );
                
                    Log_Service::write_log( 'DEBUG', __METHOD__ . " -> Open ID Connect URL: $auth_url" );

                return $auth_url;
            }

            /**
             * Processes the ID token and caches it for the current request. If an authorization code is sent
             * along, it will be saved so the it can be used when requesting access tokens for the current
             * user (if integration is configured).
             * 
             * @return  void
             */
            public static function process_openidconnect_token() {
                Log_Service::write_log( 'DEBUG', '##### -> ' . __METHOD__ );

                // Decode the id_token
                $id_token = self::decode_id_token();

                // Handle if token could not be processed
                if ( $id_token === false ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> ID token could not be processed and user will be redirected to default Wordpress login.' );
                    Authentication_Service::goodbye( Error_Service::ID_TOKEN_ERROR );
                    exit();
                }

                // Handle if nonce is invalid 
                if ( ! Options_Service::get_global_boolean_var( 'skip_nonce_verification' ) ) {

                    if ( ! wp_verify_nonce( $id_token->nonce, 'oidc' ) ) {
                        Log_Service::write_log( 'WARN', __METHOD__ . ' -> Could not successfully validate oidc nonce with value ' . $id_token->nonce );
                    }
                }

                // Log id token if configured
                if ( true === Options_Service::get_global_boolean_var( 'debug_log_id_token' ) ) {
                    Log_Service::write_log( 'DEBUG', $id_token );
                }

                $request_service = Request_Service::get_instance();
                $request = $request_service->get_request( $GLOBALS[ 'WPO_CONFIG' ][ 'request_id' ] );

                // Store the Authorization Code in the Request
                if ( isset( $_POST[ 'code' ] ) ) {
                    // Session valid until
                    $authorization_code = new \stdClass();
                    $authorization_code->expiry = time() + 3480;
                    $authorization_code->code = $_POST[ 'code' ];

                    $request->set_item( 'authorization_code', $authorization_code );
                    unset( $_POST[ 'code' ] );
                    
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Found authorization code and stored it temporarily as a request variable' );
                }

                $request->set_item( 'id_token', $id_token );
            }

            /**
             * Unraffles the incoming JWT id_token with the help of Firebase\JWT and the tenant specific public keys available from Microsoft.
             * 
             * @since   1.0
             *
             * @return  array|boolean 
             */
            public static function decode_id_token( $retry = false ) {
                Log_Service::write_log( 'DEBUG', '##### -> ' . __METHOD__ );

                // Get the token and get it's header for a first analysis
                if ( !isset( $_POST[ 'id_token' ] ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> ID token not found in posted data.' );
                    return false;
                }

                $id_token = $_POST[ 'id_token' ];
                $token_arr = explode( '.', $id_token );

                // Token should explored in three segments header, body, signature
                if ( sizeof( $token_arr ) != 3 ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> ID token does not contain the expected 3 segments header, body and signature.' );
                    return false;
                }
                
                // Header
                $headers_enc = $token_arr[0];
                $header = \json_decode( self::base64_url_decode( $headers_enc ) );

                if ( \json_last_error() !== JSON_ERROR_NONE || ! \property_exists( $header, 'kid' ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Failed to retrieve expected ID token header and corresponding kid property.' );
                    return false;
                }

                // Payload (claims)
                $claims_enc = $token_arr[1];
                $claims = \json_decode( self::base64_url_decode( $claims_enc ) );

                // Signature
                $sig_enc = $token_arr[2];
                $sig = self::base64_url_decode( $sig_enc );

                // Try get the public keys
                $key = self::get_key_from_set( $header->kid );

                if ( empty( $key ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Could not retrieve a tenant and application specific JSON Web Key Set and thus the ID token cannot be verified successfully.' );
                    return false;
                }

                // create Crypt_RSA
                $rsa = new \phpseclib\Crypt\RSA();
                
                // load public key with modulus and exponent
                $public = [
                    'n' => new \phpseclib\Math\BigInteger( self::base64_url_decode( $key->n ), 256 ),
                    'e' => new \phpseclib\Math\BigInteger( self::base64_url_decode( $key->e ), 256 ),
                ];

                $rsa->loadKey( $public );
                
                // set hash algorithm
                $rsa->setHash( 'sha256' );
                $rsa->setSignatureMode( \phpseclib\Crypt\RSA::SIGNATURE_PKCS1 );

                // Verify
                try {
                    $verified = $rsa->verify( $headers_enc . '.' . $claims_enc, $sig );
                }
                catch ( Exception $e ) {
                    $verified = false;
                }
                
                if ( ! $verified ) {
                    delete_option( 'wpo365_msft_key' );

                    if ( ! $retry ) {    
                        Log_Service::write_log( 'WARN', __METHOD__ . ' -> Verification of the signature of the ID token failed a first time. Cached tokens have been deleted and a 2nd attempt will be made.' );
                        return self::decode_id_token( true );
                    }
                    
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Verification of the signature of the ID token failed a second time. No more attempts will be made.' );
                    return false;
                }

                // Check nbf, iat and exp
                $timestamp = is_null( static::$timestamp ) ? time() : static::$timestamp;

                $leeway = Options_Service::get_global_numeric_var( 'leeway' );
                $leeway = empty( $leeway ) ? 300 : $leeway;

                // Check if the nbf if it is defined. This is the time that the
                // token can actually be used. If it's not yet that time, abort.
                if ( isset( $claims->nbf ) && $claims->nbf > ( $timestamp + $leeway ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Cannot handle ID token prior to ' . date( \DateTime::ISO8601, $claims->nbf ) . '. Please check the system clock of your WordPress server.' );
                    return false;
                }

                // Check that this token has been created before 'now'. This prevents
                // using tokens that have been created for later use (and haven't
                // correctly used the nbf claim).
                if ( isset( $claims->iat ) && $claims->iat > ( $timestamp + $leeway ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Cannot handle ID token prior to ' . date( \DateTime::ISO8601, $claims->iat ) . '. Please check the system clock of your WordPress server.' );
                    return false;
                }

                // Check if this token has expired.
                if ( isset( $claims->exp ) && ( $timestamp - $leeway ) >= $claims->exp ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Cannot handle expired ID token after ' . date( \DateTime::ISO8601, $claims->exp ) . '. Please check the system clock of your WordPress server.' );
                    return false;
                }

                Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Verification of signature of the ID token was successful' );

                return $claims;
            }

            /**
             * Helper to base64 URL decode.
             * 
             * @param   string  Input to be decoded.
             * 
             * @return  string  Input decoded
             */
            private static function base64_url_decode( $arg ) {
                $res = $arg;
                $res = str_replace( '-', '+', $res );
                $res = str_replace( '_', '/', $res );
                
                switch ( strlen($res) % 4 ) {
                    case 0:
                        break;
                    case 2:
                        $res .= "==";
                        break;
                    case 3:
                        $res .= "=";
                        break;
                    default:
                        break;
                }

                $res = base64_decode($res);
                return $res;
            }

            /**
             * Tries to retrieve the JSON Web Key Set issued for the current tenant and application either from cache or
             * by loading the JWKS from the jwks_uri specified in the open-id configuration for the current tenant.
             * 
             * @since 14.0
             * 
             * @return stdClass JSON Web Key Set to be used to verify a JWT token issued for the current tenant and registered application as a typical PHP stdClass.
             */
            private static function get_key_from_set( $kid ) {
                Log_Service::write_log( 'DEBUG', '##### -> ' . __METHOD__ );

                /**
                 * Try get the key from cache.
                 */

                $cached_key = get_site_option( 'wpo365_msft_key' );

                if ( ! empty( $cached_key ) ) {

                    if ( \is_object( $cached_key ) &&  \property_exists( $cached_key, 'kid' ) && $cached_key->kid == $kid && \property_exists( $cached_key, 'e' ) && \property_exists( $cached_key, 'n' ) ) {
                        Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Found cached JSON Web Key Set to verify the ID token signature' );
                        return $cached_key;
                    }

                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Deleted cached JSON Web Key Set to verify the ID token signature' );
                    delete_option( 'wpo365_msft_key' );
                }

                /**
                 * Get the JSON Web Key Sets
                 */

                $jwks_uri = self::get_json_web_key_sets_uri();

                $curl = curl_init();
                curl_setopt( $curl, CURLOPT_URL, $jwks_uri );
                curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
                
                if ( Options_Service::get_global_boolean_var( 'skip_host_verification' ) ) {
                    curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 ); 
                    curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 ); 
                }

                if ( ! empty( $curl_proxy = Options_Service::get_global_string_var( 'curl_proxy' ) ) ) {
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Using curl proxy ' . $curl_proxy );
                    curl_setopt( $curl, CURLOPT_PROXY, $curl_proxy );
                }

                $result = curl_exec( $curl );

                if ( curl_error( $curl ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Error occured whilst trying to retrieve JSON Web Key Sets: ' . curl_error( $curl ) );
                    curl_close( $curl );
                    return null;
                }
                
                curl_close( $curl );

                $keys = \json_decode( $result );

                if ( \json_last_error() !== JSON_ERROR_NONE ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Error when trying to decode the JSON Web Key Sets  [ ' . \json_last_error_msg() . ' ]' );
                    Log_Service::write_log( 'DEBUG',  $keys );
                    return null;
                }

                if ( \is_object( $keys ) && \property_exists( $keys, 'keys' ) ) {
                    $keys = $keys->keys;
                }

                $keys_arr = \is_array( $keys ) ? $keys : array( $keys );

                foreach ( $keys_arr as $key ) {

                    if ( \property_exists( $key, 'kid' ) && $key->kid == $kid && \property_exists( $key, 'n' ) && \property_exists( $key, 'e' ) ) {
                        update_site_option( 'wpo365_msft_key', $key );
                        return $key;
                    }
                }

                return null;
            }

            /**
             * Get the JSON Web Key Sets URI for the given tenant and app. In case of multi-tenancy enabled the generic keys will be returned.
             * 
             * @since 14.1
             */
            private static function get_json_web_key_sets_uri() {
                Log_Service::write_log( 'DEBUG', '##### -> ' . __METHOD__ );
                
                if ( Options_Service::get_global_boolean_var( 'multi_tenanted' ) ) {
                    $jwks_uri = 'https://login.microsoftonline.com/common/discovery/v2.0/keys';
                    Log_Service::write_log( 'DEBUG', __METHOD__ . " -> Trying to retrieve the Open ID configuration for the designated tenant and application $jwks_uri" );
                    return $jwks_uri;
                }

                /**
                 * Get the JSON Web Key Sets URI (jwks_uri) from the openid configuration.
                 */

                $directory_id = Options_Service::get_aad_option( 'tenant_id' );
                $application_id = Options_Service::get_aad_option( 'application_id' );

                if ( Options_Service::get_global_boolean_var( 'use_b2c' ) &&  \class_exists( '\Wpo\Services\Id_Token_Service_B2c' ) ) {
                    $b2c_domain_name = Options_Service::get_global_string_var( 'b2c_domain_name' );
                    $b2c_policy_name = Options_Service::get_global_string_var( 'b2c_policy_name' );    
                    $open_id_config_url = "https://$b2c_domain_name.b2clogin.com/$directory_id/$b2c_policy_name/v2.0/.well-known/openid-configuration";
                }
                else {
                    $open_id_config_url = "https://login.microsoftonline.com/$directory_id/v2.0/.well-known/openid-configuration?appid=$application_id";
                }

                Log_Service::write_log( 'DEBUG', __METHOD__ . " -> Trying to retrieve the Open ID configuration for the designated tenant and application $open_id_config_url" );
                
                $curl = curl_init();
                curl_setopt( $curl, CURLOPT_URL, $open_id_config_url );
                curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
                
                if ( Options_Service::get_global_boolean_var( 'skip_host_verification' ) ) {
                    curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 ); 
                    curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 ); 
                }

                if ( ! empty( $curl_proxy = Options_Service::get_global_string_var( 'curl_proxy' ) ) ) {
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Using curl proxy ' . $curl_proxy );
                    curl_setopt( $curl, CURLOPT_PROXY, $curl_proxy );
                }

                $result = curl_exec( $curl );

                if ( curl_error( $curl ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Error occured whilst getting JSON Web Key Sets URI: ' . curl_error( $curl ) );
                    curl_close( $curl );
                    return null;
                }
                
                curl_close( $curl );
                $open_id_config = json_decode( $result );

                if ( \json_last_error() !== JSON_ERROR_NONE || ! isset( $open_id_config->jwks_uri ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> jwks_uri property not found [ ' . \json_last_error_msg() . ' ]' );
                    Log_Service::write_log( 'DEBUG', $open_id_config );
                    return null;
                }

                return $open_id_config->jwks_uri;
            }
        }
    }