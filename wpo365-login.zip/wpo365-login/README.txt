=== WordPress + Microsoft Office 365 / Azure AD | LOGIN ===
Contributors: wpo365
Tags: office 365, O365, Microsoft 365, azure active directory, Azure AD, AAD, authentication, single sign-on, sso, SAML, SAML 2.0, OpenID Connect, OIDC, login, oauth, microsoft, microsoft graph, teams, microsoft teams, sharepoint online, sharepoint, spo, onedrive, SCIM, User synchronization, yammer, powerbi, power bi, mail, smtp, phpmailer, wp_mail, email
Requires at least: 4.8.1
Tested up to: 5.8
Stable tag: 16.1
Requires PHP: 5.6.40
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

With WPO365 | LOGIN users can sign in with their corporate or school (Azure AD / Microsoft Office 365) account to access your WordPress website: No username or password required (OIDC or SAML 2.0 based SSO). Plus you can send email using Microsoft Graph instead of SMTP from your WordPress website.

= SINGLE SIGN-ON =

- *OpenID Connect* and *SAML* based single sign-on (SSO) [more](https://www.wpo365.com/sso-for-office-365-azure-ad-user/)

= NEW USERS =

- New users that sign in with Microsoft are automatically registered with your WordPress [more](https://www.wpo365.com/sso-for-office-365-azure-ad-user/)

= INTRANET =

- Restrict access to pages / posts in *intranet* mode [more](https://www.wpo365.com/make-your-wordpress-intranet-private/)

= MICROSOFT TEAMS =

- Support for integration of your WordPress website into a *Microsoft Teams* Tabs and Apps [more](https://docs.wpo365.com/article/70-adding-a-wordpress-tab-to-microsoft-teams-and-use-single-sign-on)

= MAIL =

- *Send emails using Microsoft Graph* instead of SMTP from your WordPress website [more](https://docs.wpo365.com/article/108-sending-wordpress-emails-using-microsoft-graph)

= WORDPRESS MULTISITE =

- Support for *WordPress Multisite* [more](https://www.wpo365.com/support-for-wordpress-multisite-networks/)

= DOCUMENTS =

- Embed a *SharePoint Online* or *OneDrive* Library into any post or page with this useful, usable and beautiful Gutenberg Block [more](https://docs.wpo365.com/article/128-embedded-sharepoint-library-powerful-gutenberg-blocks-for-wordpress)

= MICROSOFT 365 APPS =

- Embed Microsoft *Power BI* content [more](https://www.wpo365.com/power-bi-for-wordpress/)
- *SharePoint Online* Library [more](https://www.wpo365.com/documents/) and Search [more](https://www.wpo365.com/content-by-search/)
- Employee Directory (Microsoft Graph / Azure AD) [more](https://www.wpo365.com/employee-directory/)

= DEVELOPERS =

- Developers can now connect to a RESTful API for Microsoft Graph in their favorite programming language and without the hassle of authentication and authorization [more](https://docs.wpo365.com/article/129-a-restful-proxy-to-microsoft-graph-inside-wordpress)
- *PHP hooks* for developers to build custom Microsoft Graph / Office 365 integrations [more](https://docs.wpo365.com/article/82-developer-hooks)

https://youtu.be/aIdbkmbdDog

== ADD FUNCTIONALITY WITH EXTENSIONS ==

= SINGLE SIGN-ON =

- Secured by Azure Active Directory: Visitors are required to sign in with Azure AD / Microsoft but are not automatically signed in as WordPress users [more](https://docs.wpo365.com/article/36-authentication-scenario)

= AUDIENCES =

- Create virtual groups of users that are dynamically populated - using simple Azure AD group based mapping rules - to *restrict access to WordPress posts and pages* [more](https://docs.wpo365.com/article/139-audiences)

= SYNC =

- On-demand / scheduled *user synchronization* from Azure AD to WordPress [more](https://www.wpo365.com/synchronize-users-between-office-365-and-wordpress/)

= PROFILE+ =

- Update a user's WordPress profile with (first, last, full) *name*, *email* and *UPN* from Azure AD [more](https://www.wpo365.com/downloads/wordpress-office-365-login-plus/)

= AVATAR =

- Replace the default WordPress / BuddyPress *avatar* with a Microsoft 365 profile picture [more](https://www.wpo365.com/downloads/wpo365-avatar/)

= ROLES + ACCESS =

- WordPress roles assignments / access restrictions based on *Azure AD groups* / user attributes [more](https://www.wpo365.com/downloads/wpo365-roles-access/)

= LOGIN+ =

- Support for *Azure AD B2C*, *Azure AD B2B*, *AAD Multi-Tenancy*, *SSO enabled login page*, *Dual Login*, *Private Pages* and (Single) *Sign-out* [more](https://www.wpo365.com/downloads/wordpress-office-365-login-professional/)

= MAIL =

- Send *HTML formatted email* using Microsoft Graph and save messages in *Sent Items* [more](https://www.wpo365.com/downloads/wpo365-mail/)

= GROUPS =

- Deep integration with the *(itthinx) Groups* plugin for group membership and access control [more](https://www.wpo365.com/downloads/wpo365-groups/)

= DOCUMENTS =

- An advanced version of the Gutenberg Block for embedding a *SharePoint Online* / *OneDrive* library into any post or page that also supports access for anonymous users and custom SharePoint (list item) fields [more](https://www.wpo365.com/downloads/wpo365-documents/)

= MICROSOFT 365 APPS =

- Microsoft 365 apps for *Power BI*, *SharePoint Online* (Search + List View), *OneDrive*, Employee Directory / Contacts and *Yammer* [more](https://www.wpo365.com/downloads/wpo365-microsoft-365-apps/)

= SCIM =

- Automatic (SCIM based) *Azure AD User Provisioning* to WordPress [more](https://www.wpo365.com/downloads/wpo365-scim/)

= CONFIGURATION =

- Save multiple configurations.
- Directly edit (the JSON representation of) a configuration.

== Prerequisites ==

- Make sure that you have disabled caching for your Website in case your website is an intranet and access to WP Admin and all pubished pages and posts requires authentication. With caching enabled, the plugin may not work as expected
- We have tested our plugin with Wordpress >= 4.8.1 and PHP >= 5.6.40
- You need to be (Office 365) Tenant Administrator to configure both Azure Active Directory and the plugin
- You may want to consider restricting access to the otherwise publicly available wp-content directory

== Support ==

We will go to great length trying to support you if the plugin doesn't work as expected. Go to our [Support Page](https://www.wpo365.com/how-to-get-support/) to get in touch with us. We haven't been able to test our plugin in all endless possible Wordpress configurations and versions so we are keen to hear from you and happy to learn!

== Feedback ==

We are keen to hear from you so share your feedback with us on [Twitter](https://twitter.com/WPO365) and help us get better!

== Open Source ==

When you’re a developer and interested in the code you should have a look at our repo over at [WordPress](http://plugins.svn.wordpress.org/wpo365-login/).

== Installation ==

Please refer to [these **Getting started** articles](https://docs.wpo365.com/category/21-getting-started) for detailed installation and configuration instructions.

== Frequently Asked Questions ==

== Screenshots ==
1. Microsoft / Azure AD based Single Sign-on
2. Embedded Power BI for WordPress
3. Embedded SharePoint Online Documents for WordPress
4. Embedded SharePoint Online Search for WordPress
5. Employee Directory
6. Support for Azure AD B2B and Azure AD B2C
7. Sending WordPress email using Microsoft Graph
8. Synchronizing users from Azure AD to WordPress
9. Embed WordPress in a Teams Tab or App
10. Assign WordPress roles / Deny access based on Azure AD groups

== Upgrade Notice ==

* Please check the online version of the [release notes for version 11.0](https://www.wpo365.com/release-notes-v11-0/).

== Changelog ==

= v16.1 =
* Fix: Audiences no longer generates a warning for users that not signed in with Microsoft. [ROLES + ACCESS, PREMIUM, INTRANET]

= v16.0 =
* Feature: Audiences: Create virtual groups of users and restrict access to WordPress posts and pages to members of these groups. An Audience is a group of users that is dynamically populated based on rules (or better: one or more of Azure AD group ID's) that define who is a member of that Audience. See the [online documentation](https://docs.wpo365.com/article/139-audiences) for details. [ROLES + ACCESS, PREMIUM, INTRANET]
* Feature: Secured by Azure Active Directory: Two new authentication scenarios have been added that require visitors to sign in with Azure AD / Microsoft without attempting to sign them in as WordPress users. See the updated [online documentation](https://docs.wpo365.com/article/140-auth-only-scenarios) for details. [LOGIN+, PREMIUM, INTRANET]
* Change: Your users can now benefit from true Single Sign-on support for Microsoft Teams Tabs and Apps that embed a WordPress website (without additional popups if the user is from the own organization). See the updated [online documentation](https://docs.wpo365.com/article/70-adding-a-wordpress-tab-to-microsoft-teams-and-use-single-sign-on) for instructions how to update the App registration in Azure AD. [ALL]
* Change: The loading bars (when redirecting to Microsoft) have been replaced with a circular spinner. Administrators can choose to re-activate the old loading bars when they navigate to WP Admin > WPO365 > ... > Miscellaneous. [ALL]
* Improvement: Administrators can now choose to use WP-Config(.php) for AAD secrets when they navigate to WP Admin > WPO365 > Single Sign-on, click to show the advanced configuration options and check the corresponding option. See [online documentation](https://docs.wpo365.com/article/137-use-wp-config-for-aad-secrets) for details.[LOGIN+, PREMIUM, INTRANET]
* Improvement: Administrators can now define the length of WordPress passwords created by the plugin when they go to WP Admin > WPO365 > ... > Miscellaneous. See [online documentation](https://docs.wpo365.com/article/138-password-length) for details. [ALL]
* Fix: When switching between configurations the plugin now resets the settings before switching, preventing newer settings to be added automatically to an older configuration. [PREMIUM, INTRANET]
* Fix: The page on which a Documents apps(s) has been embedded will no longer jump to the top of the app. [ALL]
* Fix: Uncaught error: Class DateTime not found [ALL].
* Fix: The plugin will now recognize correctly - when WordPress Multisite has been enabled - the subsite's ID when the Azure AD Redirect URI points to WP-Admin. [ALL]
* Fix: The plugin will now delete an itthinx Groups assignment for a user if that user has been removed from the mapped Azure AD group. [GROUPS, INTRANET]
* Fix: Anonymous users no longer are asked to sign in when they attempt to download a document from SharePoint. [DOCUMENTS, INTRANET]
* Fix: Version bump for all plugins, extensions and bundles. [ALL]

= v15.4 =
* Fix: This version patches two XSS (cross-site) security flaws (thanks to  Gary O’Leary-Steele from [AppCheck](https://appcheck-ng.com/) and Sailesh Parmar) [ALL].
* Improvement: If the user clicks the Sign in with Microsoft button on the (default) login form in Teams the user will now be redirected to the home page (or to the page the user intended to navigate to) [ALL].
* Fix: Password reset is not blocked for users that are administrators for the WordPress site [ALL].

= v15.3 =
* Fix: Overall stability of user synchronization when starting, re-starting and stopping manually [SYNC, INTRANET].

= v15.2 =
* Change: Administrators can now choose to grant application type permissions to the existing App registration and creating a 2nd App registration is (still supported but) no longer necessary or recommended [ALL].
* Fix: The domain hint variable was undefined for one of the plugin's self-tests.
* Fix: The avatar self-test will no longer fail if the request is successful but no image was found.

= v15.1 =
* Improvement: Administrators can configure a reply-to address when sending WordPress mail using Microsoft Graph [MAIL, SYNC, INTRANET].
* Fix: A cross-site scripting issue with the redirect JavaScript has been resolved [ALL].
* Fix: The User synchronization processor will now skip Azure AD (directory) objects that are not users (e.g. but groups instead) [SYNC, INTRANET].
* Fix: The plugin will now determine correctly whether or not a request is for the WordPress REST API or not [ALL].
* Fix: Instant help pages will now only be loaded on-demand [ALL].

= v15.0 =
* Feature: User synchronization V2 (see [this article](https://docs.wpo365.com/article/57-synchronize-users-from-azure-ad-to-wordpress) for details) [SYNC, INTRANET].
* Change: Emails sent will respect the Content-Type header and if no header is defined emails will be sent as text by default (only applies to emails sent using Microsoft Graph) [ALL].
* Improvement: Administrators can now configure the plugin to update attributes of users that are administrators (incl. dynamically assigned roles, see [this article](https://docs.wpo365.com/article/132-update-administrator-accounts) for details) [ROLES + ACCESS, SYNC, INTRANET]
* Improvement: When the author of a post is deleted through Azure AD User provisioning (SCIM) that post can now be re-assigned to another WordPress user [SCIM, INTRANET].
* Improvement: When a user's manager is already provisioned to WordPress through Azure AD User provisioning (SCIM) the manager's details will be collected if a custom field mapping for the 'manager' field has been configured [SCIM, INTRANET].
* Improvement: An administrators of a WordPress Multisite can now configure Azure AD group based mappings to dynamically assign the Super Administrator role (see [this article](https://docs.wpo365.com/article/133-azure-ad-group-to-super-admin-wpmu-mappings) for details) [ROLES + ACCESS, SYNC, INTRANET].
* Improvement: An administrator can now configure an external URL as custom error page where a user will be sent when authentication fails [LOGIN+, SYNC, INTRANET].
* Improvement: Support for Report control filters when embedding Power BI reports in WordPress [M365 APPS, INTRANET]
* Improvement: A new configuration will prevent the Content by Search app to scroll the page to the top of the search results [M365 APPS, INTRANET].
* Improvement: Additional translations for the Employee Directory app [ALL].
* Improvement: An administrator can configure the plugin so that a deactivated user can be re-activated when he / she successfully signs in with Microsoft (see [this article](https://docs.wpo365.com/article/134-enable-user-re-activation) for details) [SCIM, PREMIUM, INTRANET].
* Improvement: The Plugin self-test results can now be downloaded as a JSON file [ALL].
* Improvement: Additional tests have been added to the Plugin self-test to improve the configuration of user synchonization [SYNC, INTRANET].
* Improvement: Some issues identified by the Plugin self-test can now be fixed by a simple button click [ALL].
* Improvement: The Plugin's Debug Log can now be downloaded as a JSON file [ALL].
* Improvement: More custom hooks were added for when a user is created, authenticated and added to a blog (see [this article](https://docs.wpo365.com/article/82-developer-hooks) for details) [ALL].
* Fix: A de-activated users can now be re-activated when that user is added again by Azure AD User provisioning SCIM [SCIM, INTRANET].
* Fix: When a user is de-activated by Azure AD User provisioning (SCIM) all roles will be removed [SCIM, INTRANET].
* Fix: A deactivated user can no longer sign in with WordPress credentials [SCIM, SYNC, INTRANET].
* Fix: Administrators can fix an issue when sending emails using Microsoft Graph from localhost by checking the corresponding option on the plugin's Mail configuration page [ALL].

= v14.1 =
* Fix: Added URL decoding for base64 encoded ID tokens that contain special characters [ALL].
* Fix: The plugin will no longer try to get tenant specific JSON Web Key sets when verifiying the ID token's signature if multi-tenancy is enabled but instead download the common keys from https://login.microsoftonline.com/common/discovery/v2.0/keys [ALL].

= v14.0 =
* Feature: Full support for Azure AD B2C incl. the configuration of a custom domain and an Azure AD B2C policy to redirect users to corresponding custom Azure AD B2C endpoints to login and obtain ID and access tokens [LOGIN+, SYNC, INTRANET].
* Change: Now the plugin uses the phpseclib (see https://phpseclib.com/) to verify the signature of the ID token received from Microsoft. The previously used Firebase/JWT library is still included for fallback purposes and administrators can navigate to WP Admin > WPO365 > ... > Miscellaneous and enable the use of the older ID token parser in case of any issues.
* Fix: All WP AJAX endpoints have been renamed and include a namespace to avoid conflicts with other plugins after some users reported that they were not able to save the configuration [ALL].
* Fix: Improved HTML encoding for the Employee Directory app's query expression [ALL].
* Fix: When retrieving data from Microsoft Graph the plugin will now (in most cases) try to do so by a user's Object ID and only use the user principal name (UPN) for fallback [ALL].
* Fix: When the Documents Gutenberg Block tests its configuration it now does so independ of the configured Microsoft Graph Version (recommended version - however - remains Beta) [ALL].

= v13.0 =
* Feature: A brand new Gutenberg Block to display a SharePoint or OneDrive Document Library (or recently used documents) with an advanced column / field configuration editor and the exciting new option to grant anonymous users (that didn't sign in with Microsoft) access to those files (see [online documentation](https://docs.wpo365.com/article/128-embedded-sharepoint-library-powerful-gutenberg-blocks-for-wordpress) for details) [ALL, (premium features: DOCUMENTS, INTRANET)].
* Feature: A new RESTful API that transparently gives developers access to selected Microsoft Graph API endpoints so they can build client-side Microsoft 365 integrated apps for WordPress in their favorite programming language and without the hassle and complexity of implementing authentication and authorization because the WPO365 | LOGIN plugin takes care of all that (see [online documentation](https://docs.wpo365.com/article/129-a-restful-proxy-to-microsoft-graph-inside-wordpress) for details) [LOGIN].
* Improvement: The Contacts (Employee Directory) App now "remembers" its search results when an employee is selected from the result list [APPS, INTRANET].
* Improvement: The Content by Search App now checks if the default search parameter "s" is present in the current page's URL, allowing for a deep integration of the app on a WordPress search result page [APPS, INTRANET].
* Improvement: The plugin now detects a Microsoft Graph $count query and automatically adds the ConsistencyLevel = True header and thus allowing for advanced queries with $filter that use endsWith and $search. For example you can write a User sync query that includes all users from a specific organization now as follows: myorganization/users?$count=true&$filter=endsWith(userPrincipalName,%27@example.com%27)&$top=10 [LOGIN].
* Fix: When a user attribute in Azure AD has been deleted the plugin will delete the corresponding custom user field in WordPress [CUSTOM USER FIELDS, SYNC, INTRANET].
* Fix: The Content by Search App no longer will fail if it's fetched data before the page has finished loading [APPS, INTRANET].
* Fix: When sending an email from WordPress using Microsoft Graph fails, only the error (instead of the message as a whole) will be logged [LOGIN].
* Fix: The plugin's configuration pages (wizard) is now loaded using WordPress' own script enqueueing mechanism [LOGIN].
* Fix: Version bump for all plugins, extensions and bundles [ALL].

= v12.14 =
* Fix: The Plugin self-test would encounter an error when the administrator configured SAML 2.0 [ALL].
* Fix: When using the SAML 2.0 the plugin will now also read the user's AAD object ID (which is needed for integration scenarios such as retrieval of a user's profile, Azure AD group memberships etc.) [ALL].

= v12.12 =
* Feature: Administrators can save multiple WPO365 configurations and select one of the saved configurations as the current one [SYNC, INTRANET]
* Feature: Administrators can edit and save a configuration's JSON representation directly in an editor [SYNC, INTRANET]
* Improvement: The Plugin self-test has been greatly improved and now tests various scenarios in an attempt to provide better support and guidance when configuring the plugin [ALL].
* Fix: The option to de-activate instead of delete users when synchronizing was working in the opposite way and this has been corrected [SYNC, INTRANET].
* Fix: An administrator can now update passwords for users that sign in with Microsoft even if he / she configured the plugin to block password updates [ALL].
* Fix: When determining whether a user has properties that match with (one of the) the tenant's domain(s) the plugin now tries to do so in a case-insensitive way [ALL].
* Fix: When scheduling daily user synchronization the first event will be scheduled for this week and no longer jump the first week [SYNC].
* Fix: When scheduling daily user synchronization the first event will be scheduled for this week and no longer jump the first week [SYNC].

= v12.11 = 
* Improvement: Tested up to 5.7.
* Fix: The plugin will now save a user's Azure AD object ID and use it when retrieving a user's profile image, which otherwise fails for guest users when using the Azure AD user principal name [LOGIN, AVATAR, SYNC, INTRANET].
* Fix: The Microsoft 365 *Documents* App ability to restrict content to a specific folder (and its sub folders) stopped working and the error causing it has been fixed [APPS, INTRANET].

= v12.10 =
* Fix: The Microsoft Teams integration now will honour the login hint (if you add **?login_hint={loginHint}** to your WordPress URL that for your Tab or App) [ALL].
* Fix: The plugin now tries to recognize SSL and will update the WordPress (Site) Address (URL) whenever it retrieves the WordPress home option from WordPress [ALL].

= v12.9 =
* Improvement: Administrators who configured SAML 2.0 based Single Sign-On can now request that users re-authenticate by including a forceAuthn=true flag in the SAML request [LOGIN+, SYNC, INTRANET].
* Fix: The error reason for failed SAML sign-in requests is now included in the error message [ALL].
* Fix: The full email message (JSON) is now logged in case of an error when sending WordPress emails using Microsoft Graph [ALL].
* Fix: The plugin no longer tries to create a folder for downloaded Microsoft 365 profile images when it already exists [AVATAR, SYNC, INTRANET].

= v12.8 =
* Fix: When embedded in Microsoft Teams (Web App) as Tab or App or as iframe, further improvements now ensure that the login dialog will popup [ALL].

= v12.7 =
* Fix: The plugin no longer requires an authorization code / refresh code to retrieve an access token when configuring a Power BI embed for your customers (also known as "Application owns data") [LOGIN, M365 APPS, INTRANET].

= v12.6 =
* Fix: Saving the user information retrieved from the ID token / SAML response resolves an issue for multi-tenanted apps to request an access token from another tenant than the "home" tenant.

= v12.5 =
* Feature: Administrators can now enable Single Sign-On for the (default / custom) login page (see [online documentation](https://docs.wpo365.com/article/120-enable-sso-for-the-default-custom-login-page) for details) [ROLES + ACCESS, LOGIN+, SYNC, INTRANET].
* Feature [preview]: Administrators can now enable Single Sign-On for pages / posts that have limited (private) visibility (see [online documentation](https://docs.wpo365.com/article/119-enable-sso-for-a-privately-published-post-page) for details) [ROLES + ACCESS, LOGIN+, SYNC, INTRANET].
* Improvement: Administrators can now navigate to WP Admin > WPO365 > ... > Translations and update the caption for the "Sign in with Microsoft" button as well as several other error message.
* Improvement: Administrators of WordPress Multisite networks can now prevent the plugin from adding users to a subsite (see [online documentation](https://docs.wpo365.com/article/123-do-not-add-user-to-wpmu-subsite) for details) [LOGIN+, SYNC, INTRANET].
* Improvement: Administrators can now disable the WPO365 session expiration when they navigate to WP Admin > WPO365 > Single Sign-On and reconfigure the Session Duration option and set it to 0 (see [online documentation](https://docs.wpo365.com/article/46-session-duration) for details) [LOGIN].
* Improvement: The WPO365 configuration pages have been optimized and streamlined with the new recently added [extensions](https://www.wpo365.com/compare-all-wpo365-extensions/) [LOGIN].

= v12.4 =
* Fix: Administrators can now choose a default avatar when they navigate to WP Admin > Settings > Discussion and scroll to the Default Avatar section [AVATAR, SYNC, INTRANET].
* Fix: User synchronization now will recognize Azure AD Guests by their UPN instead of their preferred user name and thus no longer ignore Azure AD Guests when processing batches of users retrieved from Microsoft Graph [SYNC, INTRANET].
* Fix: The /me context will only be used if the plugin believes it can acquire an access token on behalf of that user [ALL extensions / bundles].

= v12.3 =
* Fix: Active extension (SYNC and / or INTRANET) was not correctly detected, causing (manual) user synchronization not to reload as expected but instead showing a white screen.

= v12.2 =
* Fix: License management page for WordPress Multisite now showing as expected (network admins only).

= v12.1 =
* Fix: Item ID search algorithm not finding item to activate the license for and failing without a notification showing.

= v12.0 =
* (Breaking) Change: Licenses are now administered on a separate configuration page. The new License (administration) page can be accessed via WP Admin > WPO365 > Licenses. Existing licenses must be re-entered for the automatic update function to work as expected.
* Change: Introduction of new Extensions for [MAIL](https://www.wpo365.com/downloads/wpo365-mail/), [AVATAR](https://www.wpo365.com/downloads/wpo365-avatar/), [CUSTOM USER FIELDS](https://www.wpo365.com/downloads/wpo365-custom-user-fields/), [GROUPS](https://www.wpo365.com/downloads/wpo365-groups/), [APPS](https://www.wpo365.com/downloads/wpo365-microsoft-365-apps/), [ROLES + ACCESS](https://www.wpo365.com/downloads/wpo365-roles-access/) and [SCIM](https://www.wpo365.com/downloads/wpo365-scim/).
* Improvement: In an attempt to unclutter the WordPress Admin Dashboard, the plugin will no longer show the last (three) error(s). Instead a notification that errors have been encountered will be shown with a link to the main WPO365 configuration page where the full error message(s) are shown.

= v11.20 =
* Improvement: Users who have configured SAML 2.0 can create a custom button to include a domain hint that translates to an additional whr parameter. See the [updated documentation](https://docs.wpo365.com/article/99-add-sign-in-with-microsoft-button-anywhere-shortcode) for recommended configuration.
* Improvement: The request for a plugin-review now only shows on the WPO365 configuration pages and can be turned off permanently.
* Fix: Avatar filter priority lowered to 99999 to have precendence over other plugins e.g. Ultimate Member.

= v11.19 =
* Fix: User synchronization no longer deactivates / deletes users that cannot be linked to an existing Microsoft 365 / Azure AD account (administrators must make sure the update the Custom domains list on the plugin's User registration page).
* Fix: (Array to string conversion) Error when ever an email could not be sent successfully through Microsoft Graph.

= v11.18 =
* (Breaking) Change: Improved support for WordPress Multisite with mapped domains and subsite specific WPO365 configuration. See updated [online documentation](https://docs.wpo365.com/article/29-support-for-wordpress-multisite-wpmu) for recommended configuration scenarios of WordPress Multisite installations.
* Feature: Administrators (of the LOGIN+, SYNC and INTRANET extensions) can navigate to WP Admin > WPO365 > User registration and configure the plugin to create shorter WordPress names e.g. john.doe instead of john.doe@your-tenant.onmicrosoft.com. See [online documentation](https://docs.wpo365.com/article/117-use-short-usernames) for details.
* Improvement: Prevention of users getting stuck in infinite loops through smart detection. See updated [online documentation](https://docs.wpo365.com/article/5-infinite-loop) for additional considerations.
* Improvement: Administrators can now navigate to WP Admin > WPO365 > ... > Miscellaneous and delete the current WPO365 configuration.
* Improvement: When administrators (of the LOGIN+, SYNC and INTRANET extensions) have configured the 'Post sign-out URL' option, the plugin will now also redirect users that did not sign in with Microsoft.

= v11.17 =
* Fix: When using the optimized internet authentication mode (preventing the plugin from interfering with requests for pages and posts) the "Sign in with Microsoft" button now redirects the user correctly to the WordPress Administration instead of to the homepage.

= v11.16 =
* Fix: After a recent change the global constant WPO_AUTH_SCENARIO had been erroneously renamed to WPO_AUTH_MODE.

= v11.15 =
* (Breaking) change: The out-of-the-Box algorithm for trying to find a WordPress user for the user currently signing in with Microsoft has changed. The rule to match a user by his / her Login Name (= Azure AD preferred login name without domain suffix) has been removed. Administrators can still add this option back. See the [online documentation](https://docs.wpo365.com/article/109-update-order-for-matching-users)).
* Improvement: Administrators (of the SYNC and INTRANET extensions) can now specify nested user profile properties when synchronizing WordPress user profiles with Microsoft Graph e.g. "businessPhones.0" (to retrieve the first business phone listed) or "onPremisesExtensionAttributes.extensionAttribute1" (to retrieve a custom attribute synced from Active Directory).
* Improvement: Administrators (of the LOGIN+, SYNC and INTRANET extensions) can now choose to show (new) users the option to sign up and create a new account in Azure AD B2B when the sign in with Microsoft. See the [online documentation](https://docs.wpo365.com/article/116-add-prompt-create-parameter) for additional considerations and prerequisites.
* Fix: When the plugin fails to create a new user during scheduled user synchronization, the schedule will continue to run and finish as expected.
* Fix: The double '/' when loading the (pintra-)redirect.js file has been removed. 

= v11.14 =
* Improvment: Administrators that have configured SAML 2.0 and have received error reports such as "Authentication method 'WindowsIntegrated' by which the user authenticated with the service doesn't match requested authentication method 'Password, ProtectedTransport'" can now try to configure advanced settings. See the [online documentation](https://docs.wpo365.com/article/100-single-sign-on-with-saml-2-0-for-wordpress) for details.
* Fix: The option to Skip the NONCE verification - on the plugin's Miscellaneous configuration page - has been restored.
* Fix: Due to the NONCE verification causing many false-positives, it now generates a warning instead of an error and will no longer prevent users from being able to log in. Administrators are advised to regularly check their debug logs (or configure logging to Application Insights).

= v11.13 =
* Fix: The plugin will now use WordPress nonces instead.
* Fix: For WordPress Multisite installations the plugin will now try to delete the top level auth cookies to prevent an infinite loop.
* Fix: When the license activation receives a 403 Forbidden it will transparently show this to customers who try to activate their license.

= v11.12 =
* Fix: Now the plugin - when requesting data from Microsoft Graph's /me endpoint - will enforce using delegated (instead of application) permissions.
* Fix: When activation of a license of a premium extension fails the plugin will now log the raw response as an error.

= v11.11 =
* Fix: The (WPO365 | INTRANET edition's version of the) Employee Directory app now allows for configuring a separate initial query when auto-search has been enabled.
* Fix: Functionality to activate the license of the WPO365 | PROFILE+ extension has been restored after it was broken after an earlier change.

= v11.10 =
* Fix: The user look-up algorithm did not search for preferred_username and as a result would not find users with no UPN and email address in their ID token. However, when it then tried to create a new user, an error was thrown in case that user already existed.
* Fix: If the SAML 2.0 response is deemed not valid the plugin will now log the reason as a warning in the debug log.

= v11.9 =
* Improvement: Administrators of all premium extensions can now choose to disable the default WordPress behavior of sending an email to a user when his / her email has changed. See the [online documentation](https://docs.wpo365.com/article/115-prevent-wordpress-to-send-email-changed-email) for details.
* Improvement: The plugin will not intercept requests if initiated from WP CLI.
* Fix: Functionality to activate the license of a premium extension has been restored after it was broken after an earlier change.
* Fix: Functionality to retrieve (partial) templates has been restored after it was broken after an earlier change.
* Fix: Arguments now passed to the developer hooks (as documented [here](https://docs.wpo365.com/article/82-developer-hooks)) updated.

= v11.8 =
* Feature: An Administrator (of the WPO365 | LOGIN+, WPO365 | SYNC and WPO365 | INTRANET extension) can now upload a custom HTML template and replace the default loading bars. See the [online documentation](https://docs.wpo365.com/article/114-customize-the-loading-template) for details.
* Improvement: An administrator can now configure the plugin to tell Microsoft to show the *Select Account* prompt, when it redirects a user to sign in with Microsoft. See the [online documentation](https://docs.wpo365.com/article/112-add-prompt-selectaccount-parameter) for details.
* Improvement: An administrator (of the WPO365 | INTRANET extension) can now configure the full Microsoft Graph query for the Employee Directory / Contacts app when searching for employees and colleagues. This allows for more advanced queries for example using $count, $filter, $search. This improvement now also allows to search in (transitive) members of a group. See the [online documentation](https://docs.wpo365.com/article/111-employee-directory-and-contacts) for details.
* Improvement: An administrator (of the WPO365 | SYNC and WPO365 | INTRANET extension) that configured the synchronization of Microsoft 365 profile images (to replace the user's default WordPress Avatar) now has an extra option to instruct the plugin only to refresh an *expired* profile image of the logged-in user. The plugin will, however, bypass this restriction whenever the administrator synchronizes users on-demand, users are synchronized based on a schedule or a user is being updated through Azure AD's User provisioning (SCIM). See the [online documentation](https://docs.wpo365.com/article/110-only-refresh-avatar-for-logged-in-user) for details.
* Improvement: An administrator (of the WPO365 | LOGIN+, WPO365 | SYNC and WPO365 | INTRANET extension) can now configure the order in which the plugin tries to find a matching WordPress user for the user that signs in with Microsoft (choices are upn, preferred_username, email and login). See the [online documentation](https://docs.wpo365.com/article/109-update-order-for-matching-users) for details.
* Improvement: An administrator (of the WPO365 | LOGIN+, WPO365 | SYNC and WPO365 | INTRANET extension) can now configure the plugin to bypass updating a WordPress user role. This is especially useful for WordPress installations where the users are created manually or WordPress roles are not managed by a WPO365 plugin extension.
* Improvement: An administrator of the WPO365 | LOGIN (free) edition can now choose to disable the automatic registration of new users.
* Fix: Customers reported seeing the **ID token not found in posted data** error which may be a result of the plugin's test mode not being disabled. The plugin will now immediately toggle the test mode and only start the **Plugin self-test** when an ID token is found (in case SAML 2.0 is not configured).
* Fix: The Documents (Microsoft 365) App now support library titles with special characters.
* Fix: The plugin now checks for existing (WordPress) roles when analyzing whether it should add the default role as fallback or not.

= v11.7 =
* Feature: The plugin can now be configured to [send WordPress emails using Microsoft Graph](https://docs.wpo365.com/article/108-sending-wordpress-emails-using-microsoft-graph) as an attractive alternative to sending mail via SMTP.
* Change: Support for symetric algorithms to decrypt the JWT tokens have been removed.
* Change: The user-look-up algorithm first tries to look up a WordPress user by its user principal name (UPN) when that user is not an external user / guest user before it retries using the preferred login name, the user's email address and last the user's account name.

= v11.6 =
* Fix: The automatic update functionality for WPO365 extensions is now better embedded in the overall WordPress update experience.

= v11.5 =
* Feature: The plugin can now dynamically assign WordPress roles to new and existing users based on properties of that user's Azure AD user account e.g. 'Department'.
* Feature: The plugin can now dynamically assign (itthinx) groups to new and existing users based on properties of that user's Azure AD user account e.g. 'Department'.
* Improvement: Now administrators can configure the plugin to use a proxy for the upcoming outgoing server-side request - when ever the plugin tries to build up a connection with PHP cURL e.g. to Microsoft Graph to retrieve information on behalf of a user. 
* Fix: Now throttling of retrieving avatars is working as expected and max. 5 avatars will be refresh per request, to avoid some users experiencing performance degradation.

= v11.4 =
* Fix: Activation of (premium) licenses is now working as expected.
* Fix: Auto-update of (premium) extensions is now working as expected.

= v11.3 =
* Improvement: The nonce generator and validator have been updated in an effort to reduce the risk of nonce not being found.
* Improvement: The plugin won't generate errors anymore when it cannot connect to Microsoft Graph to retrieve the current user's profile in an attempt to improve the data quality when the administrator has not configured the integration portion of the plugin.
* Fix: For reasons of backward compatibility, the plugin now only tries and retrieve all groups that a user is a member of if the ID token doesn't contain this information
* Fix: The plugin now generates a warning instead of an error when it cannot retrieve a user's manager.

= v11.2 =
* Fix: Added missing class method to parse manager details (WPO365 | SYNC and WPO365 | INTRANET edition).

= v11.1 =
* Fix: Domain whitelist now looks both at the email and the login domain.
* Fix: The plugin now checks if the administrator has configured an application secret.
* Fix: The plugin now only tries to save a refresh token if one is present.
* Fix: The wizard now ensures that the INTRANET apps are loaded from the correct source folder.

= v11.0 =
* Breaking Change: The source code of the plugin has been completely restructured. Developers that extended the plugin with own functionality must carefully review the changes.
* Breaking Change: All premium editions of the plugin now require the latest BASIC edition of the plugin to be installed and activated. An notification will be shown to admins upon upgrade to update, install and / or activate it.
* Breaking Change: Support for legacy Azure AD App registrations has been removed. The plugin will now always try and connect to **Azure AD v2** endpoints for authorization and optionally to obtain tokens.
* Breaking Change: Support for Avatars stored as WordPress user meta (in the WordPress database) has been removed. Avatars downloaded from Microsoft 365 / Azure AD will now always be stored in the /wp-content folder.
* Breaking Change: Support for the deprecated **Dual Login** feature is removed. Admins can instead toggle WP Admin > WPO365 > Login / Logout > Dual login V2.
* Breaking Change: Support for the deprecated **Sign in with Microsoft** shortcode [wpo365-sign-in-with-microsoft-sc] has been removed. Admins should configure the [Sign in with Microsoft v2](https://docs.wpo365.com/article/99-add-sign-in-with-microsoft-button-anywhere-shortcode) shortcode instead.
* Feature: Administrators can now choose between [**SAML 2.0 based single sign-on**](https://docs.wpo365.com/article/100-configure-single-sign-on-with-saml-2-0) and OpenID Connect based single sign-on (which remains the default option).
* Feature: The BASIC edition of the plugin will automatically create a new user in WordPress (but not synchronize user profile fields such as first and last name). However, this feature can be disabled by admins.
* Improvement: **User synchronization** now supports WordPress Multisite (WPMU) installations and always synchronizes users to the subsite from which the synchronization was started.
* Improvement: The plugin now remembers the tenant ID of a user and uses that information when - in case of multi tenancy - it needs to retrieve data e.g. a user's profile image from Microsoft Graph.
* Fix: The plugin no longer relies on the ID token to contain the (Azure AD / Microsoft 365 / distribution list) groups that a user is member of. Instead the plugin will always try to obtain this information from Microsoft Graph (but only if needed).
* Fix: The plugin no longer replaces stored avatars when it tries to refresh that avatar but it fails e.g. because of insufficient permissions.

= v10.10 =
* Improvement: The plugin will try to detect a possible infinite loop when the host name of the requested URL is different than the host name of the (Azure AD) redirect URI and inform the administrator to update the wp-config.php (see https://docs.wpo365.com/article/5-infinite-loop for details).
* Improvement: Added the needed prerequisites for l10n based translations for the text domain wpo365-login (a new .POT file has been added to the plugin's /languages folder that can be used e.g. to translate errors and the "Sign in with Microsoft" text on login button).
* Improvement: Thanks to customer feedback, the Teams integration will now automatically redirect the user to the Microsoft login.
* Fix: When using Azure AD customized claims the plugin must use a different endpoint to retrieve the public keys needed to decode the ID token.
* Fix: The Employee Directory now handles the auto-search flag as expected and does not ignore the query template, page and select properties configuration.
* Fix: Error messages now will show on the login page when the adminstrator optimized the plugin's performance (see https://docs.wpo365.com/article/36-authentication-scenario for details).

= v10.9 =
* Change: The PREMIUM and INTRANET edition now support mappings between Azure AD group memberships and (itthinx) Groups that you created with the [Groups plugin](wordpress.org/plugins/groups/).
* Improvement: The "Plugin self-test" will now allow you to inspect the ID token received during the execution of the test.
* Improvement: The WordPress Admin Notification now includes details of the last three errors plus useful links to help resolve those errors.
* Improvement: Several improvements have been made in an attempt to make a first-time installation / configuration successfull e.g. direct links to Azure Portal an an option to hide advanced configuration options.
* Improvement: Even when an administrator configured the global constant WPO_AUTH_SCENARIO and set its value as 'internet' to prevent the plugin from initializing when running in intranet authentication mode, the plugin will still initialize when: 1 - A Microsoft authentication response (= ID token) is detected or 2 - The login_init hook is triggered (which is the case for the default login page).
* Improvement: The Employee Directory / Contacts app now supports a query template that can include a '{searchterms}' placeholder and if it does it will override the default query e.g. startswith(department, '{searchterms}')
* Fix: Microsoft Teams integration accidently was not included in versions v10.6 - v10.8.
* Fix: "Express login" that can be togged for the PREMIUM and INTRANET edition now works as expected (adm)
* Fix: When an error occurs in one of the Microsoft Office 365 Apps, the error message now starts with Oops (instead of Ups).
* Deprecated: The "Nonce secret" option is no longer used (no action required).
* Deprecated: The "Default domain" option is now edited as a "Custom domain" instead (no action required). 

= v10.8 =
* Fix: Power BI Embed token was generated using the wrong scope.
= v10.7 =
* Change: All editions now feature the ability to embed Power BI artifacts such as reports and dashboard in any WordPress page or post. The INTRANET edition - in addition - allows administrators to directly edit the JSON source for generating tokens and embedding artifacts. See [website](https://www.wpo365.com/power-bi-for-wordpress/) for details.
* Change: The INTRANET edition now features a brand new Yammer app that can be embedded in any WordPress page or post. Users are authenticated when they sign into the WordPress website with Microsoft using the single sign-on experience. See [website](https://www.wpo365.com/yammer-for-wordpress/) for details.
* Improvement: The "wpo365_openid_token_processed" developer hook now receives the ID token as a third argument. See [website](https://docs.wpo365.com/article/82-developer-hooks) for details.
* Fix: The (Microsoft Graph) Employee Directory app now correctly clears the list of existing results when the user continues to type the search query.

= v10.6 =
* Change: All editions of the plugin will now always show a "Sign in with Microsoft" button on the (default) WordPress login form. Administrators, however, can choose to hide the button. See https://docs.wpo365.com/article/81-enable-dual-login for details.
* Change: The plugin no longer rejects the ID token of a user without a valid email address. This may result in premium editions of the plugin creating WordPress users without a valid address.
* Change: The plugin now provides 3 hooks for developers to respond when a user signs in with Microsoft, receives an access token and when the plugin analyzes reasons to skip authentication. These hooks are not enabled by default. See https://docs.wpo365.com/article/82-developer-hooks for details.
* Improvement: The (Helpscout) Support Beacon is now loaded whenever the plugin's configuration wizard is loaded. This makes it very easy to search the available documentation when configuring the plugin without the need to open a new browser window.
* Improvement: A new toolbar has been added to the plugin's configuration wizard the interacts with the (Helpscout) Support Beacon, making it really easy to contact WPO365 support.
* Improvement: The wizard now tries to load pages from the new (but still work-in-progress) documentation service https://docs.wpo365.com.

= v10.5 =
* Fix: The (PREMIUM and INTRANET editions of the) plugin now checks if the BuddyPress avatar is requested for a user (e.g. and not for a group).
* Fix: The (INTRANET edition's) Content by (SharePoint Online) Search app auto-search function did not automatically started a new search immediately after being loaded.
* Improvement: The (INTRANET edition's) Content by (SharePoint Online) Search app now injects a count property into the Handlebar template to make it possible e.g. to show a table header before the first row.

= v10.4 =
* Fix: The plugin now saves the request ID variable as a GLOBAL variable.
* Fix: A missing (global) namespace declaration in the plugin's update checker could cause a serious error.
* Fix: The Content by Search (SharePoint Online) and Documents (SharePoint Online / OneDrive) apps will now format dates based on the detected user's browser (language) preference.

= v10.3 =
* Fix: Accented characters e.g. é, è or ä would prevent the wizard from saving updated options (e.g. custom error messages, Office 365 profile field labels etc.).
* Fix: The PLUS+ edition's update checker was not tracking the correct item in the online store and therefore didn't show that updates were available.

= v10.2 =
* Fix: Usage of trailing comma's after method parameters is not supported before PHP 7.3 and hence for older PHP versions the plugin may not load as expected (affected the INTRANET edition v10.1).
* Fix: Usage of the PHP function get_file_contents to retrieve the WordPress gravatar for a user may cause a warning if the IT administrator had disallowed allow_url_fopen in php.ini (affected PREMIUM and INTRANET editions v10.1).
* Fix: The table that tracks the user synchronization results was only updated with the results of the last batch (affected the PREMIUM and INTRANET editions v10.0 and higher).

= v10.1 =
* New capability: An administrator (of the INTRANET edition of the plugin) can now configure Azure AD User provisioning by configuring the custom WPO365 SCIM endpoint for WordPress. See https://docs.wpo365.com/article/59-wordpress-user-provisioning-with-azure-ad-scim for details.
* Improvement: The plugin now tries to detect whether the requested WordPress page is loaded inside of Microsoft Teams e.g. as Content Page of a custom built Microsoft Teams App. If this is the case, the plugin will show a "Sign in with Microsoft" button that - when clicked - will then start the authentication workflow in a popup window that is controlled by Microsoft Teams. See https://docs.wpo365.com/article/70-adding-a-wordpress-tab-to-microsoft-teams-and-use-single-sign-on for details.
* Improvement: Additional Office 365 fields can now be mapped to BuddyPress Extended Profile Fields.
* Improvement: An administrator can now choose to stream the WPO365 log to a remote instance of Microsoft ApplicationInsights and by doing so benefit from the advanced search, analytics and alert functions the platform offers. See https://docs.wpo365.com/article/60-use-applicationinsights for details.
* Improvement: When synchronizing users (with the PREMIUM and / or INTRANET edition of the plugin) an Administrator can now choose to soft-delete users which will result in soft-deleted users no longer being able to sign into the WordPress. Instead those users will see an "Account deactivated" error message.
* Fix: The Documents app's breadcrumb navigation will now start with the folder name if a folder path has been provided.
* Fix: Checked PHP 7.3 compatibility with PHP Compatibility Checker and fixed two issues.

= v10.0 =
* New capability: An adminstrator (of the PREMIUM and INTRANET edition of the plugin) can now create a schedule to synchronize users between Azure AD and Wordpress at regular (daily or weekly) intervals. Please note that doing so requires you to have configured the (App-only) Application (client) ID and corresponding secret (see https://www.wpo365.com/use-app-only-token/ and https://www.wpo365.com/app-only-application-id/ for more details about app-only permissions). Please also note that scheduled user synchronization relies on WordPress cron jobs. 
* New capability: In addition to the Employee Directory the (INTRANET edition of the plugin) now offers an advanced Contacts app that allows users to search for users, view their contact details and see their direct reports as well as their managers in the form of an interactive clickable organization chart. The app uses Handlebar templates that can be used to further customize the user experience.
* Improvement: The Documents app (of the INTRANET edition of the plugin) can now be configured to only show the contents of a SharePoint Online / OneDrive folder. In addition it can be configured to show the "recently used" documents of the "logged-in" user.
* Improvement: Most apps now offer the ability to add translations for (most of) the user interface elements (error information not always included).
* Improvement: To optimize performance in case of the "Internet" authentication mode, administrators can now add the following line to the wp-config.php: "define( 'WPO_AUTH_SCENARIO', 'internet' );". This will prevent the plugin from loading for all requests that are not for WordPress administration pages. Please be aware that - if you add this line to your wp-config.php - you must ensure that the Redirect URI ends with "/wp-admin/". If this is not the case, the plugin won't be able to receive the authentication response sent by Microsoft and the plugin will not work as expected. Please also note that the following Login / Logout capabilities won't work and must be de-activated in advance: Dual Login, Error Page.
* Improvement: All apps have been refactored from the ground up and have been greatly simplified from a technical / maintenance point of view by utilizing Function Components combined with React Hooks and removing React Redux alltogether. Administrators are advised to test the apps before upgrading in production.
* Fix: Previously, the plugin would overwrite the array containing a user's (Azure AD) groups with an empty array when it tried to retrieve missing profile fields from Microsoft Graph.

= v9.6 =
* Improvement: The plugin will now try to request data from Microsoft Graph for the current user if essential information (user principal name, email, first or last name) is not included in the initial authentication response (ID token) (PROFESSIONAL, PREMIUM and INTRANET editions only).
* Improvement: The WordPress session will expire automatically whenever the user closes the browser. A new setting has been added (on the Single Sign-on tab of the plugin's wizard) to remember the user.
* Improvement: The (INTRANET edition of the) Employee Directory now includes an Org Chart template that allows users to see an employee's manager and direct reports.
* Improvement: You can now customize the appearance of the (INTRANET edition of the) Documents app by adding your own translations for the available columns (or choose not to show a column at all).
* Improvement: The plugin is now capable of running a self-test sequence that validates core configuration and received ID and access tokens. Test results include hints and recommendations for improvement.
* Improvement: The debug log now shows an ID for each request, making it easier to understand the program flow when executing multiple requests simultaneously.
* Improvement: The (PREMIUM and INTRANET) edition of the plugin now allows storing Office 365 profile images as avatars in the wp-content folder without the need to configure a secondary App registation for app-only tokens.
* Tested: Compatibility with WordPress 5.3.
* Fix: PREMIUM and INTRANET edition of the plugin do not retrieve Avatar for another user when synchronizing.
* Fix: PREMIUM and INTRANET edition of the plugin do not update extra O365 fields if that field is a boolean and changes from true to false.
* Fix: Compatibility with PHP 7.4 (create_func deprecation).
* Fix: By default the plugin now starts validation of the current session on WordPress' init hook. Administrators can, however, override this and choose to start validation earlier on the plugins_loaded hook.

= v9.5 =
* Improvement: An administrator can now configure to save the retrieved O365 user profile images in wp-content/uploads/wpo365/profile-images (instead of in the database), helping boost performance significantly.
* Improvement: An administrator can now configure a 2nd Azure AD App registration for so-called application permissions. Doing so eliminates the need for sensitve permissions such as Groups.Read.All and User.Read.All being granted for all users.
* Improvement: Apps can now be customized with the help of (<a href="https://handlebarsjs.com/" target="_blank">Handlebars.js</a>)templates</a> (Employee Directory, Content by Search).
* Improvement: Using (colorful) branded icons for Office products (Content by Search).
* Improvement: Specify the (custom Azure AD extension) properties that should return from a Microsoft Graph users query e.g. employeeId (Employee Directory).
* Improvement: Specify to use the current user's OneDrive as the library source instead of entering the OneDrive site address and library title (Documents).
* Fix: IE 11 compatibility (all apps).
* Fix: Rendering of (user profile) images in search results (Employee Directory, Content by Search).
* Fix: Increased time-out waiting to start searching after a user entered a query (Employee Directory).

= v9.4 =
* Improvement: An administrator can now configure the plugin to automatically assign users a WordPress role by creating one or more mappings between a (username's login) domain on the one side and a WordPress role on the other side. Visit https://www.wpo365.com/domain-roles-mappings/.
* Improvement: Added support for so-called Azure single sign out. Visit https://www.wpo365.com/enable-logout-without-confirmation/.
* Improvement: An administrator can now configure a domain hint to prevent users that are already logged on toanother Azure AD / Office 365 tenant from signing in with possibly the wrong Microsoft work or school account. Visit https://www.wpo365.com/domain-hint/.
* Improvement: The plugin, when receiving the authentication response from Microsoft, will now additionally search in WordPress for users by account name i.e. the user's principal name (= Office 365 login name) without the domain suffix. However, please be aware that some plugin features expect a WordPress username to be a legitimate Azure AD login name. Features not working when the WordPress user name is not a fully qualified Azure AD user principal name are the Avatar synchronization, mapping of Azure AD group memberships to WordPress roles and adding additional Office 365 user profile properties to a user's WordPress and / or BuddyPress profile as well as the deep integration in MS Graph and SharePoint Online.
* Improvement: Some 3rd party themes and plugins that hook into the user_register action e.g. to send an email with a confirmation link, would run into a fatal error when the action was triggered. This new configuration setting (on the Miscellaneous tab) - when checked - is a work-around to disable the action from being triggered (when a new user is created automatically by the plugin). Visit https://www.wpo365.com/skip-user-register-action/.
* Fix: Error "Undefined variable: resource Auth.php on line 774".

= v9.3 =
* Change: The plugin now ships with a built-in SharePoint Online Documents app (see https://www.wpo365.com/documents/). 
* Improvement: A new setting "Retrieve all group memberships" allows you to retrieve all sorts of groups memberships when synchronizing users instead of only the security-enabled group memberships.

= v9.2 =
* Fix: Now getting / setting WordPress transients take into account WordPress multisite to prevent "Your login has been tampered with" error when signing into a subsite (when authentication configuration is shared between all sites in the network).

= v9.1 =
* Improvement: Optionally you can specify your custom query when synchronizing users.
* Improvement: Optionally you can specify a Welcome Page URL where new users are sent after they signed on with Microsoft the very first time.
* Improvement: You can now (try to) activate your license.
* Fix: When redirecting, the plugin now writes a proper HTML document incl. doctype.
* Fix: The plugin now tries to obtain the initial URL the users intended to load on the client to preserve query parameters and fragments (hash).

= v9.0 =
* Change: The plugin now ships with a built-in SharePoint Online Search app (see https://www.wpo365.com/content-by-search/). 
* Change: The plugin now ships with a built-in Employee Directory app that queries Microsoft Graph (see https://www.wpo365.com/employee-directory/).
* Change: When using BuddyPress you can now instruct the plugin to show the Office 365 profile picture instead.
* Fix: When synchronizing users the plugin will now also update core user fields (email, first name, last name, display name).
* Fix: When synchronizing users the plugin will now also retrieve a user's Office 365 profile picture (if this feature is enabled and if an older version that has not yet expired is not found).
* Fix: If the plugin detects a different scheme between the Azure AD redirect URL and the URL the user navigated to before the SSO workflow started the plugin autocorrects the scheme (changes http:// to https://) to avoid infinite loops. An error will be generated in the log and the admin should take appropriate measures e.g. updating .htaccess to ensure the site automatically redirects to its secure version.

= 8.6 =
* Fix: The plugin will only (try to) retrieve additional user fields (from O365) if the user signed in with Microsoft (assumption made by analyzing the email domain).
* Fix: When the Dual Login feature is activated, the plugin now redirects the user to the WordPress site instead to initiate the login workflow.
* Fix: A typo caused the BASIC edition to cause a warning when trying to show the discount banner.
* Fix: When redirecting to Microsoft the plugin would sometimes not remember the state correctly, resulting in a login error.
* Fix: Cache buster for the wizard was not set correctly and therefore wizard updates were not immediately visible after an upgrade.
* Fix: More robust detection whether WordPress is loaded in an iframe.

= 8.5 =
* Change: Now the plugin will no longer require access to WP REST API or WP AJAX API. Instead the plugin adds an additional POST request to trigger the Single Sign-on workflow. This request uses a cache breaker to work-around server-side cache, allowing admins to configure the home url (instead of the WP Admin url) as a Redirect URI for the Azure AD App registration.
* Change: User synchronization no longer requires (unattended) access to the WP AJAX API. Instead the plugin will "loop" until all users found in Microsoft Graph have been processed. For the admin starting the synchronization this will appear as a synchronous action but in reality the synchronization is executed in batches of 10 users. By doing so the synchronization will not eventually time out (but as a drawback can also not be executed unattended).

= 8.4 =
* Fix: Removed the "too" opinionated validation of schemes used for redirect URI and WordPress URL.
* Fix: Improved the detection of HTTPS (but it is up to the administrator to ensure SSL is being enforced for the front and back end).
* Fix: Removed dead code.

= 8.3 =
* Change: Moved the custom API for users to obtain the Microsoft authentication endpoint e.g. login.microsoftonline.com to the WordPress REST API. Please ensure that this endpoint i.e. https://www.example.com/wp-json/wpo365/ is not blocked e.g. by basic auth, another plugin or your firewall.
* Change: If the custom (WP REST) API is not available to end users (e.g. because it is disabled or blocked) the user will see an error message and instructions on how to resolve the issue are printed to the developer console (F12).
* Change: The option to bypass the NONCE verification (at your own risk) to work around server-side cache has been re-activated. This options should only be used in combination with SSL.
* Change: The client-side redirect script will try and detect if it's being loaded in an iframe (which is by default not supported by Microsoft) and if this is the case it will try and open a popup instead. Please make sure popup blockers are disable for your domain, if you are trying to place your website in an iframe. For Internet Explorer / Edge please make sure that login.microsoftonline.com and your website are both added to the same security zone.
* Change: Logging has been improved with a filter to only show errors and error descriptions now offer more guidance on how they can be resolved.
* Fix: When WordPress multisite has been installed, the plugin will detect when the user changes the (sub) site (when the admin configured WPO_MU_USE_SUBSITE_OPTIONS (true)) and if this is the case signs out the user and eventually redirects the user to Microsoft to authenticate for the new (sub) site.

= 8.2 =
* Fix: WPO365 admin menu not available when WPO_MU_USE_SUBSITE_OPTIONS (true) has been configured.
* Fix: O365 user fields now requested using the user's principal name (upn) instead of email address.

= 8.1 =
* Fix: Compatibility with older browsers, specifically IE11.
* Fix: Added a plugcache breaker when loading pintra-redirectjs.

= 8.0 =
* Change: To work-around server-side caching the previous solution to redirect via /wp-admin has been discontinued. Instead the plugin will now output a short (cachable) JavaScript that will request the authentication URL from a custom WordPress AJAX service and redirect the user accordingly.
* Change: The way nonces are generated and validated has been changed to ensure that nonces are really used only once.
* Change: A version 2 of the "Sign-in with Microsoft" shortcode has been added to take advantage of the beforementioned client-side redirection to prevent server-side caching. Older "Sign-in with Microsoft" shortcode templates will continue to work but it is recommended that they are updated accordingly.
* Change: A version 2 of the "Dual Login" feature (= previously referred to as "Redirect to login")  has been added to take advantage of the beforementioned client-side redirection to prevent server-side caching. Older Dual Login templates will continue to work but it is recommended that they are updated accordingly.
* Change: The plugin now requires that the Azure AD "Redirect URI" and your WordPress (Site) Address use the same scheme e.g. http(s). If this is not the case it will show a "Plugin is not configured" error and will basically disable it self, to prevent infinite loops.
* Change: Debug log will now show the debug in descending order (latest entries first).
* Change: The plugin will now try and automatically add a trailing slash whenever it tries to redirect the user.
* Change: When using the "Dual Login" feature (= previously referred to as Redirect to login) the plugin will now remember the URL the user initially requested and redirect the user accordingly upon successful authentication.
* Change: The plugin's wizard "Test authentication" button has been removed. Instead the configuration is always saved and then tested. The authentication URL used for testing will now appear after clicking "Save configuration" since this URL (and the corresponding nonce) is generated server-side and must be unique.
* Fix: A legacy function to prevent client-side caching that generated unnecessary error log entries (and thus unnecessary warnings in WP admin) has been removed.

= 7.18 =
* Change: The plugin will regularly check the error log to see if recently new errors were logged and if so show a dismissable notice in the WordPress admin area.
* Change: The administrator can choose to surpress the error notice in the WordPress admin area.
* Fix: Improved the improved way of parsing the ID token (trying to get the user principal name first if available).
* Fix: The plugin would throw an previously uncaught exception when trying to log an event when the synchronization of users would fail.

= 7.17 =
* Change: Now that Microsoft has made the new Azure App registration portal General Available, the recommended Azure AD endpoint to use is v2.0 (see https://www.wpo365.com/azure-application-registration/)
* Change: The plugin now supports retrieving manager data (display name, email, telephone number(s), office location, country) of an O365 user through Microsoft Graph.
* Change: When configuring "Redirect to login" you can now choose to hide the SSO link which is otherwise shown above the login form.
* Change: You can now configure a custom login URL (which is automatically added to the Pages Blacklist).
* Fix: Improved way of parsing the ID token, avoiding unexpected WP user names, especially for Azure AD guests and users from other tenants.
* Fix: Display name property now correctly set when creating a new WP user using the information from the parsed ID token.
* Fix: Now the plugin will check - when multisite is activated - whether the logged in user autenticated for the current site and if not the user will be logged out and forced to authenticate again.
* Fix: WP user now created with a stronger default password.

= 7.16 =
* Fix: Improved caching of license check result to prevent it from impacting the overall website performance.
* Fix: Now the wizard is loaded with a cache breaker to ensure with each new plugin version the latest version shows immediately.
* Fix: White spaces at the beginning and end of configuration options that are strings are now properly trimmed.

= 7.15 =
* Change: Added software licensing and replaced automated upgrade with license key based solution (professional and premium version).
* Fix: Additional logging when synchronizing user (premium version).

= 7.14 =
* Change: Added an extra option (see Miscellaneous tab of the plugin's configuration wizard) to prevent the wp-login hook from being fired as it may cause an error in combination with some 3rd party themes.
* Fix: The plugin now recognize the super administrator (available only for WordPress multisite) as an administrator of (any) subsite.

= 7.13 =
* Fix: The plugin now checks whether a user is an administrator by verifying roles instead of capabilities.
* Fix: The plugin's URL cache now resolves the WordPress home URL instead of the site address for the website's front end home.
* Fix: The plugin now correctly recognizes a "bounced" request when preparing to redirect the user to Microsoft's authentication endpoint.

= 7.12 =
* Change: The plugin can be configured to skip authentication when requesting data from the WordPress REST API when a Basic authentication header is present (professional and premium editions only).
* Change: You can configure the plugin to skip nonce verification (however, it is not recommended to do so but instead find the root cause e.g. an aggressive server-side caching strategy).
* Change: User synchronization is now supported at the level of a (sub) site in a WordPress Multisite WPMU network (premium edition only).
* Change: User synchronization now checks user capabilities and won't delete users that have the administrator capability (premium edition only).
* Fix: Check for admin capabilities would not always return true for a WordPress Multisite WPMU Network.
* Fix: Due to a regression the number of user synced per batch was set to 1 instead of 10 (premium edition only).
* Fix: Manual login attempts will now be intercepted even when redirect to login is checked (professional and premium editions only).

= 7.11 =
* Change: User Synchronization is now executed in asynchronous batches of 25 users each until finished to prevent a timeout exception. As soon as the asynchronous user synchronization has finished the plugin will (try and) send an email to website's administrator (premium version only).
* Change: When you have selected the Intranet (Authentication) Scenario, you can check the "Public Homepage" option to allow anonymous access to the WordPress frontpage i.e. your website's home page (premium and professional version only).
* Change: A direct link to the WPO365 Wizard has been added to the Admin Dashboard Menu.
* Change: You can now toggle debug mode comfortably from the "Debug" tab that has been added to the plugin's configuration wizard. The debug log can now be viewed on that tab as well and you can copy the log to the clipboard.
* Change: The plugin now partially obscures a number of configuration secrets e.g. application ID, application secret, nonce etc.
* Change: The plugin's wizard has been enhanced with a number of warnings in the form of popups to provide more guidance when configuring the plugin.
* Fix: Synchronizing external users has been improved and the user name configured by the plugin is the external user's own email address (instead of the - sanitized - Azure AD User Principal Name) (premium version only).
* Fix: When a user - for any reason - cannot be created, the plugin would try and log that user's ID, causing an irrecoverable exception, which is now caught and logged adequately.

= 7.10 =
* Fix: Stricter validation of the Error Page URL and Pages Blacklist entries to ensure that the website is not accidently added (causing the plugin to skip authentication alltogether).
* Fix: Automatic update for the PROFESSIONAL edition failed.

= 7.9 =
* Fix: Custom error messages were ignored due to an error with the property's casing.
* Change: The professional and premium version now offer a "Redirect to login" option that when checked will send the user to the default WordPress login form (instead of the Microsoft) and on the login form a message will inform the user that he / she can also sign into the website using his / her Microsoft Office 365 / Azure AD account (and provide a link that when clicked will sign in the user with Microsoft)

= 7.8 =
* Fix: Auto-fix for bypassing server-side cache dind't work as expected.
* Change: The BASIC edition will now show an appropriate error message when user not found.
* Change: Added a short code that can be used on a custom error page to display the plugin's error message (professional / premium only).

= 7.7 =
* Fix: Removed "Plugin not configured" error redirection which prevented users to logon with their WordPress-only admin account when then plugin was not yet configured.
* Fix: (Smoke) Tested against PHP 7.3.3 and replaced deprecated create_function call.

= 7.6 =
* Change: When you change the authentication scenario to "Internet" the Pages Blacklist will be replaced by a Private Pages list. Posts and Pages added to the new Private Pages list will only be accessible for authenticated users. If the user is authenticated, the plugin will try and sign in the user with Microsoft.
* Change: You can now configure an Error Page. When configured, the plugin will redirect the user to this page each time it runs into an error e.g. user not found, plugin not configured etc. If no Error Page is configured, the plugin will instead redirect the user to the default WordPress login form. The plugin will automatically skip the Error Page when authenticate a request (to avoid an infinite loop). The error code will be sent along as query string parameter and can be used to customize your own Error Page.
* Fix: Added MIME Type and Content Headers to the New User Notification email template.

= 7.5 =
* Change: Sending a customized new user registration email is not supported by the basis (free) version. See <a href="https://www.wpo365.com/new-user-email/">online documentation</a> for details.

= 7.4 =
* Fix: If a user is not manually registered prior to trying to sign into the WordPress site with Microsoft, the user would end up in an infinite loop (only impacts basic version).
* Fix: Remove crossorigin from Pintra Fx template since this was causing an issue downloading react files from UNPKG CDN.

= 7.3 =
* Fix: A new setting "Don't try bypass (server side) cache" on the Miscellaneous Tab now controls whether the plugin will try and bypass the server side cache by redirecting the user first to /wp-admin before redirecting the user to Microsoft's Identity Provider.
* Fix: A new global constant WPO_MU_USE_SUBSITE_OPTIONS allows administrators of a WordPress multisite network to toggle between a "shared" scenario in which all subsites in the network share the same Azure AD application registration and a "dedicated" scenario in which all sites in the network will have to be configured individually. 

= 7.2 =
* Fix: Missing namespace import causing server error when user cannot be added successfully [professional, premium]

= 7.1 =
* Change: Now the plugin can redirect users based on their Azure AD Group Membership [premium]
* Fix: User synchronization would not work correctly with Graph Version set to beta
* Fix: Added support for wp_login hook
* Fix: Lowered priority when hooking into the wp_authenticate hook

= 7.0 =
* Plugin options are now managed through a new Wizard app that can be opened from the WordPress Plugins page where a new action link has been added to the wpo365-login plugin
* Support for configuring options through wp-config.php and Redux Platform has been discontinued (existing options will be upgraded automatically)
* Harmonized version number across all versions

= 6.1 =
* Change: Removed the (Redux) WPO365 Option for scope
* Change: Support for Azure AD v2.0 authentication and access token requests (preview, more information will follow in a separate upcoming post)
* Change: Updated the access token (AJAX) service API to support Azure AD v2.0 scope based token requests
* Change: Authorization, access and refresh codes and tokens are now stored as JSON encoded classes
* Change: Previously deprecated methods have been removed (other / third party plugins and apps must integrate using the API now)

= 6.0 =
* Change: A configuration option has been added to always redirect a user to a designated page upon signin into the website
* Change: A client (side) application can now request an oauth access token for any Azure AD secured resource e.g. Graph and SharePoint Online
* Change: A configuration section has been added to configure / disable the aforementioned AJAX service for Azure AD oauth access tokens
* Change: A Configuration section has been added that allows administrators to define custom login error messages
* Change: Refresh tokens e.g. for Graph and SharePoint Online are now set to expire after 14 days
* Change: The plugin will now cache the Microsoft signin keys used to verify the incoming ID token for 6 hours to improve overall performance
* Change: The flow to obtain access tokens has been refactored and greatly simplied (existing methods have been marked deprecated)
* Fix: Dynamic role assignment will not add default role when user has existing role(s)

= 5.3 =
* Change: Pages Blacklist can now include query string parts e.g. "?api=" but administrators need to be aware that this can potentially weaken overall security [read more](https://www.wpo365.com/pages-blacklist/)

= 5.2 =
* Fix: user_nicename - a WP_User field that is limited to 50 characters - was wrongly set to a user's full name which under circumstances prevented a user from being created successfully

= 5.1 =
* Fix: When searching for O365 users search both in email and login name
* Fix: Check before redirecting whether headers are sent and if yes falls back to an alternative method to redirect
* Fix: search_columns argument for WP_User_Query must be an array

= 5.0 =
* Moved the JWT class into the Wpo namespace (to avoid class loading issues)
* Added psr-4 type auto class loading
* Code refactoring to allow for tighter integration e.g. with [SharePoint Online Plugin](https://wordpress.org/plugins/wpo365-spo/)
