<?php

    namespace Wpo\Graph;
        
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die();

    use \Wpo\Core\Url_Helpers;
    use \Wpo\Services\Graph_Service;
    use \Wpo\Services\Log_Service;
    use \Wpo\Services\Options_Service;

    if( ! class_exists( '\Wpo\Graph\Request' ) ) {

        class Request {

            /**
             * A transparant proxy for https://graph.microsoft.com/.
             * 
             * Supported body parameters are:
             * - application (boolean)  -> when an access token emitted by the Azure AD app with static application permissions should be used.
             * - binary (boolean)       -> e.g. when retrieving a user's profile picture. The binary result will be an JSON structure with a "binary" member with a base64 encoded value.
             * - data (string)          -> Stringified JSON object (will only be sent if method equals post)
             * - headers (array)        -> e.g. {"ConsistencyLevel": "eventual"}
             * - method (string)        -> any of get, post
             * - query (string)         -> e.g. demo@wpo365/photo/$value
             * - scope (string)         -> the permission scope required for the query e.g. https://graph.microsoft.com/User.Read.All.
             * 
             * @param WP_REST_Request $rest_request The request object.
             * @return array|WP_Error
             */
            public static function get( $rest_request, $endpoint ) {
                $body = $rest_request->get_json_params();

                if ( empty( $endpoint ) || empty( $body ) || !\is_array( $body ) || empty( $body[ 'query' ] ) ) {
                    return new \WP_Error( 'InvalidArgumentException', 'Body is malformed JSON or the request header did not define the Content-type as application/json.' );
                }

                $application = ! empty( $body[ 'application' ] ) ? true : false;
                $binary = ! empty( $body[ 'binary' ] ) ? true : false;
                $data = ! empty( $body[ 'data' ] ) ?  $body[ 'data' ] : '';
                $headers = ! empty( $body[ 'headers' ] ) ? $body[ 'headers' ] : array();
                $method = ! empty( $body[ 'method' ] ) ? \strtoupper( $body[ 'method' ] ) : 'GET';
                $query = $endpoint . Url_Helpers::leadingslashit( $body[ 'query' ] );

                $result = Graph_Service::fetch( $query, $method, $binary, $headers, ! $application, false, $data );

                if ( \is_wp_error( $result ) ) {
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Could not fetch data from Microsoft Graph [' . $result->get_error_message() . '].' );
                    return new \WP_Error( 'GraphFetchError', $result->get_error_message() );
                }

                if ( empty( $result ) ) {
                    return new \WP_Error( 'GraphFetchError', 'Your request to Microsoft Graph returned an empty result.' );
                }

                if ( $result[ 'response_code' ] < 200 || $result[ 'response_code' ] > 299 ) {
                    $json_encoded_result = \json_encode( $result );
                    Log_Service::write_log( 'ERROR', __METHOD__ . ' -> Could not fetch data from Microsoft Graph [' . $json_encoded_result . '].' );
                    return new \WP_Error( 'GraphFetchError', 'Your request to Microsoft Graph returned an invalid HTTP response code [' . $json_encoded_result . '].' );
                }
                
                if ( $binary ) {
                    return array( "binary" => \base64_encode( $result[ 'payload' ] ) );
                }

                return $result[ 'payload' ];
            }
        }   
    }