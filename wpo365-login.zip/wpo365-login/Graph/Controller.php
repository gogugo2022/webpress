<?php

    namespace Wpo\Graph;
        
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die();

    use \Wpo\Graph\Request;
    use \Wpo\Services\Access_Token_Service;
    use \Wpo\Services\Log_Service;
    use \Wpo\Services\Options_Service;

    if( !class_exists( '\Wpo\Graph\Controller' ) ) {

        class Controller extends \WP_REST_Controller { 

            /**
             * Register the routes for the objects of the controller.
             */
            public function register_routes() {

                $version = '1';
                $namespace = 'wpo365/v' . $version . '/graph';

                register_rest_route( $namespace, '/user', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::READABLE,
                            'callback' => '\Wpo\Graph\Current_User::get_current_user',
                            'permission_callback' => array( $this, 'check_permissions_current_user' ),
                        ),
                    )
                );

                register_rest_route( $namespace, '/users', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/users' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );

                register_rest_route( $namespace, '/myorganization', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/myorganization' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );

                register_rest_route( $namespace, '/me', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/me' ); 
                            },
                            'permission_callback' => array( $this, 'check_permissions' ),
                        ),
                    )
                );

                register_rest_route( $namespace, '/groups', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/groups' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );

                register_rest_route( $namespace, '/drives', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/drives' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );

                register_rest_route( $namespace, '/sites', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/sites' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );

                register_rest_route( $namespace, '/search', 
                    array(
                        array(
                            'methods' => \WP_REST_Server::CREATABLE,
                            'callback' => function ( $request ) { 
                                return Request::get( $request, '/me' ); 
                            },
                            'permission_callback' => function ( $request ) {
                                return $this->check_permissions( $request, true );
                            }
                        ),
                    )
                );
            }

            /**
             * Checks if the user can retrieve an access token for the requested scope.
             * 
             * @param string $scope Scope for which the token must be valid.
             * @return bool|WP_Error True if user can retrieve an access token for the requested scope otherwise a WP_Error is returned.
             */
            public function check_permissions( $request, $allow_application = false ) {
                
                if ( ! wp_verify_nonce( $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
                    return new \WP_Error( 'UnauthorizedException', 'The request cannot be validated.', array( 'status' => 401 ) );
                }

                $body = $request->get_json_params();

                if ( empty( $body ) || !\is_array( $body ) || empty( $body[ 'scope' ] ) ) {
                    return new \WP_Error( 'InvalidArgumentException', 'No (Microsoft Graph permission) scope has been defined. Possibly the request body is malformed or the request header did not define the Content-type as application/json.', array( 'status' => 400 ) );
                }

                // The query does not require a logged-in user
                if ( $allow_application && ! empty( $body[ 'application' ] ) && $body[ 'application' ] === true ) return true;

                $wp_usr_id = \get_current_user_id();

                if ( $wp_usr_id === 0 ) {
                    return new \WP_Error( 'UnauthorizedException', 'Please sign in first before using this API.', array( 'status' => 401 ) );
                }

                $access_token = Access_Token_Service::get_access_token( $body[ 'scope' ] );

                if ( \is_wp_error( $access_token ) ) {
                    return new \WP_Error( 'UnauthorizedException', 'Could not retrieve an access token for scope ' . $body[ 'scope' ] . ' [' . $access_token->get_error_message() . '].', array( 'status' => 400 ) );
                }

                return true;
            }

            /**
             * Checks if a user is logged in.
             */
            public function check_permissions_current_user() {
                $wp_usr_id = \get_current_user_id();

                if ( $wp_usr_id === 0 ) {
                    return new \WP_Error( 'UnauthorizedException', 'Please sign in first before using this API.', array( 'status' => 401 ) );
                }

                return true;
            }
        }
    }