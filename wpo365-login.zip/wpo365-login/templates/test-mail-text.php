<?php defined( 'ABSPATH' ) or die(); ?>
Hi there
                
Thank you for choosing WPO365 | LOGIN and its extension to 
seamlessly connect your WordPress website with the powerful
world of Microsoft Office 365 and Azure AD.

This email is a test and is sent to you on your own request
upon saving updated settings for the Graph Mailer feature.

I hope everthing works as expected. If not, then please
don't hesitate and get in touch, for example through the 
blue help beacon that you find when you go to your WordPress
Admin Dashboard > WPO365.
                
Marco van Wieren, Downloads by van Wieren
WPO365 - Connecting WordPress and Microsoft Office 365 / Azure AD
Zurich, Switzerland
t https://twitter.com/WPO365
w https://www.wpo365.com
e support@wpo365.com
