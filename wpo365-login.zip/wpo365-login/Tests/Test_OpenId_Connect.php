<?php

    namespace Wpo\Tests;

    use \Wpo\Services\Id_Token_Service;
    use \Wpo\Services\Options_Service;
    use \Wpo\Services\Request_Service;
    use \Wpo\Services\User_Service;

    // Prevent public access to this script
    defined( 'ABSPATH' ) or die();

    if ( !class_exists( '\Wpo\Tests\Test_OpenId_Connect' ) ) {

        class Test_OpenId_Connect {

            private $id_token = null;
            
            public function test_application_id() {

                $test_result = new Test_Result( 'Application ID has been configured', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_BLOCKING );
                $test_result->passed = true;

                $application_id = Options_Service::get_aad_option( 'application_id' );

                if ( empty( $application_id ) ) {
                    $test_result->passed = false;
                    $test_result->message = "Application ID is not configured but needed for OpenID Connect based Single Sign-On and many of the supported features. It may be omitted in case of SAML 2.0 based Single Sign-On. Please copy the 'Application (client) ID' from your Azure AD App registration's 'Overview' page and paste it into the corresponding field on the <a href=\"#singleSignOn\">'Single Sign-on' tab</a>.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }
                elseif ( !preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/', $application_id ) ) {
                    $test_result->passed = false;
                    $test_result->message = "Application ID is not a valid GUID but needed for OpenID Connect based Single Sign-On and many of the supported features. It may be omitted in case of SAML 2.0 based Single Sign-On. Please copy the 'Application (client) ID' from your Azure AD App registration's 'Overview' page and paste it into the corresponding field on the <a href=\"#singleSignOn\">'Single Sign-on' tab</a>.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_redirect_url() {

                $test_result = new Test_Result( 'Redirect URL has been configured', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_BLOCKING );
                $test_result->passed = true;

                $redirect_url = Options_Service::get_aad_option( 'redirect_url' );

                if ( empty( $redirect_url ) ) {
                    $test_result->passed = false;
                    $test_result->message = "The Redirect URL is not configured but needed for OpenID Connect based Single Sign-On. It may be omitted in case of SAML 2.0 based Single Sign-On. Please copy the 'Redirect URI' from your Azure AD App registration's 'Authentication' page and paste it into the corresponding field on the plugin's <a href=\"#singleSignOn\">Single Sign-on</a> page.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_decode_id_token() {
                delete_site_option( 'wpo365_msft_key' );
                delete_site_option( 'wpo365_msft_keys' );

                $test_result = new Test_Result( 'Can decode the ID token', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_BLOCKING );
                $test_result->passed = true;

                $this->id_token = Id_Token_Service::decode_id_token();

                if ( empty( $this->id_token ) ) {
                    $test_result->passed = false;
                    $test_result->message = 'Could not decode the ID token. Please check the <a href="#debug">debug log</a> for errors.';
                    $test_result->more_info = '';
                }
                else {
                    $test_result->data = $this->id_token;

                    $request_service = Request_Service::get_instance();
                    $request = $request_service->get_request( $GLOBALS[ 'WPO_CONFIG' ][ 'request_id' ] );

                    // Store the Authorization Code in the Request
                    if ( isset( $_POST[ 'code' ] ) ) {
                        // Session valid until
                        $authorization_code = new \stdClass();
                        $authorization_code->expiry = time() + 3480;
                        $authorization_code->code = $_POST[ 'code' ];

                        $request->set_item( 'authorization_code', $authorization_code );

                        unset( $_POST[ 'code' ] );
                    }

                    $request->set_item( 'id_token', $this->id_token );
                }

                return $test_result;
            }

            public function test_id_token_contains_email() {
                $test_result = new Test_Result( 'ID token contains email address', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_CRITICAL );
                $test_result->passed = true;

                if ( empty( $this->id_token ) ) {
                    $test_result->passed = false;
                    $test_result->message = 'ID token missing -> test skipped';
                    $test_result->more_info = '';
                }
                elseif ( empty( $this->id_token->email ) ) {
                    $test_result->passed = false;
                    $test_result->message = "ID token does not contain email address. Please ensure that the user has a valid email address. If this is the case then please consult the online documentation and update the (Azure AD) App registration's manifest to include the optional 'email' claim.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_id_token_contains_upn() {
                $test_result = new Test_Result( 'ID token contains user principal name', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_CRITICAL );
                $test_result->passed = true;

                if ( empty( $this->id_token ) ) {
                    $test_result->passed = false;
                    $test_result->message = 'ID token missing -> test skipped';
                    $test_result->more_info = '';
                }
                elseif ( empty( $this->id_token->upn ) ) {
                    $test_result->passed = false;
                    $test_result->message = "ID token does not contain user principal name (upn). Please consult the online documentation and update the (Azure AD) App registration's manifest to include the optional 'upn' claim.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_id_token_contains_given_name() {
                $test_result = new Test_Result( 'ID token contains first name', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_LOW );
                $test_result->passed = true;

                if ( empty( $this->id_token ) ) {
                    $test_result->passed = false;
                    $test_result->message = 'ID token missing -> test skipped';
                    $test_result->more_info = '';
                }
                elseif ( empty( $this->id_token->given_name ) ) {
                    $test_result->passed = false;
                    $test_result->message = "ID token does not contain first name (given_name). Please consult the online documentation and update the (Azure AD) App registration's manifest to include the optional 'given_name' claim. Please note that the latest version of the plugin will try to retrieve a user's profile from Microsoft Graph to update the corresponding WordPress user instead.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_id_token_contains_family_name() {
                $test_result = new Test_Result( 'ID token contains last name', Test_Result::CAPABILITY_OIC_SSO, Test_Result::SEVERITY_LOW );
                $test_result->passed = true;

                if ( empty( $this->id_token ) ) {
                    $test_result->passed = false;
                    $test_result->message = 'ID token missing -> test skipped';
                    $test_result->more_info = '';
                }
                elseif ( empty( $this->id_token->family_name ) ) {
                    $test_result->passed = false;
                    $test_result->message = "ID token does not contain last name (family_name). Please consult the online documentation and update the (Azure AD) App registration's manifest to include the optional 'family_name' claim. Please note that the latest version of the plugin will try to retrieve a user's profile from Microsoft Graph to update the corresponding WordPress user instead.";
                    $test_result->more_info = 'https://docs.wpo365.com/article/22-sso';
                }

                return $test_result;
            }

            public function test_end() {

                if ( empty( $this->id_token ) ) {
                    return;
                }

                $request_service = Request_Service::get_instance();
                $this->request = $request_service->get_request( $GLOBALS[ 'WPO_CONFIG' ][ 'request_id' ] );
                $this->request->set_item( 'wpo_usr', User_Service::user_from_id_token( $this->id_token ) );
            }
        }
    }