<?php
namespace Wpo\Firebase;

class ExpiredException extends \UnexpectedValueException
{

}