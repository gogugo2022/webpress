<?php
namespace Wpo\Firebase;

class BeforeValidException extends \UnexpectedValueException
{

}