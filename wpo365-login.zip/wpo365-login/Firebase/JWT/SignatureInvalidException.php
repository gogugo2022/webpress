<?php
namespace Wpo\Firebase;

class SignatureInvalidException extends \UnexpectedValueException
{

}