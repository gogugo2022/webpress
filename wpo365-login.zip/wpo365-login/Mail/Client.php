<?php
    
    namespace Wpo\Mail;

    use \Wpo\Mail\Mailer;
    use \Wpo\Services\Graph_Service;
    use \Wpo\Services\Log_Service;
    use \Wpo\Services\Options_Service;
    
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die( );

    if ( !class_exists( '\Wpo\Mail\Client' ) ) {
    
        class Client {

            /**
             * 
             */
            public static function init( &$phpmailer ) {

                if ( !Options_Service::get_global_boolean_var( 'use_graph_mailer' ) ) {
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Not initializing the Graph Mailer because this feature has not been enabled' );
                    return;
                }

                $phpmailer_data = clone $phpmailer;
                $phpmailer = new Mailer();
                $phpmailer->phpmailer_data = $phpmailer_data;
            }

            /**
             * Sends an email using the app-only AAD app token. See 
             * https://developer.microsoft.com/en-us/graph/docs/api-reference/v1.0/api/user_sendmail
             * 
             * @since   11.7
             * 
             * @param   $to         string|array    Email address(es)
             * @param   $subject    string          Subject
             * @param   $content    string          Body
             * @param   $cc         string|array    Email address(es)
             *
             * @return  bool    True if successful otherwise false
             */
            public static function send( $to, $subject, $content, $cc = array(), $content_type = 'text/plain' ) {

                if ( !Options_Service::get_global_boolean_var( 'use_graph_mailer' ) ) {
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Not sending email because Graph Mailer has not been enabled' );
                    return false;
                }

                $_to = self::validate_email_addresses( $to, 'WARN' );

                if ( empty( $_to ) ) {
                    Log_Service::write_log( 'WARN', __METHOD__ . ' -> Not sending email because the recipient does not seem to be (a) valid email address(es) (check log for details)' );
                    return false;
                }

                $_cc = self::validate_email_addresses( $cc );

                $_reply_to = self::validate_email_addresses( Options_Service::get_global_string_var( 'mail_reply_to' ) );

                /**
                 * @since   15.0    Allow to send emails as text.
                 */
                $_content_type = $content_type != 'text/plain' && Options_Service::get_global_string_var( 'mail_mime_type' ) == 'Html' ? 'Html' : 'Text';

                $save_sent = Options_Service::get_global_boolean_var( 'mail_save_to_sent_items' );
                $mail_user = Options_Service::get_global_string_var( 'mail_from' );
                $message_as_json = self::email_message_encode( $subject, $_to, $content, $_cc, $_reply_to, $_content_type, $save_sent );
                $query = "/users/$mail_user/sendMail";
                $headers = array( 'Content-Type: application/json' );

                $message_sent_result = Graph_Service::fetch( $query, 'POST', false, $headers, false, false, $message_as_json, 'https://graph.microsoft.com/Mail.Send' );

                if ( Graph_Service::is_fetch_result_ok( $message_sent_result, 'Could not sent email message' ) ) {
                    Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Email sent successfully' );
                    return true;
                }

                return false;
            }

            /**
             * Sends a template based test mail to the mail address provided
             * 
             * @since   11.7
             * 
             * @param   $to         string|array    Email address(es)
             * 
             * @return  boolean     True if succesful otherwise false
             */
            public static function send_test_mail( $to ) {
                Log_Service::write_log( 'DEBUG', __METHOD__ . ' -> Sending test email to ' . is_string( $to ) ? $to : print_r( $to ) );
                $content_type = Options_Service::get_global_string_var( 'mail_mime_type' ) == 'Html' ? 'text/html' : 'text/plain';
                $template = $content_type == 'text/html' ? 'test-mail-html' : 'test-mail-text';

                ob_start();
                include( $GLOBALS[ 'WPO_CONFIG' ][ 'plugin_dir' ] . '/templates/' . $template . '.php' );
                $content = ob_get_clean();

                /**
                 * To test CC the user can enter john.doe@example.com|max.demo@example.com 
                 * and the latter will be sent the test email as CC
                 */

                $_to = $to;
                $_cc = array();

                if ( false !== strpos( $to, '|' ) ) {
                    $exploded = \explode( '|', $to );

                    if ( sizeof( $exploded ) == 2 && filter_var( $exploded[1], FILTER_VALIDATE_EMAIL ) ) {
                        $_cc[] = array( 'emailAddress' => array( 'address' => $exploded[1] ) ); 
                        $_to = $exploded[0];
                    }
                }

                $subject = '[' . wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES ) . '] Test email by WPO365 | LOGIN Graph Mailer';
                $result = self::send( $_to, $subject, $content, $_cc, $content_type );

                return $result;
            }

            /**
             * Validates email addresses passed as argument to the mail client's send method.
             * 
             * @since 11.7
             * 
             * @param   mixed   $email_addresses    single email address, comma separated email address, semi colon separated email address, WP / Graph formatted email address array
             * @param   string  $level              Level for debug log entries
             * 
             * @return  array   Array with valid email address that must checked if empty
             */
            private static function validate_email_addresses( $email_addresses, $level = 'DEBUG' ) {

                if ( empty( $email_addresses ) ) {
                    Log_Service::write_log( $level, __METHOD__ . ' -> Invalid email address found (empty)' );
                    return array();
                }

                // Array that will contain all email addresses after format validation
                $_email_addresses = array();

                /**
                 * @param   $unformatted    string  A single email address
                 * 
                 * @return  array   Assoc. array in the form WordPress provides and Graph expects it.
                 */
                $format = function ( $unformatted ) {
                    return array( 'emailAddress' => array( 'address' => $unformatted ) );
                };

                /**
                 * Handle the case of email address provided as a string
                 * 1. Single email address
                 * 2. Comma seperated email addresses
                 * 3. Semi colon separated email addresses
                 */ 
                if ( is_string( $email_addresses ) ) {

                    if ( stripos( $email_addresses, ',' ) !== false ) {
                        $delimited = \explode( ',', $email_addresses );

                        foreach ( $delimited as $_delimited ) {
                            $_email_addresses[] = $format( $_delimited );
                        }
                    }
                    elseif ( stripos( $email_addresses, ';' ) !== false ) {
                        $delimited = \explode( ';', $email_addresses );

                        foreach ( $delimited as $_delimited ) {
                            $_email_addresses[] = $format( $_delimited );
                        }
                    }
                    else {
                        $_email_addresses[] = $format( $email_addresses );
                    }
                }

                /**
                 * Handle the case of email address provided as an array
                 */
                elseif ( is_array( $email_addresses ) ) {
                    
                    foreach ( $email_addresses as $_email_address ) {

                        if ( isset( $_email_address[ 'emailAddress' ] ) && isset( $_email_address[ 'emailAddress' ][ 'address' ] ) ) {
                            $_email_addresses[] = $_email_address;
                            continue;
                        }
                        Log_Service::write_log( $level, __METHOD__ . ' -> Email address format invalid (check log for details)' );
                        Log_Service::write_log( 'DEBUG', $_email_address );
                    }
                }

                /**
                 * If format cannot be parsed then return an empty result
                 */
                else {
                    Log_Service::write_log( $level, __METHOD__ . ' -> Email address format not recognized (check log for details)' );
                    Log_Service::write_log( 'DEBUG', $email_addresses );
                }

                // Array that will contain all validated email addresses that will be returned
                $result = array();


                // Validate each email address
                foreach ( $_email_addresses as $_email_address ) {
                    
                    try {
                        if( !filter_var( $_email_address[ 'emailAddress' ][ 'address' ], FILTER_VALIDATE_EMAIL ) ) {
                            Log_Service::write_log( $level, __METHOD__ . ' -> Invalid email address found (' . $_email_address[ 'emailAddress' ][ 'address' ] . ')' );
                            continue;
                        }

                        $result[] = $_email_address;
                    }
                    catch( Exception $e ) {
                        Log_Service::write_log( $level, __METHOD__ . ' -> Invalid email address found (check log for details)' );
                        Log_Service::write_log( 'DEBUG', $_email_address );
                        continue;
                    }
                }
    
                return $result;
            }

            /**
             * 
             */
            private static function email_message_encode( $subject, $to, $content, $cc = array(), $reply_to = array(), $content_type = 'Text', $save_sent = false ) {

                $message = array(
                    'message' => array(
                        'subject' => $subject,
                        'body'    => array(
                            'contentType' => $content_type,
                            'content'     => $content,
                        ),
                        'toRecipients' => $to,
                    ),
                    'saveToSentItems' => $save_sent,
                );
    
                if ( !empty( $cc ) ) {
                    $message[ 'message' ][ 'ccRecipients' ] = $cc;
                }

                if ( !empty( $reply_to ) ) {
                    $message[ 'message' ][ 'replyTo' ] = $reply_to;
                }
    
                return json_encode( $message );
            }
        }
    }