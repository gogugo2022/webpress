<?php
    
    namespace Wpo\Mail;

    use \Wpo\Services\Log_Service;
    use \Wpo\Services\Options_Service;
    
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die( );

    if ( !class_exists( '\Wpo\Mail\Mailer' ) ) {
    
        class Mailer {

            public $phpmailer_data;

            public function send() {
                $to = array();
                $cc = array();

                foreach ( $this->phpmailer_data->getToAddresses() as $address ) {

                    if ( !is_array( $address ) || sizeof( $address ) != 2 ) {
                        continue;
                    }

                    $to[] = array( 'emailAddress' => array( 'address' => $address[ 0 ] ) );

                }

                foreach ( $this->phpmailer_data->getCcAddresses() as $address ) {

                    if ( !is_array( $address ) || sizeof( $address ) != 2 ) {
                        continue;
                    }

                    $cc[] = array( 'emailAddress' => array( 'address' => $address[ 0 ] ) );
                }

                return true == Client::send( $to, $this->phpmailer_data->Subject, $this->phpmailer_data->Body, $cc, $this->phpmailer_data->ContentType );
            }
        }
    }