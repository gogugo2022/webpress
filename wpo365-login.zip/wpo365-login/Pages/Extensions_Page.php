<?php
    
    namespace Wpo\Pages;

    use \Wpo\Core\Extensions_Helpers;
    use \Wpo\Services\Options_Service;
    use \Wpo\Services\Log_Service;
    
    // Prevent public access to this script
    defined( 'ABSPATH' ) or die( );

    if ( !class_exists( '\Wpo\Pages\Extensions_Page' ) ) {
    
        class Extensions_Page {

            private static $extensions = array();

            public function __construct() {
    
                /**
                 * Load custom updater.
                 */

                // Multisite frontend
                if ( is_multisite() && ! is_network_admin() ) {
                    return;
                }

                // Single site frontend
                if ( ! is_multisite() && ! is_admin() ) {
                    return;
                }

                // Collect information about all available extensions
                self::$extensions = Extensions_Helpers::get_extensions( true );

                // No extensions so no need to add the extension page
                if ( empty( self::$extensions ) ) {
                    return;
                }
        
                /**
                 * Add admin page.
                 */
                add_action( 'admin_menu', '\Wpo\Pages\Extensions_Page::extensions_menu' );
                add_action( 'network_admin_menu', '\Wpo\Pages\Extensions_Page::extensions_menu' );
            }
        
            /**
             * Adds a "Licenses" submenu page to the main WPO365 admin menu.
             */
            public static function extensions_menu() {
                add_submenu_page( 'wpo365-wizard', 'Extensions', 'Extensions', 'delete_users', 'wpo365-extensions', '\Wpo\Pages\Extensions_Page::extensions_page' );
            }
        
            public static function extensions_page() { 
                ?>
                <style>
                    .wpo365-extensions-table {
                        background: #ffffff; 
                        border: 1px solid #cccccc;
                        box-sizing: border-box;
                        float: left; 
                        margin: 0 15px 15px 0; 
                        max-width: 350px; 
                        min-height: 550px; 
                        padding: 14px; 
                        position: relative;
                        position: relative; 
                        width: 30.5%; 
                    }
                    .wpo365-extensions-table TH {
                        background-color: #f9f9f9;
                        border-bottom: 1px solid #cccccc;
                        display: block;
                        margin: -14px -14px 20px;
                        padding: 14px; 
                        width: 100%;
                    }
                    .wpo365-extensions-table TD {
                        display: block;
                        padding: 0;
                    }
                    .wpo365-extensions-table TD P {
                        padding-bottom: 20px;
                    }
                    .wpo365-extensions-table TD .wpo365-extensions-heading {
                        font-weight: 500;
                        font-size: 13px;
                    }
                    .wpo365-extensions-table TD .wpo365-extensions-feature {
                        font-size: 13px;
                    }
                    .wpo365-extensions-table TD .wpo365-extensions-feature span {
                        font-weight: 500;
                    }
                    .wpo365-extensions-table TD DIV {
                        background: #fafafa;
                        border-top: 1px solid #eeeeee;
                        bottom: 14px;
                        box-sizing: border-box;
                        margin: 20px -14px -14px;
                        min-height: 67px;
                        padding: 14px;
                        position: absolute;
                        width: 100%;
                    }
                </style>
                <div class="wrap">
                    <h2 style="font-size: 23px; font-weight: 400;"><?php _e('WPO365 | Extensions'); ?></h2>
                    <table class="form-table">
                        <tbody>
                            <?php foreach( self::$extensions as $slug => $data ) : 
                                  if ( $data[ 'type' ] != 'extension' ) continue; ?>
                                <tr valign="top" class="wpo365-extensions-table">
                                    <th scope="row" valign="top">
                                        <?php echo $data[ 'store_item' ] ?>
                                    </th>
                                    <td>
                                        <?php foreach( $data[ 'features' ] as $feature) : ?>
                                        <p class="wpo365-extensions-feature"><span><?php echo $feature[0] ?></span>&nbsp;|&nbsp;<?php echo $feature[1]; if ( ! empty( $feature[2] ) ) : ?>&nbsp;<a href="<?php echo $feature[2] ?>">more</a><?php endif ?></p>
                                        <?php endforeach ?>
                                        <div>
                                            <?php if ( $data[ 'activated' ] ) : ?>
                                                Installed
                                            <?php else : ?>
                                                <input type="button" class="button-secondary" value="<?php _e('Details and pricing'); ?>" onclick="window.open('<?php echo $data[ 'store_url' ] ?>', '_blank')"/>
                                            <?php endif ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                    <h2 style="font-size: 23px; font-weight: 400;"><?php _e('WPO365 | Bundles'); ?></h2>
                    <table class="form-table">
                        <tbody>
                            <?php foreach( self::$extensions as $slug => $data ) : 
                                  if ( $data[ 'type' ] != 'bundle' ) continue; ?>
                                <tr valign="top" class="wpo365-extensions-table" style="min-height: 900px;">
                                    <th scope="row" valign="top">
                                        <?php echo $data[ 'store_item' ] ?>
                                    </th>
                                    <td>
                                    <?php foreach( $data[ 'features' ] as $feature) : ?>
                                        <p class="wpo365-extensions-feature"><span><?php echo $feature[0] ?></span>&nbsp;|&nbsp;<?php echo $feature[1]; if ( ! empty( $feature[2] ) ) : ?>&nbsp;<a href="<?php echo $feature[2] ?>">more</a><?php endif ?></p>
                                        <?php endforeach ?>
                                        <div>
                                            <?php if ( $data[ 'activated' ] ) : ?>
                                                Installed
                                            <?php else : ?>
                                                <input type="button" class="button-secondary" value="<?php _e('Details and pricing'); ?>" onclick="window.open('<?php echo $data[ 'store_url' ] ?>', '_blank')"/>
                                            <?php endif ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                    <h2 style="font-size: 23px; font-weight: 400;"><?php _e('WPO365 | Passes'); ?></h2>
                    <table class="form-table">
                        <tbody>
                            <tr valign="top" class="wpo365-extensions-table" style="min-height: 300px;">
                                <th scope="row" valign="top">Enterprise Access Pass</th>
                                <td><p>The Enterprise Access Pass grants you a master license key that you can use to download any extension and activate it on up to 50 different WordPress sites.</p>
                                    <div>
                                        <input type="button" class="button-secondary" value="<?php _e('Details and pricing'); ?>" onclick="window.location.href='https://www.wpo365.com/downloads/enterprise-access-pass/'"/>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                <?php
            }
        }
    }