<?php
/**
 * The template used for displaying credits
 *
 * @package Kids_Camp
 */
?>

<?php
/**
 * kids_camp_credits hook
 * @hooked kids_camp_footer_content - 10
 */
do_action( 'kids_camp_credits' );
