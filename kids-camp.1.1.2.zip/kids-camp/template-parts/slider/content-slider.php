<?php
/**
 * The template used for displaying slider
 *
 * @package Kids_Camp
 */
?>

<?php
/**
 * kids_camp_slider hook
 * @hooked kids_camp_slider - 10
 */
do_action( 'kids_camp_slider' );
