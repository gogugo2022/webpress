 <script>
 import Navbar from './Navbar.svelte';
 import Link from './Link.svelte';
 </script>
 
 <Navbar>
    <Link path="/configuration" text={"Pages"}></Link>
    <Link path="/settings" text={"Settings"}></Link>
 </Navbar>