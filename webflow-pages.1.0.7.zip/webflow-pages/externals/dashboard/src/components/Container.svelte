<style>
div {
    width: 100%;
    max-width: 90%;
    margin-right: auto;
    margin-left: auto;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>

<div>
    <slot></slot>
</div>