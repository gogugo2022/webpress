<style>
.footer {
    position: absolute;
    bottom: 12px;
    width: 100%;
    text-align: center;
}
a {
    color: #4253ff;
}
</style>

<div class="footer">
    <a href="https://university.webflow.com/" target="_blank" rel="nofollow">Need support?</a>
</div>