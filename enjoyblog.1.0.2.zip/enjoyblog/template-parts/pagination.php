<?php 
	the_posts_pagination(array('prev_text' => esc_html('Previous','enjoyblog'),'next_text' => esc_html('Next','enjoyblog')));