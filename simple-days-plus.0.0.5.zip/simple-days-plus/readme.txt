=== Simple Days Plus ===
Contributors: back2nature
Requires at least: 4.9
Tested up to: 5.8
Requires PHP: 5.3
Version: 0.0.5
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Template: simple-days
Text Domain: simple-days-plus
Tags: custom-background, custom-colors, custom-logo, custom-menu, editor-style, featured-image-header, featured-images, flexible-header, footer-widgets, one-column, post-formats, right-sidebar, sticky-post, theme-options, threaded-comments, three-columns, translation-ready, two-columns, blog

== Description ==
Simple Days Plus is a child theme of Simple Days.Simple Days is a free responsive WordPress Blog theme.Visitors arrive by any devices.I designed it using a mobile-first approach.It is thus possible to improve usability of the smartphone.And of course, other devices is responsive.Moreover,you can also edit the design using its customizer.Google Fonts is 800 over.Right or Left or No sidebar.Gutenberg ready.Translation ready and currently translated in Japanese(���{��).If you use plugin of YAHMAN Add-ons, you can Page views,Google Adsense,Analytics,Social,Profile,Table of contents,Related Posts,sitemap,SEO,JSON-LD structured data,Open Graph protocol(OGP),Blog card,Twitter timeline,Facebook timeline,Carousel Slider.Let's try it.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Simple Days Plus in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.

== Copyright ==

Simple Days WordPress Theme, Copyright 2018 YAHMAN
Simple Days is distributed under the terms of the GNU GPL

Simple Days Plus WordPress Theme, Copyright 2018 YAHMAN
Simple Days Plus is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Simple Days Plus Theme bundles the following third-party resources:

screenshot image credits 1/5
https://stocksnap.io/photo/nature-beach-I77JDV8AZQ
License: Creative Commons CC0 (https://stocksnap.io/license)
Copyright: frank mckenna (https://stocksnap.io/author/34618)

screenshot image credits 2/5
https://stocksnap.io/photo/woman-girl-9CUBLPT1GC
License: Creative Commons CC0 (https://stocksnap.io/license)
Copyright: Blake Moulton (https://stocksnap.io/author/32859)

screenshot image credits 3/5
https://stocksnap.io/photo/happy-blacklabrador-AOSAX9RXJA
License: Creative Commons CC0 (https://stocksnap.io/license)
Copyright: Helena Lopes (https://stocksnap.io/author/helenalopes)

screenshot image credits 4/5
https://stocksnap.io/photo/woman-walking-TXPPZXZIKL
License: Creative Commons CC0 (https://stocksnap.io/license)
Copyright: Matt Bango (https://stocksnap.io/author/mattbangophotos)

screenshot image credits 5/5
https://stocksnap.io/photo/female-monochrome-NN4QREVJQZ
License: Creative Commons CC0 (https://stocksnap.io/license)
Copyright: Matt Moloney (https://stocksnap.io/author/mattmoloney)

== Changelog ==

= 0.0.5 =
* Released: October 14, 2021
fixed screenshot and credit.

= 0.0.4 =
* Released: January 28, 2019
fixed css file.

= 0.0.3 =
* Released: August 31, 2018
fixed functions file.

= 0.0.2 =
* Released: August 31, 2018
fixed text file.

= 0.0.1 =
* Released: August 25, 2018

Initial release
