<?php

class Youzify_Gamipress_Profile_User_Badges_Widget {

    /**
     * Widget Content.
     */
    function widget() {
        do_action( 'youzify_gamipress_user_badges_widget_content' );
    }

}