<div class="subnav-filters filters no-ajax" id="subnav-filters">
    <div class="subnav-search clearfix">
        <div class="dir-search activity-search bp-search">
            <form action="" method="get" class="bp-dir-search-form" id="dir-activity-search-form" role="search">
                <label for="dir-activity-search" class="bp-screen-reader-text">Search Activity...</label>
                <input id="dir-activity-search" name="activity_search" type="search" placeholder="Search Activity...">
                <button type="submit" id="dir-activity-search-submit" class="nouveau-search-submit"
                        name="dir_activity_search_submit">
                    <span class="dashicons dashicons-search" aria-hidden="true"></span>
                    <span id="button-text" class="bp-screen-reader-text">Search</span>
                </button>
            </form>
        </div>
    </div>
</div>
