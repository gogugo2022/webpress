<nav class="activity-type-navs main-navs bp-navs dir-navs " role="navigation" aria-label="Directory menu">
    <ul class="component-navigation activity-nav">
        <li id="activity-all" class="dynamic selected">
            <a href="#">
                All Updates
            </a>
        </li>

        <li id="activity-favorites" class="">
            <a href="#">
                Likes
            </a>
        </li>
    </ul>
</nav>