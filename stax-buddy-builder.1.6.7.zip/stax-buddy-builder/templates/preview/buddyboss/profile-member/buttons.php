<div class="member-header-actions action">
    <div class=" friendship-button not_friends generic-button">
        <button class="friendship-button not_friends add" rel="add">
            Connect
        </button>
    </div>
    <div class=" friendship-button pending_friend generic-button">
        <button class="friendship-button pending_friend requested" rel="remove">Cancel connection request</button>
    </div>
    <div class="friendship-button is_friend generic-button">
        <button id="friend-10" class="friendship-button is_friend remove" rel="remove">Connected</button>
    </div>
    <div id="post-mention" class="generic-button">
        <a href="#" class="activity-button mention">
            Message
        </a>
    </div>
</div>
