<nav class="main-navs no-ajax bp-navs single-screen-navs horizontal groups-nav" id="object-nav" role="navigation"
	 aria-label="Group menu">
	<ul>
		<li id="activity-groups-li" class="bp-groups-tab current selected">
			<a href="#" id="activity">
				Feed
			</a>
		</li>
        <li id="members-groups-li" class="bp-groups-tab">
			<a href="#" id="members">
				Members
				<span class="count">2</span>
			</a>
		</li>
        <li id="nav-forum-groups-li" class="bp-groups-tab">
            <a href="#" id="nav-forum">
                Discussions
            </a>
        </li>
		<li id="invite-groups-li" class="bp-groups-tab">
			<a href="#" id="invite">
				Send Invite
			</a>
		</li>
        <li id="group-messages-groups-li" class="bp-groups-tab">
            <a href="#" id="group-messages">
                Send Messages
            </a>
        </li>
        <li id="photos-groups-li" class="bp-groups-tab">
            <a href="#" id="photos">
                Photos
            </a>
        </li>
        <li id="albums-groups-li" class="bp-groups-tab">
            <a href="#" id="albums">
                Albums
            </a>
        </li>
		<li id="admin-groups-li" class="bp-groups-tab">
			<a href="#" id="admin">
				Manage
			</a>
		</li>
	</ul>
</nav>
