<?php

if ( ! isset( $content ) ) {
	$content = '';
}

?>

<div id="buddypress" class="buddypress-wrap bp-dir-hori-nav">
	<?php echo $content; ?>
</div>
