<nav class="members-type-navs main-navs bp-navs dir-navs " role="navigation" aria-label="Directory menu">
    <ul class="component-navigation members-nav">
        <li id="members-all" class="selected">
            <a href="#">
                All Members
                <span class="count">20</span>
            </a>
        </li>
        <li id="friends-all">
            <a href="#">
                Friends
                <span class="count">3</span>
            </a>
        </li>
    </ul>
</nav>
