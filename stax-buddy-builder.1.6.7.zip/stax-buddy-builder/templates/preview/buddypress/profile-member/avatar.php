<div class="elementor-image-bpb-avatar">
	<a href="#">
		<img src="<?php echo esc_url( bpb_get_dummy_avatar_url( 'member' ) ); ?>"
			 class="avatar user-10-avatar avatar-150 photo" width="150" height="150"
			 alt="Profile picture of Matraca Berg">
	</a>
</div>
