<div class="member-header-actions action">
    <div class=" friendship-button not_friends generic-button">
        <button class="friendship-button not_friends add" rel="add">
            Add Friend
        </button>
    </div>
    <div class=" friendship-button pending_friend generic-button">
        <button class="friendship-button pending_friend requested" rel="remove">Cancel Friendship Request</button>
    </div>
    <div class="friendship-button is_friend generic-button">
        <button id="friend-10" class="friendship-button is_friend remove" rel="remove">Cancel Friendship</button>
    </div>
    <div id="post-mention" class="generic-button">
        <a href="#" class="activity-button mention">
            Public Message
        </a>
    </div>
    <div id="send-private-message" class="generic-button">
        <a href="#" class="send-message">
            Private Message
        </a>
    </div>
</div>
