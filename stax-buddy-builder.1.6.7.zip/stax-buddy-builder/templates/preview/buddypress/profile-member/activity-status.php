<div id="item-meta">
    <div id="latest-update">
        The fundamental cause of trouble in the world is that the stupid are cocksure while the intelligent are full of
        doubt. (Bertrand Russell) <a href="#" rel="nofollow">View</a>
    </div>
</div>
