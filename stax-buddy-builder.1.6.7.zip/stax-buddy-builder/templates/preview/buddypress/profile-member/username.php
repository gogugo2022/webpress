<h2 class="user-nicename">
	<?php if ( $username_type === 'full_name' ) : ?>
        John Doe
	<?php else : ?>
        @john-doe
	<?php endif; ?>

</h2>
