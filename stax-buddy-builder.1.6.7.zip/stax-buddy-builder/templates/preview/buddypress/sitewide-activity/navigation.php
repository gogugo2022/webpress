<nav class="activity-type-navs main-navs bp-navs dir-navs " role="navigation" aria-label="Directory menu">
    <ul class="component-navigation activity-nav">
        <li id="activity-all" class="dynamic selected">
            <a href="#">
                All Members
                <span class="count">230</span>
            </a>
        </li>
        <li id="activity-groups" class="dynamic">
            <a href="#">
                My Groups
                <span class="count">4</span>
            </a>
        </li>
        <li id="activity-favorites" class="">
            <a href="#">
                My Favorites
            </a>
        </li>
        <li id="activity-mentions" class="dynamic">
            <a href="#">
                Mentions
                <span class="count">10</span>
            </a>
        </li>
    </ul>
</nav>
