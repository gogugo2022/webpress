<div class=" groups-meta action">
    <div id="groupbutton-1" class="generic-button">
        <button class="group-button join-group button">
            Join Group
        </button>
    </div>
    <div id="groupbutton-2" class="generic-button">
        <button class="group-button leave-group button">
	        Leave Group
        </button>
    </div>
    <div id="groupbutton-21" class="generic-button">
        <button class="group-button request-membership button">
            Request Membership
        </button>
    </div>
    <div id="groupbutton-12" class="generic-button">
        <button class="group-button pending membership-requested button">
            Request Sent
        </button>
    </div>
    <div id="groupbutton-13" class="generic-button">
        <button class="button">
            General Button
        </button>
    </div>
</div>
