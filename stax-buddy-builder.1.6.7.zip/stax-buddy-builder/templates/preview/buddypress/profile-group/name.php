<div class="bpb-group-name">
	My Group Name
</div>
