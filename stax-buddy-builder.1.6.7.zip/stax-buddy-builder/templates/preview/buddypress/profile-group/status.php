<p class="highlight group-status">
    Public Group
</p>
