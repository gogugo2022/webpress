<div id="item-header-avatar">
	<a href="#" title="Demo group">
		<img src="<?php echo esc_url( bpb_get_dummy_avatar_url( 'group' ) ); ?>"
			 class="avatar group-1-avatar avatar-150 photo" width="150" height="150" alt="Group logo of Demo group">
	</a>
</div>
