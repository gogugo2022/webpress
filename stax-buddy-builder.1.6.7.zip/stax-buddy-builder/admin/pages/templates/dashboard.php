<div class="ste-mt-5">
    <h3>Welcome to BuddyBuilder, your complete BuddyPress customization tool.</h3>

    YOUTUBE VIDEO HERE
</div>
