<h2 class="ste-my-0 ste-leading-none ste-text-2xl ste-text-gray-700 ste-font-bold ste-tracking-wide">
	<?php esc_html_e( 'Help', 'stax-buddy-builder' ); ?>
</h2>

<div class="ste-mt-5">
	<div class="ste-flex ste-flex-wrap ste--mx-2">
		<div class="ste-my-2 ste-w-full md:ste-w-1/2 lg:ste-w-1/3 xl:ste-w-1/4">
			<div class="ste-mx-2">
				// help
			</div>
		</div>
	</div>
</div>
