<?php

$title = apply_filters( 'es_search_property_page_title',  __( 'Search properties', 'es-plugin' ) );

es_load_template( 'archive-properties.php' );
