# Contributing to Firebase WordPress Plugin

Thank you for your interest in contributing back to Firebase WordPress Plugin. Please help us review your issues and/or merge your pull requests.

+ Thanks [kurozumi](https://github.com/kurozumi) for adding the credentials.
