<div class="wrap">
    <hr class="wp-header-end">
    <div class="easy-page-body">
        <main class="content-area">
            <?php include( EASYJOBS_ADMIN_DIR_PATH .'/partials/easyjobs-admin-header.php');?>
            <!-- content body -->
            <div class="content-area__body">
                <div id="easyjobs-react"></div>
            </div>
        </main>
    </div>
</div>