<?php

class Youzify_Profile_Website_Info_Box_Widget extends Youzify_Profile_Info_Box_Widget {

}