<?php

class Youzify_Profile_Phone_Info_Box_Widget extends Youzify_Profile_Info_Box_Widget {

}