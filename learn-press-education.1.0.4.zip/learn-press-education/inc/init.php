<?php

require_once (get_stylesheet_directory(  ). '/inc/learn-press-functions.php');
require_once (get_stylesheet_directory(  ). '/inc/sections-hooks.php');
require_once (get_stylesheet_directory(  ). '/inc/customizer.php');
require_once (get_stylesheet_directory(  ). '/inc/dynamic.php');