<?php
/**
 * Template Name: Home Page
 *
 * @package corporate-one
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header(); ?>
<?php Responsive\responsive_wrapper_top(); // before wrapper content hook. ?>
<div id="wrapper" class="site-content clearfix">
	<div class="content-outer container">
		<div class="row">
			<?php Responsive\responsive_in_wrapper(); // wrapper hook. ?>
			<main id="primary" class="content-area corporate-home" role="main">
				<?php
				/*====fetch options =============*/

				// banner.
				$corporate_one_enable_banner_section = get_theme_mod( 'corporate_one_enable_banner_section', 1 );
				// about.
				$corporate_one_enable_about_section = get_theme_mod( 'corporate_one_enable_about_section', 1 );
				// services.
				$corporate_one_enable_services_section = get_theme_mod( 'corporate_one_enable_services_section', 1 );
				// experience.
				$corporate_one_enable_experience_section = get_theme_mod( 'corporate_one_enable_experience_section', 1 );
				// testimonial.
				$corporate_one_enable_testimonial_section = get_theme_mod( 'corporate_one_enable_testimonial_section', 1 );
				// contact.
				$corporate_one_enable_contact_section = get_theme_mod( 'corporate_one_enable_contact_section', 1 );

				if ( $corporate_one_enable_banner_section ) {
				    get_template_part( 'template-parts/banner' );
				}
				if ( $corporate_one_enable_about_section ) {
                    get_template_part( 'template-parts/about' );
				}
				if ( $corporate_one_enable_services_section ) {
                    get_template_part( 'template-parts/services' );
				}
				if ( $corporate_one_enable_experience_section ) {
                    get_template_part( 'template-parts/experience' );
				}
				if ( $corporate_one_enable_testimonial_section ) {
                    get_template_part( 'template-parts/testimonial' );
				}
				if ( $corporate_one_enable_contact_section ) {
                    get_template_part( 'template-parts/contact' );
				}
				?>
				</main><!-- end of #content-full -->
			</div>
		</div>
		<?php Responsive\responsive_wrapper_bottom(); // after wrapper content hook. ?>
	</div> <!-- end of #wrapper -->
	<?php Responsive\responsive_wrapper_end(); // after wrapper hook. ?>
	<?php get_footer(); ?>
