<?php
/**
 * Corporate One functions and definitions.
 *
 * @link
 *
 * @package corporate-one
 */

namespace Corporate\Core;

/**
 * [require description]
 *
 * @var [type]
 */

require_once get_stylesheet_directory() . '/inc/customizer.php';
require_once get_stylesheet_directory() . '/inc/custom-functions.php';

/**
 * Enqueue scripts and styles
 */
function enqueue() {

	// Load library for jcarousel.
	wp_enqueue_script( 'jcarousel', get_stylesheet_directory_uri() . '/lib/jquery.jcarousel.min.js', array( 'jquery' ), '1.0' );
	if ( is_front_page() ) {
		wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri() . '/lib/bootstrap.min.css', false, '3.3.7' );
	}
	wp_enqueue_script( 'bootstrap-js', get_stylesheet_directory_uri() . '/lib/bootstrap.min.js', array( 'jquery' ), '3.3.7', true );

	$parent_style = 'responsive-style';

	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/core/css/style.css' );
	wp_enqueue_style(
		'corporate-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( $parent_style ),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'Corporate\Core\enqueue', 99 );
require get_stylesheet_directory() . '/custom-corporate-styles.php';

/**
 * Function to register multiple checkboxes option
 */
function one_load_customize_controls() {
	require_once get_stylesheet_directory() . '/inc/customizer.php';
}
add_action( 'customize_register', 'Corporate\Core\one_load_customize_controls', 0 );

/**
 * [remove_customizer_tooltip_actions description]
 *
 * @return void [description].
 */
function remove_customizer_tooltip_actions() {
	remove_action( 'customize_controls_print_scripts', 'Responsive\Customizer\responsive_tooltip_script' );
}
add_action( 'init', 'Corporate\Core\remove_customizer_tooltip_actions' );

/**
 * This function overrides customizer defaults of Responsive theme
 *
 * @param array $theme_options Theme Options.
 * @return mixed
 */
function override_theme_defaults( $theme_options ) {
	$theme_color = get_theme_mod( 'corporate_theme_color', '#82b440' );

	$theme_options['header_background']                   = 'rgba(17,17,17,.9)';
	$theme_options['header_menu_link']                    = '#ffffff';
	$theme_options['header_menu_link_hover']              = $theme_color;
	$theme_options['header_active_menu_background']       = 'transparent';
	$theme_options['header_menu_toggle']                  = '#888';
	$theme_options['header_site_title']                   = '#ffffff';
	$theme_options['header_text']                         = '#ffffff';
	$theme_options['body_text']                           = '#575b66';
	$theme_options['shop_product_price']                  = $theme_color;
	$theme_options['button']                              = $theme_color;
	$theme_options['button_hover']                        = $theme_color;
	$theme_options['button_hover_text']                   = '#0066CC';
	$theme_options['add_to_cart_button']                  = $theme_color;
	$theme_options['scroll_to_top_icon']                  = '#fff';
	$theme_options['scroll_to_top_icon_hover']            = '#fff';
	$theme_options['scroll_to_top_icon_background']       = $theme_color;
	$theme_options['scroll_to_top_icon_background_hover'] = $theme_color;
	$theme_options['theme']                               = $theme_color;

	$theme_options['box_padding']      = 0;
	$theme_options['entry_columns']    = 2;
	$theme_options['buttons_radius']   = 20;
	$theme_options['background_color'] = '#fff';

	return $theme_options;
}
add_filter( 'responsive_theme_defaults', 'Corporate\Core\override_theme_defaults', 10, 1 );

/**
 * This function overrides responsive_theme_footer_link filter
 *
 * @param $footer_link
 */
function get_footer_link( $footer_link ) {
	$footer_link = esc_url( 'https://cyberchimps.com/wordpress-themes/corporate/' );

	return $footer_link;
}
add_filter( 'responsive_theme_footer_link', 'Corporate\Core\get_footer_link', 10, 1 );

/**
 * This function overrides responsive_theme_footer_link_text filter
 *
 * @param $footer_link_text
 */
function get_footer_link_text( $footer_link_text ) {
	$footer_link_text = esc_html__( ' | Powered by Corporate One', 'corporate-one' );

	return $footer_link_text;
}
add_filter( 'responsive_theme_footer_link_text', 'Corporate\Core\get_footer_link_text', 10, 1 );

/**
 * This function overrides responsive_blog_single_elements_positioning filter
 *
 * @param array $sections Sections.
 */
function override_blog_single_elements_positioning( $sections ) {
	$sections = array( 'featured_image', 'meta', 'title', 'content' );

	return $sections;
}
add_filter( 'responsive_blog_single_elements_positioning', 'Corporate\Core\override_blog_single_elements_positioning', 10, 1 );

/**
 * This function overrides responsive_blog_entry_elements_positioning filter
 *
 * @param array $sections Sections.
 */
function override_blog_elements_positioning( $sections ) {
	$sections = array( 'featured_image', 'title', 'meta', 'content' );

	return $sections;
}
add_filter( 'responsive_blog_entry_elements_positioning', 'Corporate\Core\override_blog_elements_positioning', 10, 1 );

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook
 */
function corporate_one_theme_support() {
	/*
	 * Adds starter content to highlight the theme on fresh sites.
	 * This is done conditionally to avoid loading the starter content on every
	 * page load, as it is a one-off operation only needed once in the customizer.
	 */
	if ( is_customize_preview() ) {
		require __DIR__ . '/inc/starter-content.php';
		add_theme_support( 'starter-content', corporate_one_get_starter_content() );
	}

}

add_action( 'after_setup_theme', 'Corporate\Core\corporate_one_theme_support', 20 );

/**
 *   [corporateone_remove_responsive_theme_ask_for_review description].
 *
 *   @return void [description]
 */
function corporateone_remove_responsive_theme_ask_for_review() {
	remove_action( 'admin_notices', 'Responsive\Admin\\responsive_ask_for_review_notice' );
	remove_action( 'admin_init', 'Responsive\Admin\\responsive_theme_notice_dismissed' );
	remove_action( 'admin_init', 'Responsive\Admin\\responsive_theme_notice_change_timeout' );
}
add_action( 'init', 'Corporate\Core\corporateone_remove_responsive_theme_ask_for_review' );

function corporateone_ask_for_review_notice() {

	if ( isset( $_GET['page'] ) && 'responsive' === $_GET['page'] ) {
		return;
	}

	if ( false === get_option( 'corporateone-theme-old-setup' ) ) {
		set_transient( 'corporateone_theme_ask_review_flag', true, MONTH_IN_SECONDS );
		update_option( 'corporateone-theme-old-setup', true );
	} elseif ( false === get_transient( 'corporateone_theme_ask_review_flag' ) && false === get_option( 'corporateone_theme_review_notice_dismissed' ) ) {

		$image_path = get_theme_file_uri() . '/images/corporate.jpg';
		echo sprintf(
			'<div class="notice notice-warning ask-for-review-notice">
             					<div class="notice-image">
									<img src="%1$s" class="custom-logo" alt="Corporate One" itemprop="logo">
								</div>
								<div class="notice-content">
									<div class="notice-heading">
										%3$s
									</div>
									%4$s<br />
									<div class="responsive-review-notice-container">
										<a href="%2$s" class="responsive-notice-close responsive-review-notice button-primary" target="_blank">
										%5$s
										</a>
										<span class="dashicons dashicons-calendar"></span>
										<a href="?corporateone-theme-review-notice-change-timeout=true" data-repeat-notice-after="60" class="responsive-notice-close responsive-review-notice">
										%6$s
										</a>
										<span class="dashicons dashicons-smiley"></span>
										<a href="?corporateone-theme-review-notice-dismissed=true" class="responsive-notice-close responsive-review-notice">
										%7$s
										</a>
									</div>
								</div>
								<div>
									<a href="?corporateone-theme-review-notice-dismissed=true">Dismiss</a>

								</div>
         					</div>',
			esc_url( $image_path ),
			'https://wordpress.org/support/theme/corporate-one/reviews/#new-post',
			__( 'Hi! Thanks for using the Corporate One theme.', 'corporate-one' ),
			__( 'Can you please do us a favor and give us a 5-star rating? Your feedback keeps us motivated and helps us grow the Corporate One community.', 'corporate-one' ),
			__( 'Ok, you deserve it', 'corporate-one' ),
			__( 'Nope, maybe later', 'corporate-one' ),
			__( 'I already did', 'corporate-one' )
		);
		do_action( 'tag_review' );
	}

}
add_action( 'admin_notices', ( 'Corporate\Core\corporateone_ask_for_review_notice' ) );

/**
 * Removed Ask For Review Admin Notice when dismissed.
 */
function corporateone_theme_notice_dismissed() {
	if ( isset( $_GET['corporateone-theme-review-notice-dismissed'] ) ) {
		update_option( 'corporateone_theme_review_notice_dismissed', true );
		wp_safe_redirect( remove_query_arg( array( 'corporateone-theme-review-notice-dismissed' ), wp_get_referer() ) );
	}
}
add_action( 'admin_init', ( 'Corporate\Core\corporateone_theme_notice_dismissed' ) );

/**
 * Removed Ask For Review Admin Notice when dismissed.
 */
function corporateone_theme_notice_change_timeout() {
	if ( isset( $_GET['corporateone-theme-review-notice-change-timeout'] ) ) {
		set_transient( 'corporateone_theme_ask_review_flag', true, DAY_IN_SECONDS );
		wp_safe_redirect( remove_query_arg( array( 'corporateone-theme-review-notice-change-timeout' ), wp_get_referer() ) );
	}
}
add_action( 'admin_init', ( 'Corporate\Core\corporateone_theme_notice_change_timeout' ) );
