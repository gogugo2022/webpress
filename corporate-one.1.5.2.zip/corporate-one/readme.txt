Corporate One - Responsive WordPress Theme 
================================================
Contributors: cyberchimps
Requires at least: 5.0
Tested up to: 5.4.2
Requires PHP: 5.6
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

- Corporate One, Copyright 2017
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v3.0 - http://www.gnu.org/licenses/gpl-3.0.html

- Bootstrap
- Adds core styles and responsive structure
- by Twitter Bootstrap http://getbootstrap.com
- licensed under MIT - https://github.com/twitter/bootstrap/blob/master/LICENSE

- Images
- https://unsplash.com/photos/IegYaCY101s

- Isotope JS
- http://isotope.metafizzy.co
- Licensed GPLv3 for open source use

- JQuery Easing
- http://gsgd.co.uk/sandbox/jquery/easing/
- Open source under the BSD License.

- jQuery Validation Plugin
- http://jqueryvalidation.org/
- Licensed under the MIT license - http://opensource.org/licenses/MIT 

- animate.css
- http://daneden.me/animate
- Licensed under the MIT license - http://opensource.org/licenses/MIT
- Copyright (c) 2016 Daniel Eden

- Font Awesome 4.7.0 by @davegandy
- http://fontawesome.io
- License - http://fontawesome.io/license

- Roboto Slab Font by Christian Robertson
- https://fonts.google.com/specimen/Roboto+Slab
- License: Apache License, version 2.0 (http://www.apache.org/licenses/LICENSE-2.0.html)

- Playball Font by TypeSETit
- https://fonts.google.com/specimen/Playball
- License: Open Font License

- jCarousel
- adds the responsive Carousel
- by Sorgalla http://sorgalla.com/jcarousel/
- dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.

- Slimbox
- adds the lightbox we use in Portfolio etc
- by Digitalia http://www.digitalia.be/software/slimbox
- licensed under the MIT license - http://www.opensource.org/licenses/mit-license.php

- Retina.js v1.1.0
- adds the ability to load HD images to devices that can display them
- Copyright 2013 Imulus, LLC
- licensed under the MIT license

- Glyphicons
- fonticons for arrows, visual links etc
- by Twitter Bootstrap http://getbootstrap.com
- licensed under MIT - https://github.com/twitter/bootstrap/blob/master/LICENSE

- All other images
- by CyberChimps http://cyberchimps.com
- Licensed under GNU General Public License v3.0 - http://www.gnu.org/licenses/gpl-3.0.html

= Images =
* CharityPure: /images/corporate-about.jpg, CC0, https://stocksnap.io/photo/boardroom-business-KCIU8RWM09
* Responsive: /images/corporatebg.jpg, CC0, https://stocksnap.io/photo/glasses-desk-LE1W2B7R93
* Responsive: /images/corporatebg1.jpg, CC0, https://stocksnap.io/photo/laptop-typing-YBKJ1G35EX
* Responsive: /images/corporatebg2.jpg, CC0, https://stocksnap.io/photo/computer-office-XGXORJWZIX
* Responsive: /images/corporatebg3.jpg, CC0, https://stocksnap.io/photo/man-work-DZ7DC58DSV
* Responsive: /images/corporatebg4.jpg, CC0, https://stocksnap.io/photo/seo-serpstat-HQV6HVSTAW
* Responsive: /images/corporatebg5.jpg, CC0, https://stocksnap.io/photo/computer-office-XGXORJWZIX
* Responsive: /images/corporatebg6.jpg, CC0, https://stocksnap.io/photo/laptop-apple-N6NK9J8V0A

====================================================================================================================================

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/guides/

For the support forum please visit: http://cyberchimps.com/forum/
