<?php
/**
* Outputs the customizer styles.
*
* @package corporate-one
*/

/**
* Outputs the custom styles for the theme.
*
* @return void
*/
function customizer_styles() {
$theme_color      = get_theme_mod( 'corporate_theme_color', '#82b440' );
$background_color = get_theme_mod( 'background_color', '#fff' );
$buttons_radius   = get_theme_mod( 'responsive_buttons_radius', 20 );
$buttons_radius   = $buttons_radius . 'px';
$custom_css       = "
.hentry .read-more a, article.product .read-more a{
background-color: $theme_color;
border-radius: $buttons_radius;
}
body{
background-color: $background_color;
}

#scroll {
background-color: $theme_color;
}
#scroll:hover {
background-color: $theme_color;
}
#scroll span {
border-bottom-color : #fff;
}
#scroll:hover span {
border-bottom-color : #fff;
}

#secondary .widget-title :after {
border-bottom: solid 2px $theme_color;
bottom: -7px;
content: '';
left: 0;
position: absolute;
width: 100px;
}
.wc-block-grid__product-price,
.woocommerce ul.products li.product .price {
color: $theme_color;
}
.main-navigation .menu  .current_page_item > a,
.main-navigation .menu  .current-menu-item > a,
.main-navigation .menu  li > a:hover {
color: $theme_color;
}
.woocommerce #respond input#submit,
.wp-block-button__link.add_to_cart_button,
.woocommerce div.product .woocommerce-tabs ul.tabs li a,
.woocommerce div.product .woocommerce-tabs ul.tabs li,
.woocommerce button.button.alt,
.woocommerce button.button,
.woocommerce a.button {
background-color: $theme_color;
}
.woocommerce div.product .woocommerce-tabs ul.tabs::before,
.woocommerce div.product .woocommerce-tabs ul.tabs li {
border-color: $theme_color;
}
.woocommerce div.product .woocommerce-tabs ul.tabs li::after {
box-shadow: -2px 2px 0 $theme_color;
}
.woocommerce div.product .woocommerce-tabs ul.tabs li::before {
box-shadow: 2px 2px 0 $theme_color;
}
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.wc-block-grid__product-onsale,
.woocommerce span.onsale {
background-color: $theme_color;
}
.page.front-page .button,
.blog.front-page .button,
.read-more-button .hentry .read-more .more-link,
input[type=button],
input[type=submit],
button,
.button,
div.wpforms-container-full .wpforms-form input[type=submit],
body div.wpforms-container-full .wpforms-form button[type=submit],
div.wpforms-container-full .wpforms-form .wpforms-page-button {
background-color: $theme_color;
padding: 5px 20px;
}

.page.front-page .button:focus,
.blog.front-page .button:focus,
.page.front-page .button:hover,
.blog.front-page .button:hover
{
background-color: $theme_color;
}

.wp-block-button__link:focus,
.wp-block-button__link:hover,
.read-more-button .hentry .read-more .more-link:hover,
.read-more-button .hentry .read-more .more-link:focus,
input[type=button]:hover,
input[type=submit]:hover,
input[type=button]:focus,
input[type=submit]:focus,
button:hover,
button:focus,
.button:hover,
.button:focus,
div.wpforms-container-full .wpforms-form input[type=submit]:hover,
div.wpforms-container-full .wpforms-form input[type=submit]:focus,
div.wpforms-container-full .wpforms-form input[type=submit]:active,
div.wpforms-container-full .wpforms-form button[type=submit]:hover,
div.wpforms-container-full .wpforms-form button[type=submit]:focus,
div.wpforms-container-full .wpforms-form button[type=submit]:active,
div.wpforms-container-full .wpforms-form .wpforms-page-button:hover,
div.wpforms-container-full .wpforms-form .wpforms-page-button:active,
div.wpforms-container-full .wpforms-form .wpforms-page-button:focus {
background-color: $theme_color;
}
";
wp_add_inline_style( 'corporate-style', apply_filters( 'responsive_head_css', $custom_css ) );

}
add_action( 'wp_enqueue_scripts', 'customizer_styles', 99 );
