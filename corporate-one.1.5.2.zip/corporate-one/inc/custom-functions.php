<?php
/**
 * Custom functions template
 *
 * @package corporate-one
 */

/**
 * Modify footer
 */
function corporate_one_custom_functions() {
	remove_action( 'cyberchimps_footer', 'cyberchimps_footer_credit' );
	add_action( 'cyberchimps_footer', 'corporate_one_footer_credit' );
}
add_action( 'init', 'corporate_one_custom_functions' );

/**
 * Footer area modified
 */
function corporate_one_footer_credit() {
?>
	 <div id="copy_right_section">
			<div class="container">
				<div class="col-md-4 col-sm-4 footer_logo">
					<!-- logo -->
					<?php $corporate_one_footer_image = get_theme_mod( 'corporate_one_footer_image' ); ?>
					<?php if ( ! empty( $corporate_one_footer_image ) ) { ?>
						<img class="corporate_one_footer_image" src="<?php echo esc_attr( $corporate_one_footer_image ); ?>" alt="<?php esc_attr_e( 'footer image','corporate-one' ); ?>" />
					<?php } ?>
				</div>
				<div class="col-md-4 col-sm-4 copyright_text">
					<!-- copyright text -->
					<?php
						$default_copyright = '&copy; ' . date( 'Y' ) . ' <a href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( get_bloginfo( 'name', 'display' ) ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a>';
						$copyright = get_theme_mod( 'footer_copyright_text', $default_copyright );
					?>
					<div id="copyright">
						<?php echo wp_kses_post( $copyright ); ?>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="corporate_one_footer_icons">
						<?php corporate_one_footer_social_icons(); ?>
					</div><!-- end of .corporate_one_footer_icons -->
				</div>
				<?php
					$corporate_one_enable_cc_link = get_theme_mod( 'corporate_one_enable_cc_link', 1 );
				if ( ! empty( $corporate_one_enable_cc_link ) ) {
				?>
				<!--cyberchimps link -->
				<div id="credit">                   
					<a href="<?php echo esc_url( __( 'http://cyberchimps.com/','corporate-one' ) ); ?>" target="_blank" title="<?php echo esc_attr( __( 'CyberChimps Themes','corporate-one' ) ); ?>" rel="noindex, nofollow">									
						<h4 class="cc-credit-text"><?php esc_html_e( 'CyberChimps WordPress Themes', 'corporate-one' ); ?></h4>
						<span class="screen-reader-text"><?php esc_html_e( 'Theme home page (will open in a new window)', 'corporate-one' ); ?></span>
					</a>                                
				</div><!-- end of .credit -->
				<?php
				}
				?>
			</div>
		</div>
		
	<div id="scroll-to-top"><span class="glyphicon glyphicon-chevron-up"></span></div>	
<?php
}

/**
 * Footer social icons
 */
function corporate_one_footer_social_icons() {

	// get the design of the icons to apply the right class
	$design = get_theme_mod( 'theme_backgrounds' );

	// create array of social icons to loop through to check if they are set and add title key to
	// social networks with names different to key
	$social['twitterbird']['set']   = get_theme_mod( 'social_twitter', 'checked' );
	$social['twitterbird']['title'] = 'twitter';
	$social['twitterbird']['url']   = get_theme_mod( 'twitter_url' );
	$social['facebook']['set']      = get_theme_mod( 'social_facebook', 'checked' );
	$social['facebook']['url']      = get_theme_mod( 'facebook_url' );
	$social['googleplus']['set']    = get_theme_mod( 'social_google', 'checked' );
	$social['googleplus']['url']    = get_theme_mod( 'google_url' );
	$social['flickr']['set']        = get_theme_mod( 'social_flickr' );
	$social['flickr']['url']        = get_theme_mod( 'flickr_url' );
	$social['pinterest']['set']     = get_theme_mod( 'social_pinterest' );
	$social['pinterest']['url']     = get_theme_mod( 'pinterest_url' );
	$social['linkedin']['set']      = get_theme_mod( 'social_linkedin' );
	$social['linkedin']['url']      = get_theme_mod( 'linkedin_url' );
	$social['youtube']['set']       = get_theme_mod( 'social_youtube' );
	$social['youtube']['url']       = get_theme_mod( 'youtube_url' );
	$social['map']['set']           = get_theme_mod( 'social_googlemaps' );
	$social['map']['title']         = 'google maps';
	$social['map']['url']           = get_theme_mod( 'googlemaps_url' );
	$social['email']['set']         = get_theme_mod( 'social_email' );
	$social['email']['url']         = 'mailto:' . get_theme_mod( 'email_url' );
	$social['rss']['set']           = get_theme_mod( 'social_rss' );
	$social['rss']['url']           = get_theme_mod( 'rss_url' );
	$social['instagram']['set']     = get_theme_mod( 'social_instagram' );
	$social['instagram']['url']     = get_theme_mod( 'instagram_url' );

	$output = '';

	// get the blog title to add to link title
	$link_title = get_bloginfo( 'title' );

	// Loop through the $social variable
	foreach ( $social as $key => $value ) {

		// Check that the social icon has been set
		if ( ! empty( $value['set'] ) ) {

			// check if title is set and use it otherwise use key as title
			$title = ( isset( $social[ $key ]['title'] ) ) ? $social[ $key ]['title'] : $key;

			// Create the output
			$output .= '<a href="' . esc_url( $social[ $key ]['url'] ) . '"' . ( 'email' != $key ? ' target="_blank"' : '' )
				. ' title="' . esc_attr( $link_title . ' ' . ucwords( $title ) ) . '" class="symbol ' . $key . '"><span class="screen-reader-text">' . $key . ' - ' . __( ' Link will open in new window', 'corporate-one' ) . '</span></a>';
		}
	}

	// Echo to the page
	?>
	<?php
	if ( ! empty( $design ) ) {
	?>
	<div id="social">
		<div class="<?php echo $design; ?>-icons">
			<?php echo $output; ?>
		</div>
	</div>
	<?php
	}
	?>

<?php
}

/**
 * Excerpt length for services section
 *
 * @param array $length Excerpt length.
 */
function corporate_one_sections_excerpt_length( $length ) {
	return 10;
}

/**
 * Excerpt length for section subtitles
 *
 * @param array $length Excerpt length.
 */
function corporate_one_sections_excerpt_subtitle( $length ) {
	return 4;
}

/**
 * Replaces "[...]" with ... *
 */
function corporate_one_excerpt_more() {
	return '';
}
add_filter( 'excerpt_more', 'corporate_one_excerpt_more' );

/**
 * Replaces "[...]" with Read More
 */
function corporate_one_excerpt_read_more( $excerpt ) {
	$post = get_post();
	$excerpt .= '<a class="excerpt-more" href="' . esc_url(get_permalink( $post->ID )) . '">' . esc_html(__( 'Read More', 'corporate-one' )) . '</a>';
	return $excerpt;
}

/*================= Fonts =====================*/

/**
 * List for sizes
 *
 * @param array $sizes Typography sizes.
 */
function corporate_one_typography_sizes( $sizes ) {
	$sizes = array( '8', '9', '10', '12', '14', '15', '16', '18', '20' );
	return $sizes;
}
add_filter( 'cyberchimps_typography_sizes', 'corporate_one_typography_sizes' );

/**
 * List for styles
 *
 * @param array $styles Typography styles.
 */
function corporate_one_typography_styles( $styles ) {
	$styles = array(
		'normal' => esc_html(__( 'Normal', 'corporate-one' )),
		'bold' => esc_html(__( 'Bold', 'corporate-one' )),
	);
	return $styles;
}
add_filter( 'cyberchimps_typography_styles', 'corporate_one_typography_styles' );

/**
 * Adding Roboto Slab font to main list
 *
 * @param array $orig Typography faces.
 */
function corporate_one_typography_faces( $orig ) {

	$new = array(
		'"Roboto Slab", serif' => 'Roboto Slab',
	);

	$new = array_merge( $new, $orig );

	return $new;
}
add_filter( 'cyberchimps_typography_faces', 'corporate_one_typography_faces' );

/**
 * Setting defaults - body
 */
function corporate_one_typography_defaults() {
	$default = array(
		'size' => '15px',
		'face' => '"Roboto Slab", serif',
		'style' => 'normal',
		'color' => '',
	);

	return $default;
}
add_filter( 'cyberchimps_typography_defaults', 'corporate_one_typography_defaults' );

/**
 * Setting defaults - menu
 */
function corporate_one_menu_typography_style() {
	$default = array(
		'face' => '"Roboto Slab", serif',
	);
	return $default;
}
add_filter( 'cyberchimps_typography_menu_defaults', 'corporate_one_menu_typography_style' );

/**
 * Prints HTML for author link of the post.
 */
function corporate_one_posted_by() {

					// Get url of all author archive( the page will contain all posts by the author).
		$auther_posts_url = esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );

		// Set author title text which will appear on hover over the author link.
		/* translators: %s: Author name */
		$auther_link_title = esc_attr( sprintf( __( 'View all posts by %s', 'corporate-one' ), get_the_author() ) );

		// Set the HTML for author link.
		$posted_by = sprintf(
			/* translators: %s: Author details */
			'<li><span class="byline"> %s ',
			'<span class="author vcard">
								<a class="url fn n" href="' . $auther_posts_url . '" title="' . $auther_link_title . '" rel="author">' . esc_html( get_the_author() ) . '</a>
							</span>
						</span></li>'
		);

		// If post byline author toggle is on then print HTML for author link.
		echo "<li class='author_img'>" . get_avatar( get_the_author_meta( 'ID' ), 48 ) . '</li>';
		echo apply_filters( 'cyberchimps_posted_by', $posted_by );
}

/**
 * Prints HTML for post date.
 */
function corporate_one_posted_on() {

		// Get all data related to date.
		$date_url   = esc_url( get_permalink() );
		$date_title = esc_attr( get_the_time() );
		$date_time  = esc_attr( get_the_time() );
		$date_time  = esc_attr( get_the_date( 'c' ) );
		$date       = esc_html( get_the_date() );

		// Set the HTML for date link.
		$posted_on = sprintf(
			/* translators: %s: Date */
			__( '<li><i class="fa fa-calendar" aria-hidden="true"></i> Posted on %s', 'corporate-one' ),
			'<a href="' . $date_url . '" title="' . $date_title . '" rel="bookmark">
							<time class="entry-date updated" datetime="' . $date_time . '">' . $date . '</time>
						</a></li>'
		);

		// If post byline date toggle is on then print HTML for date link.
		echo apply_filters( 'cyberchimps_posted_on', $posted_on );
}

/**
 * Prints HTML for post categories.
 */
function corporate_one_posted_in() {
		global $post;

		$categories_list = get_the_category_list( ', ' );
	if ( $categories_list ) :
		/* translators: %s: Categories list */
		$cats = sprintf( __( 'Posted in %s', 'corporate-one' ), $categories_list );
		?>
		<li><span class="cat-links">
		<?php echo apply_filters( 'cyberchimps_post_categories', $cats ); ?>
		</span>
		</li>
		<?php
		endif;
}

/**
 * Prints HTML for post comments.
 */
function corporate_one_post_comments() {
		global $post;

		$leave_comment = ( is_single() || is_page() ) ? '' : __( 'Leave a comment', 'corporate-one' );
	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) :
		?>
		<li><span class="comments-link"><?php comments_popup_link( $leave_comment, __( '<i class="fa fa-comment" aria-hidden="true"></i> 1 Comment', 'corporate-one' ), '<i class="fa fa-comment" aria-hidden="true"></i> % ' . __( 'Comments', 'corporate-one' ) ); ?></span></li>
		<?php
		endif;
}

/**
 * For Author Bio on Single Posts Page
 */
function corporate_one_posts_author_bio() {
	global $post;
	$user_description = get_the_author_meta( 'user_description', $post->post_author );
	?>
			<div class="row">
			<div class="cyberchimps_author_bio col-md-12">
				<div class="author_bio_wrapper">
				<div class="avatar_author  col-md-2">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 90 ); ?> 
				</div>
				<div class="author_bio col-md-10">
					<?php
					// Get url of all author archive( the page will contain all posts by the author).
					$auther_posts_url = esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );

					/* translators: %s: Author name */
					$auther_link_title = esc_attr( sprintf( __( 'View all posts by %s', 'corporate-one' ), get_the_author() ) );

					echo '<div class="author vcard author_bio_name">
			<a class="url fn n" href="' . $auther_posts_url . '" title="' . $auther_link_title . '" rel="author">' . esc_html( get_the_author() ) . '</a>
		</div>';
					the_author_meta( 'user_description' );
					?>
				</div>
				</div>
			</div>
			</div>
<?php
}

/**
 * Exclude post categories from the Category widget
 */
function corporate_one_custom_category_widget( $arg ) {
	$cat = get_theme_mod( 'corporate_one_exclude_post_cat' );

	if ( $cat ) {
		$cat = array_diff( array_unique( $cat ), array( '' ) );
		$arg['exclude'] = $cat;
	}
	return $arg;
}
add_filter( 'widget_categories_args', 'corporate_one_custom_category_widget' );
add_filter( 'widget_categories_dropdown_args', 'corporate_one_custom_category_widget' );

/**
 * Exclude post categories from the Recent Post widget
 */
function corporate_one_exclude_post_cat_recentpost_widget( $array ) {
	$s = '';
	$i = 1;
	$cat = get_theme_mod( 'corporate_one_exclude_post_cat' );

	if ( $cat ) {
		$cat = array_diff( array_unique( $cat ), array( '' ) );
		foreach ( $cat as $c ) {
			$i++;
			$s .= '-' . $c;
			if ( count( $cat ) >= $i ) {
				$s .= ', ';
			}
		}
	}

	$array[ 'cat' ] = array( $s );

	return $array;
}
add_filter( 'widget_posts_args', 'corporate_one_exclude_post_cat_recentpost_widget' );
