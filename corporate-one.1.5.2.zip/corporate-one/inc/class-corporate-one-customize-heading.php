<?php
/**
 * Corporate One customize_register class.
 *
 * @link
 *
 * @package corporate-one
 */

/**
 * Class Corporate_One_Customize_Heading
 *
 * Creates a form heading to show headings for sub-sections
 */
class Corporate_One_Customize_Heading extends WP_Customize_Control {
	/**
	 * Heading for customizer options
	 *
	 * @var type.
	 */
	public $type = 'heading';

	/**
	 * Display content.
	 */
	public function render_content() {
		if ( ! empty( $this->label ) ) : ?>
			<h3 class="total-accordion-section-title"><?php echo esc_html( $this->label ); ?></h3>
			<?php
		endif;

		if ( $this->description ) {
			?>
			<span class="description customize-control-description">
			<?php echo wp_kses_post( $this->description ); ?>
			</span>
			<?php
		}
	}
}
