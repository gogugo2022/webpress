<?php
/**
 * Theme options in customizer
 *
 * @package corporate-one
 */

/**
 * Customizer options
 *
 * @param array $wp_customize Customizer options.
 */
function corporate_one_customizer_register( $wp_customize ) {

    require get_stylesheet_directory() . '/inc/class-corporate-one-customize-heading.php';
	/* Option list of all post */
	$options_posts     = array();
	$options_posts_obj = new WP_Query(
		array(
			'posts_per_page' => 100,
		)
	);
	$options_posts[''] = esc_html( __( 'Choose Post', 'corporate-one' ) );
	if ( $options_posts_obj->have_posts() ) {
		while ( $options_posts_obj->have_posts() ) :
			$options_posts_obj->the_post();
			$post_id                   = get_the_ID();
			$options_posts[ $post_id ] = get_the_title();
		endwhile;
		wp_reset_postdata();
	}

	/* Option list of all categories */
	$args                  = array(
		'type'         => 'post',
		'orderby'      => 'name',
		'order'        => 'ASC',
		'hide_empty'   => 1,
		'hierarchical' => 1,
		'taxonomy'     => 'category',
	);
	$option_categories     = array();
	$category_lists        = get_categories( $args );
	$option_categories[''] = esc_html( __( 'Choose Category', 'corporate-one' ) );
	foreach ( $category_lists as $category ) {
		$option_categories[ $category->term_id ] = $category->name;
	}

	$option_all_post_cat = array();
	foreach ( $category_lists as $category ) {
		$option_all_post_cat[ $category->term_id ] = $category->name;
	}

	/* Option list of all pages */
	$options_pages     = array();
	$options_pages_obj = new WP_Query(
		array(
			'posts_per_page' => 100,
			'post_type'      => 'page',
		)
	);
	$options_pages[''] = esc_html( __( 'Choose Page', 'corporate-one' ) );
	if ( $options_pages_obj->have_posts() ) {
		while ( $options_pages_obj->have_posts() ) :
			$options_pages_obj->the_post();
			$post_id                   = get_the_ID();
			$options_pages[ $post_id ] = get_the_title();
		endwhile;
		wp_reset_postdata();
	}


	$wp_customize->add_panel(
		'home_page_settings',
		array(
			'priority'       => 46,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Corporate One Settings', 'corporate-one' ) ),
		)
	);

	/*============== setup guidelines =====================*/
	$wp_customize->add_section(
		'corporate_one_homepage_setup_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Home Template and Menu setup guidelines', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	$wp_customize->add_setting(
		'corporate_one_homepage_setup_guide',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_homepage_setup_guide',
				array(
					'settings'    => 'corporate_one_homepage_setup_guide',
					'section'     => 'corporate_one_homepage_setup_section',
					'label'       => esc_html( __( 'Steps to setup homepage :', 'corporate-one' ) ),
					'description' => esc_html( __( 'Please create a page and choose "Home Template" from under "Page Attributes" > "Template" on the right side. These home page settings will apply to this page. To view this page as the front page, please go to "Settings" > "Reading" and choose this page for the setting "A static page" under the "Your homepage displays" option. ', 'corporate-one' ) ),
				)
			)
		);

	// menu setup - for home page sections.
	$wp_customize->add_setting(
		'corporate_one_homesections_menu_setup_guide',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_homesections_menu_setup_guide',
				array(
					'settings'    => 'corporate_one_homesections_menu_setup_guide',
					'section'     => 'corporate_one_homepage_setup_section',
					'label'       => esc_html( __( 'Steps to setup menu consisting of home page sections :', 'corporate-one' ) ),
					'description' => esc_html( __( 'The "Home Page" has multiple sections. Each section has an ID. The ID for each section is mentioned under its settings. Link to each section can be added from the menu. For example, steps to create menu link for "Testimonial" section are: Go to "Appearance" > "Menus" > "Custom Links"> "URL": Please enter your site URL followed by its ID "#testimonial"', 'corporate-one' ) ),
				)
			)
		);
	/*============== banner =====================*/
	$wp_customize->add_section(
		'corporate_one_banner_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Top Banner Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_banner_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_banner_section_id',
				array(
					'settings'    => 'corporate_one_banner_section_id',
					'section'     => 'corporate_one_banner_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#intro', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_banner_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_banner_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_banner_section',
			'settings' => 'corporate_one_enable_banner_section',
			'type'     => 'checkbox',
		)
	);

	// choose banner post 1.
	$wp_customize->add_setting(
		'corporate_one_banner_post_1',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_banner_post_1',
		array(
			'label'       => esc_html( __( 'Select First Banner Post ', 'corporate-one' ) ),
			'section'     => 'corporate_one_banner_section',
			'type'        => 'select',
			'choices'     => $options_posts,
			'description' => esc_html( __( 'The featured image from this post will be the main banner background image. Recommended image size for the featured image: 1920 x 827px', 'corporate-one' ) ),
		)
	);

	// choose banner post 2.
	$wp_customize->add_setting(
		'corporate_one_banner_post_2',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_banner_post_2',
		array(
			'label'       => esc_html( __( 'Select Second Banner Post ', 'corporate-one' ) ),
			'section'     => 'corporate_one_banner_section',
			'type'        => 'select',
			'choices'     => $options_posts,
			'description' => esc_html( __( "This post's content will be displayed on top of the main banner image. Recommended image size for the featured image: 395 x 438px", 'corporate-one' ) ),
		)
	);

	/*============== About =====================*/
	$wp_customize->add_section(
		'corporate_one_about_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'About Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_about_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_about_section_id',
				array(
					'settings'    => 'corporate_one_about_section_id',
					'section'     => 'corporate_one_about_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#about', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_about_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_about_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_about_section',
			'settings' => 'corporate_one_enable_about_section',
			'type'     => 'checkbox',
		)
	);

	// choose page - section title and subtitle.
	$wp_customize->add_setting(
		'corporate_one_about_title_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_about_title_subtitle',
		array(
			'label'       => esc_html( __( 'Select Page for title and subtitle: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_about_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page title will be displayed as section title and page content will be displayed as the subtitle for this section', 'corporate-one' ) ),
		)
	);

	// choose page - description.
	$wp_customize->add_setting(
		'corporate_one_about_description',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_about_description',
		array(
			'label'       => esc_html( __( 'Select Page for description: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_about_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page content will be displayed as the description for this section', 'corporate-one' ) ),
		)
	);

	// Subsection:skills heading.
	$wp_customize->add_setting(
		'corporate_one_about_skills_heading',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_about_skills_heading',
				array(
					'settings' => 'corporate_one_about_skills_heading',
					'section'  => 'corporate_one_about_section',
					'label'    => esc_html( __( 'Sub-section: Skills', 'corporate-one' ) ),
				)
			)
		);

	// choose post category - for subsection:Skills.
	$wp_customize->add_setting(
		'corporate_one_about_skills_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_about_skills_category',
		array(
			'label'       => esc_html( __( 'Select Post Category', 'corporate-one' ) ),
			'section'     => 'corporate_one_about_section',
			'type'        => 'select',
			'choices'     => $option_categories,
			'description' => esc_html( __( 'The page title, content and featured image from the post will be displayed. Recommended image size for the featured image: 51 x 51px', 'corporate-one' ) ),
		)
	);

	// Subsection:highlights heading.
	$wp_customize->add_setting(
		'corporate_one_about_highlights_heading',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_about_highlights_heading',
				array(
					'settings' => 'corporate_one_about_highlights_heading',
					'section'  => 'corporate_one_about_section',
					'label'    => esc_html( __( 'Sub-section: Highlights', 'corporate-one' ) ),
				)
			)
		);

	// choose post category - for subsection:Highlights.
	$wp_customize->add_setting(
		'corporate_one_about_highlights_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_about_highlights_category',
		array(
			'label'       => esc_html( __( 'Select Post Category', 'corporate-one' ) ),
			'section'     => 'corporate_one_about_section',
			'type'        => 'select',
			'choices'     => $option_categories,
			'description' => esc_html( __( 'The page title and content from the post will be displayed.', 'corporate-one' ) ),
		)
	);

	/*============== Services =====================*/
	$wp_customize->add_section(
		'corporate_one_services_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Services Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_services_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_services_section_id',
				array(
					'settings'    => 'corporate_one_services_section_id',
					'section'     => 'corporate_one_services_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#services', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_services_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_services_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_services_section',
			'settings' => 'corporate_one_enable_services_section',
			'type'     => 'checkbox',
		)
	);

	// choose page - section title and subtitle.
	$wp_customize->add_setting(
		'corporate_one_services_title_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_services_title_subtitle',
		array(
			'label'       => esc_html( __( 'Select Page for title and subtitle: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_services_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page title will be displayed as section title and page content will be displayed as the subtitle for this section', 'corporate-one' ) ),
		)
	);

	// choose 3 post categories to display the services.
	for ( $i = 1; $i < 4; $i++ ) {
		$wp_customize->add_setting(
			'corporate_one_each_services_category_title_' . $i,
			array(
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_each_services_category_title_' . $i,
				array(
					'settings' => 'corporate_one_each_services_category_title_' . $i,
					'section'  => 'corporate_one_services_section',
					'label'    => esc_html( __( 'Category ', 'corporate-one' ) ) . $i,
				)
			)
		);

		// value description.
		$wp_customize->add_setting(
			'corporate_one_services_category_' . $i,
			array(
				'default'           => '',
				'sanitize_callback' => 'cyberchimps_sanitize_select_post',
			)
		);
		$wp_customize->add_control(
			'corporate_one_services_category_' . $i,
			array(
				'label'       => esc_html( __( 'Select Post category', 'corporate-one' ) ),
				'section'     => 'corporate_one_services_section',
				'type'        => 'select',
				'settings'    => 'corporate_one_services_category_' . $i,
				'choices'     => $option_categories,
				'description' => esc_html( __( 'The post title, content and featured image will be showcased as the services portfolio. Recommended image size for the featured images: 370 x 348px', 'corporate-one' ) ),
			)
		);
	}

	/*============== Experience =====================*/
	$wp_customize->add_section(
		'corporate_one_experience_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Experience Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_experience_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_experience_section_id',
				array(
					'settings'    => 'corporate_one_experience_section_id',
					'section'     => 'corporate_one_experience_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#experience', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_experience_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_experience_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_experience_section',
			'settings' => 'corporate_one_enable_experience_section',
			'type'     => 'checkbox',
		)
	);

	// choose page - section title and subtitle.
	$wp_customize->add_setting(
		'corporate_one_experience_title_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_experience_title_subtitle',
		array(
			'label'       => esc_html( __( 'Select Page for title and subtitle: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_experience_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page title will be displayed as section title and page content will be displayed as the subtitle for this section', 'corporate-one' ) ),
		)
	);

	// choose post category - for experience events.
	$wp_customize->add_setting(
		'corporate_one_experience_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_experience_category',
		array(
			'label'       => esc_html( __( 'Select Post Category to display experience events:', 'corporate-one' ) ),
			'section'     => 'corporate_one_experience_section',
			'type'        => 'select',
			'choices'     => $option_categories,
			'description' => esc_html( __( 'The page title, content and tags from the post will be displayed.', 'corporate-one' ) ),
		)
	);

	/*============== Testimonial =====================*/
	$wp_customize->add_section(
		'corporate_one_testimonial_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Testimonial Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_testimonial_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_testimonial_section_id',
				array(
					'settings'    => 'corporate_one_testimonial_section_id',
					'section'     => 'corporate_one_testimonial_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#testimonial', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_testimonial_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_testimonial_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_testimonial_section',
			'settings' => 'corporate_one_enable_testimonial_section',
			'type'     => 'checkbox',
		)
	);

	// choose page - section title and subtitle.
	$wp_customize->add_setting(
		'corporate_one_testimonial_title_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_testimonial_title_subtitle',
		array(
			'label'       => esc_html( __( 'Select Page for title and subtitle: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_testimonial_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page title will be displayed as section title and page content will be displayed as the subtitle for this section. Also, the featured image will be displayed as background image. Recommended image size: 2000 x 942px', 'corporate-one' ) ),
		)
	);

	// choose post category.
	$wp_customize->add_setting(
		'corporate_one_testimonial_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_testimonial_category',
		array(
			'label'       => esc_html( __( 'Select Post Category to display client reviews:', 'corporate-one' ) ),
			'section'     => 'corporate_one_testimonial_section',
			'type'        => 'select',
			'choices'     => $option_categories,
			'description' => esc_html( __( 'The page title, content and featured image from the post will be displayed. Recommended image size for the featured image: 600 x 397px', 'corporate-one' ) ),
		)
	);

	/*============== Contact =====================*/
	$wp_customize->add_section(
		'corporate_one_contact_section',
		array(
			'priority'       => 10,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html( __( 'Contact Section', 'corporate-one' ) ),
			'panel'          => 'home_page_settings',
		)
	);
	// section id.
	$wp_customize->add_setting(
		'corporate_one_contact_section_id',
		array(
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

		$wp_customize->add_control(
			new Corporate_One_Customize_Heading(
				$wp_customize,
				'corporate_one_contact_section_id',
				array(
					'settings'    => 'corporate_one_contact_section_id',
					'section'     => 'corporate_one_contact_section',
					'label'       => esc_html( __( 'Section ID (can be used to setup the menu) : ', 'corporate-one' ) ),
					'description' => esc_html( __( '#contact', 'corporate-one' ) ),
				)
			)
		);
	// enable section.
	$wp_customize->add_setting(
		'corporate_one_enable_contact_section',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_contact_section',
		array(
			'label'    => esc_html( __( 'Enable Section', 'corporate-one' ) ),
			'section'  => 'corporate_one_contact_section',
			'settings' => 'corporate_one_enable_contact_section',
			'type'     => 'checkbox',
		)
	);

	// choose page - section title and subtitle.
	$wp_customize->add_setting(
		'corporate_one_contact_title_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_contact_title_subtitle',
		array(
			'label'       => esc_html( __( 'Select Page for title and subtitle: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_contact_section',
			'type'        => 'select',
			'choices'     => $options_pages,
			'description' => esc_html( __( 'The page title will be displayed as section title and page content will be displayed as the subtitle for this section', 'corporate-one' ) ),
		)
	);

	// choose post category.
	$wp_customize->add_setting(
		'corporate_one_contact_details_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_contact_details_category',
		array(
			'label'       => esc_html( __( 'Select Post Category to display contact details:', 'corporate-one' ) ),
			'section'     => 'corporate_one_contact_section',
			'type'        => 'select',
			'choices'     => $option_categories,
			'description' => esc_html( __( 'The page content and featured image from the post will be displayed. Recommended image size: 60 x 44px', 'corporate-one' ) ),
		)
	);

	// choose page - map.
	$wp_customize->add_setting(
		'corporate_one_contact_page_map',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_contact_page_map',
		array(
			'label'       => esc_html( __( 'Select Post to display map: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_contact_section',
			'type'        => 'select',
			'choices'     => $options_posts,
			'description' => esc_html( __( 'The post content will be diplayed as the background. Recommended: google map', 'corporate-one' ) ),
		)
	);

	// choose page - contact form.
	$wp_customize->add_setting(
		'corporate_one_contact_page_form',
		array(
			'default'           => '',
			'sanitize_callback' => 'cyberchimps_sanitize_select_post',
		)
	);
	$wp_customize->add_control(
		'corporate_one_contact_page_form',
		array(
			'label'       => esc_html( __( 'Select Post to display form: ', 'corporate-one' ) ),
			'section'     => 'corporate_one_contact_section',
			'type'        => 'select',
			'choices'     => $options_posts,
			'description' => esc_html( __( "The post content will overlap the above map. Recommended: Contact form (from Contact Form 7's plugin)", 'corporate-one' ) ),
		)
	);

	// footer image.
	$wp_customize->add_setting(
		'corporate_one_footer_image',
		array(
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'corporate_one_footer_image',
			array(
				'label'       => esc_html( __( 'Footer image', 'corporate-one' ) ),
				'section'     => 'cyberchimps_footer_section',
				'settings'    => 'corporate_one_footer_image',
				'type'        => 'image',
				'description' => esc_html( __( 'Recommended image size: 200 x 26px', 'corporate-one' ) ),
			)
		)
	);

	// cyberchimps link on/off.
	$wp_customize->add_setting(
		'corporate_one_enable_cc_link',
		array(
			'sanitize_callback' => 'cyberchimps_sanitize_checkbox',
			'default'           => 1,
		)
	);

	$wp_customize->add_control(
		'corporate_one_enable_cc_link',
		array(
			'label'       => esc_html( __( 'Display CyberChimps Link ?', 'corporate-one' ) ),
			'section'     => 'cyberchimps_footer_section',
			'settings'    => 'corporate_one_enable_cc_link',
			'description' => esc_html( __( 'Check this checkbox to display CyberChimps link in footer', 'corporate-one' ) ),
			'type'        => 'checkbox',
		)
	);

    $wp_customize->add_setting(
        'corporate_theme_color', array(
            'default' => '#82b440',
            'sanitize_callback' => 'sanitize_hex_color',
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize, 'corporate_theme_color', array(
                'label' => __( 'Theme Color', 'corporate-one' ),
                'section' => 'responsive_colors',
                'settings' => 'corporate_theme_color',
            )
        )
    );

    /**
	 * Function to sanitze multiple checkboxes option
	 *
	 * @param  [type] $values [description].
	 * @return [type]         [description]
	 */
	function corporate_one_sanitize_multiple_checkboxes( $values ) {

		$multi_values = ! is_array( $values ) ? explode( ',', $values ) : $values;

		return ! empty( $multi_values ) ? array_map( 'sanitize_text_field', $multi_values ) : array();
	}

}
add_action( 'customize_register', 'corporate_one_customizer_register' );

/**
 * [cyberchimps_sanitize_select_post description].
 *
 * @param  [type] $input   [description].
 * @param  [type] $setting [description].
 * @return [type]          [description].
 */
function cyberchimps_sanitize_select_post( $input, $setting ) {
		// Ensure input is a slug.
		$input = sanitize_key( $input );
		// Get list of choices from the control associated with the setting.
		$choices = $setting->manager->get_control( $setting->id )->choices;
		// If the input is a valid key, return it; otherwise, return the default.
		return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}
