<?php
/**
 * Contact section
 *
 * @package corporate-one
 */

// fetch page.
$corporate_one_contact_title_subtitle = get_theme_mod( 'corporate_one_contact_title_subtitle' );
$corporate_one_contact_page_map       = get_theme_mod( 'corporate_one_contact_page_map' );
$corporate_one_contact_page_form      = get_theme_mod( 'corporate_one_contact_page_form' );
$contact_pages                        = array( $corporate_one_contact_page_map, $corporate_one_contact_page_form );
$contact_pages                        = array_diff( array_unique( $contact_pages ), array( '' ) );

// fetch post categories.
$corporate_one_contact_details_category = get_theme_mod( 'corporate_one_contact_details_category' );
?>
<section id="contact" class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php
                if ( $corporate_one_contact_title_subtitle ) {
                    remove_filter( 'the_excerpt', 'wpautop' );
                    $corporate_one_contact_title_subtitle_query = new WP_Query(
                        array(
                            'page_id' => $corporate_one_contact_title_subtitle,
                        )
                    );

                    if ( $corporate_one_contact_title_subtitle_query->have_posts() ) {
                        while ( $corporate_one_contact_title_subtitle_query->have_posts() ) {
                            $corporate_one_contact_title_subtitle_query->the_post();
                            ?>
                            <h1><?php the_title(); ?></h1>
                            <?php
                            if ( get_the_content() != '' ) {
                                ?>
                                <p class="subtitle fancy"><span>
										<?php
                                        add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                        the_excerpt();
                                        remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                        ?>
									</span></p>
                                <?php
                            }
                            ?>
                            <?php
                        }
                    }
                    wp_reset_postdata();
                    add_filter( 'the_excerpt', 'wpautop' );
                }
                ?>

                <?php

                if ( $corporate_one_contact_details_category ) {
                    remove_filter( 'the_content', 'wpautop' );
                    $corporate_one_contact_details_category_posts = new WP_Query(
                        array(
                            'cat'                 => $corporate_one_contact_details_category,
                            'posts_per_page'      => 3,
                            'ignore_sticky_posts' => true,
                        )
                    );
                    $skills_counter                               = 1;
                    if ( $corporate_one_contact_details_category_posts->have_posts() ) {
                        while ( $corporate_one_contact_details_category_posts->have_posts() ) {
                            $corporate_one_contact_details_category_posts->the_post();
                            if ( 1 === $skills_counter ) {
                                $contact_class     = '';
                                $contact_box_class = 'col-sm-12';
                            } elseif ( 2 === $skills_counter ) {
                                $contact_class     = 'phonenumber';
                                $contact_box_class = 'col-sm-6';
                            } elseif ( 3 === $skills_counter ) {
                                $contact_class     = 'mail';
                                $contact_box_class = 'col-sm-6';
                            }
                            ?>
                            <div class="col-md-4 <?php echo esc_attr( $contact_box_class ); ?> contact_details_box">
                                <?php
                                if ( has_post_thumbnail() ) {
                                    $contact_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
                                    $post_id       = get_the_ID();
                                    $thumbnail_id  = get_post_thumbnail_id( $post_id );
                                    $img_alt       = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                                    ?>
                                    <img src="<?php echo esc_url( $contact_image[0] ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>" />
                                <?php } ?>
                                <p class="<?php echo esc_attr( $contact_class ); ?>"><?php the_content(); ?></p>
                            </div><!-- end of col-md-4 -->
                            <?php
                            $skills_counter++;
                        }
                        wp_reset_postdata();
                        add_filter( 'the_content', 'wpautop' );
                    }
                }
                ?>
            </div>
        </div>
    </div>
    <div class="map">
        <?php
        if ( $contact_pages ) {
            remove_filter( 'the_content', 'wpautop' );
            $i             = 1;
            $contact_query = new WP_Query(
                array(
                    'post__in'            => $contact_pages,
                    'orderby'             => 'post__in',
                    'posts_per_page'      => 2,
                    'ignore_sticky_posts' => true,
                )
            );
            if ( $contact_query->have_posts() ) {
                while ( $contact_query->have_posts() ) {
                    $contact_query->the_post();

                    if ( 1 === $i ) {
                        the_content();
                    } elseif ( 2 === $i ) {
                        ?>
                        <div class="contact_form_box">
                            <?php the_content(); ?>
                        </div>
                        <?php
                    }

                    $i++;
                }
                wp_reset_postdata();
                add_filter( 'the_content', 'wpautop' );
            }
        }
        ?>
    </div>
</section>
<?php
