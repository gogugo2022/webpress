<?php
/**
 * About section
 *
 * @package corporate-one
 */

    // fetch page.
    $corporate_one_about_title_subtitle = get_theme_mod( 'corporate_one_about_title_subtitle' );
    $corporate_one_about_description    = get_theme_mod( 'corporate_one_about_description' );

    // fetch post categories.
    $corporate_one_about_skills_category     = get_theme_mod( 'corporate_one_about_skills_category' );
    $corporate_one_about_highlights_category = get_theme_mod( 'corporate_one_about_highlights_category' );

    ?>
    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <?php
                    if ( $corporate_one_about_highlights_category ) {
                        remove_filter( 'the_content', 'wpautop' );
                        $corporate_one_about_highlights_category_posts = new WP_Query(
                            array(
                                'cat'                 => $corporate_one_about_highlights_category,
                                'posts_per_page'      => 4,
                                'ignore_sticky_posts' => true,
                            )
                        );
                        $highlight_counter                             = 1;
                        if ( $corporate_one_about_highlights_category_posts->have_posts() ) {
                            while ( $corporate_one_about_highlights_category_posts->have_posts() ) {
                                $corporate_one_about_highlights_category_posts->the_post();
                                if ( 1 === $highlight_counter ) {
                                    $countup_color = 'green';
                                } elseif ( 2 === $highlight_counter ) {
                                    $countup_color = 'turquoise';
                                } elseif ( 3 === $highlight_counter ) {
                                    $countup_color = 'blue';
                                } elseif ( 4 === $highlight_counter ) {
                                    $countup_color = 'skyblue';
                                }

                                ?>
                                <div class="countup_box <?php echo esc_attr( $countup_color ); ?>">
                                    <span><?php the_content(); ?></span>
                                    <p><?php the_title(); ?></p>
                                </div>

                                <?php
                                $highlight_counter++;
                            }
                            wp_reset_postdata();
                            add_filter( 'the_content', 'wpautop' );
                        }
                    }
                    ?>

                </div><!-- end of col-md-4 -->
                <div class="col-md-8 ">
                    <div class="about_info">
                        <?php
                        if ( $corporate_one_about_title_subtitle ) {
                            remove_filter( 'the_excerpt', 'wpautop' );
                            $corporate_one_about_title_subtitle_query = new WP_Query(
                                array(
                                    'page_id' => $corporate_one_about_title_subtitle,
                                )
                            );

                            if ( $corporate_one_about_title_subtitle_query->have_posts() ) {
                                while ( $corporate_one_about_title_subtitle_query->have_posts() ) {
                                    $corporate_one_about_title_subtitle_query->the_post();
                                    ?>
                                    <h2><?php the_title(); ?></h2>
                                    <?php
                                    if ( get_the_content() != '' ) {
                                        ?>
                                        <p class="subtitle fancy"><span>
											<?php
                                            add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            the_excerpt();
                                            remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            ?>
										</span></p>
                                        <?php
                                    }
                                    ?>
                                    <?php
                                }
                            }
                            wp_reset_postdata();
                            add_filter( 'the_excerpt', 'wpautop' );
                        }
                        ?>
                        <?php
                        if ( $corporate_one_about_description ) {
                            $corporate_one_about_description_query = new WP_Query(
                                array(
                                    'page_id' => $corporate_one_about_description,
                                )
                            );

                            if ( $corporate_one_about_description_query->have_posts() ) {
                                while ( $corporate_one_about_description_query->have_posts() ) {
                                    $corporate_one_about_description_query->the_post();
                                    ?>
                                    <?php the_content(); ?>
                                    <?php
                                }
                            }
                            wp_reset_postdata();
                        }
                        ?>
                    </div>
                    <?php
                    if ( $corporate_one_about_skills_category ) {
                        $corporate_one_about_skills_category_posts = new WP_Query(
                            array(
                                'cat'                 => $corporate_one_about_skills_category,
                                'posts_per_page'      => 4,
                                'ignore_sticky_posts' => true,
                            )
                        );
                        $skills_counter                            = 0;
                        if ( $corporate_one_about_skills_category_posts->have_posts() ) {
                            while ( $corporate_one_about_skills_category_posts->have_posts() ) {
                                $corporate_one_about_skills_category_posts->the_post();
                                $skills_counter ++;
                                ?>
                                <div class="col-md-6 feature_box">
                                    <?php
                                    if ( has_post_thumbnail() ) {
                                        $about_skill_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
                                        $post_id           = get_the_ID();
                                        $thumbnail_id      = get_post_thumbnail_id( $post_id );
                                        $img_alt           = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                                        ?>
                                        <img src="<?php echo esc_url( $about_skill_image[0] ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>"/>
                                    <?php } ?>
                                    <h3><?php the_title(); ?></h3>
                                    <?php the_content(); ?>
                                </div><!-- end of col-md-6 -->
                                <?php
                                if ( is_int( $skills_counter / 2 ) ) {
                                    ?>
                                    <div class="clearfix"></div>
                                    <?php
                                }
                                ?>
                                <?php
                            }
                            wp_reset_postdata();
                        }
                    }
                    ?>

                </div><!-- end of col-md-8 -->
            </div><!-- end of row -->
        </div><!-- end of container -->
    </section>
    <?php
