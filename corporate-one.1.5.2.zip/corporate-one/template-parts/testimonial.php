<?php
/**
 * Testimonial section
 *
 * @package corporate-one
 */


    // fetch page.
    $corporate_one_testimonial_title_subtitle = get_theme_mod( 'corporate_one_testimonial_title_subtitle' );

    // fetch post categories.
    $corporate_one_testimonial_category = get_theme_mod( 'corporate_one_testimonial_category' );

    if ( ! empty( $corporate_one_testimonial_category ) ) {
        $cat_obj_test  = get_term( $corporate_one_testimonial_category, 'category' );
        $cat_type_test = $cat_obj_test->name;

        $args_test         = array(
            'posts_per_page'   => 30,
            'offset'           => 0,
            'category_name'    => $cat_type_test,
            'orderby'          => 'post_date',
            'order'            => 'ASC',
            'post_type'        => 'post',
            'post_status'      => 'publish',
            'suppress_filters' => false,
        );
        $testimonial_posts = new WP_Query( $args_test );
    }
    ?>

    <!-- page title and img -->
    <?php
    if ( $corporate_one_testimonial_title_subtitle ) {
        remove_filter( 'the_excerpt', 'wpautop' );

        $tst_qry = new WP_Query(
            array(
                'page_id' => $corporate_one_testimonial_title_subtitle,
            )
        );

        if ( $tst_qry->have_posts() ) {
            while ( $tst_qry->have_posts() ) {
                $tst_qry->the_post();
                if ( has_post_thumbnail() ) {
                    $corporate_one_tst_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
                } else {
                    $corporate_one_tst_image[0] = '';
                }
                ?>
                <section id="testimonial" style="background:url('<?php echo esc_url( $corporate_one_tst_image[0] ); ?>'); background-size:cover; background-position:center;">
                <div class="transprent">
                <div class="container testimonial_container">
                <div class="row">
                <h1><?php the_title(); ?></h1>
                <?php
                if ( get_the_content() != '' ) {
                    ?>
                    <p class="subtitle fancy"><span>
											<?php
                                            add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            the_excerpt();
                                            remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            ?>
										</span></p>
                    <?php
                }
                ?>
                <?php
            }
        }
        wp_reset_postdata();
        add_filter( 'the_excerpt', 'wpautop' );
    }
    ?>


    <?php
    $slide_counter2 = 0;
if ( ! empty( $corporate_one_testimonial_category ) ) {
    ?>
    <!-- carousel -->
    <div id="corporate_one_testimonial_slider" class="carousel slide carousel-fade" data-ride="carousel">

    <div class="carousel-inner" role="listbox">
        <?php
        $slide_counter1 = 1;
        $tsn2           = 0;
        if ( $testimonial_posts->have_posts() ) {
            while ( $testimonial_posts->have_posts() ) :
                $testimonial_posts->the_post();
                $tsn2++;
                // Getting ID of the current post.
                $post_id = get_the_ID();

                // Getting individual options of each post.
                $tw_testimonial_img = wp_get_attachment_url( get_post_thumbnail_id( $post_id ) );
                $thumbnail_id       = get_post_thumbnail_id( $post_id );
                $img_alt            = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                ?>
                <div class="testimonial_main_div item <?php echo ( 1 === $slide_counter1 ) ? 'active' : ''; ?>">
                    <div class="col-md-4 col-sm-4 client_img"><img src="<?php echo esc_url( $tw_testimonial_img ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>"/></div>
                    <div  class="col-md-8 col-sm-8 testmonial_content">
                        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/quote.png' ); ?>" alt="<?php echo esc_attr_e( 'quote icon', 'corporate-one' ); ?>" />
                        <?php the_content(); ?>
                    </div>
                </div>
                <?php
                $slide_counter1++;
            endwhile;
        }

        ?>

    </div><!-- end of carousel inner -->
    <div class="testimonial_arrows">
        <a class="arrow_left" href="#corporate_one_testimonial_slider" data-slide="prev"><i class="icon-caret-left" aria-hidden="true"></i></a>
        <a class="arrow_right" href="#corporate_one_testimonial_slider" data-slide="next"><i class="icon-caret-right" aria-hidden="true"></i></a>
    </div>
    <?php
} //end of if
    ?>
    </div>
    </div><!-- end of container -->
    </div>
    </div>
    </section>
