<?php
/**
 * Experience section
 *
 * @package corporate-one
 */

    // fetch page.
    $corporate_one_experience_title_subtitle = get_theme_mod( 'corporate_one_experience_title_subtitle' );

    // fetch post categories.
    $corporate_one_experience_category = get_theme_mod( 'corporate_one_experience_category' );
    ?>

    <section id="experience">
        <div class="container">
            <div class="row">
                <?php
                if ( $corporate_one_experience_title_subtitle ) {
                    remove_filter( 'the_excerpt', 'wpautop' );
                    $corporate_one_experience_title_subtitle_query = new WP_Query(
                        array(
                            'page_id' => $corporate_one_experience_title_subtitle,
                        )
                    );

                    if ( $corporate_one_experience_title_subtitle_query->have_posts() ) {
                        while ( $corporate_one_experience_title_subtitle_query->have_posts() ) {
                            $corporate_one_experience_title_subtitle_query->the_post();
                            ?>
                            <h1><?php the_title(); ?></h1>
                            <?php
                            if ( get_the_content() != '' ) {
                                ?>
                                <p class="subtitle fancy"><span>
											<?php
                                            add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            the_excerpt();
                                            remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                            ?>
										</span></p>
                                <?php
                            }
                            ?>
                            <?php
                        }
                    }
                    wp_reset_postdata();
                    add_filter( 'the_excerpt', 'wpautop' );
                }
                ?>

                <div class="experience_container">
                    <?php
                    if ( $corporate_one_experience_category ) {
                        $corporate_one_experience_category_posts = new WP_Query(
                            array(
                                'cat'            => $corporate_one_experience_category,
                                'posts_per_page' => 4,
                                'ignore_sticky_posts' => true,
                            )
                        );
                        $experience_counter                      = 1;
                        if ( $corporate_one_experience_category_posts->have_posts() ) {
                            while ( $corporate_one_experience_category_posts->have_posts() ) {
                                $corporate_one_experience_category_posts->the_post();

                                if ( 1 === $experience_counter % 2 ) {
                                    ?>
                                    <div class="timeline-block timeline-block-right">
                                        <div class="marker"></div>
                                        <div class="timeline-content">
											<span>
											<?php
                                            $articletags = strip_tags( get_the_tag_list( '', ', ', '' ) );
                                            echo esc_html( $articletags );
                                            ?>
												</span>
                                            <h3><?php the_title(); ?></h3>
                                            <?php the_content(); ?>
                                        </div>
                                    </div>
                                    <?php
                                } elseif ( 0 === $experience_counter % 2 ) {
                                    ?>
                                    <div class="timeline-block timeline-block-left">
                                        <div class="marker"></div>
                                        <div class="timeline-content">
										<span>
											<?php
                                            $articletags = strip_tags( get_the_tag_list( '', ', ', '' ) );
                                            echo esc_html( $articletags );
                                            ?>
												</span>
                                            <h3><?php the_title(); ?></h3>
                                            <?php the_content(); ?>
                                        </div>
                                    </div>
                                <?php } ?>
                                <?php
                                $experience_counter++;
                            }
                            wp_reset_postdata();
                        }
                    }

                    ?>
                </div>
            </div><!-- end of .row -->
        </div><!-- end of .container -->
    </section>
