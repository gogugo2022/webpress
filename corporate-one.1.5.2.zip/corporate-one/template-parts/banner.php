<?php
/**
 * Banner section
 *
 * @package corporate-one
 */

$corporate_one_banner_post_1 = get_theme_mod( 'corporate_one_banner_post_1' );
$corporate_one_banner_post_2 = get_theme_mod( 'corporate_one_banner_post_2' );

$banner_posts = array( $corporate_one_banner_post_1, $corporate_one_banner_post_2 );
$banner_posts = array_diff( array_unique( $banner_posts ), array( '' ) );

?>
<?php
if ( $banner_posts ) {
    $i                = 1;
    $banner_query     = new WP_Query(
        array(
            'post__in'            => $banner_posts,
            'orderby'             => 'post__in',
            'posts_per_page'      => 2,
            'ignore_sticky_posts' => true,
        )
    );
    $banner_title_2   = '';
    $banner_content_2 = '';

    if ( $banner_query->have_posts() ) {
        while ( $banner_query->have_posts() ) {
            $banner_query->the_post();

            if ( 2 == $i ) {
                $post_id_2        = get_the_ID();
                $banner_title_2   = get_the_title( $post_id_2 );
                $banner_content_2 = get_the_content( $post_id_2 );
                if ( has_post_thumbnail() ) {
                    $banner_img_2 = wp_get_attachment_url( get_post_thumbnail_id( $post_id_2 ) );
                } else {
                    $banner_img_2 = '';
                }
            } else {
                $post_id_1        = get_the_ID();
                $banner_title_1   = get_the_title( $post_id_1 );
                $banner_content_1 = get_the_content( $post_id_1 );
                if ( has_post_thumbnail() ) {
                    $banner_img_1 = wp_get_attachment_url( get_post_thumbnail_id( $post_id_1 ) );
                } else {
                    $banner_img_1 = '';
                }
            }
            $i++;
        }
        wp_reset_postdata();
    }
    ?>
    <header id="intro" class="intro-section">
        <div class="header_image" style="background-image: url(<?php echo esc_url( $banner_img_1 ); ?>)">
            <div class="scene">
                <?php if ( isset( $banner_img_2 ) ) { ?>
                    <div data-offset="90" class="clouds parallax" style="background: url(<?php echo esc_url( $banner_img_2 ); ?>) no-repeat center"></div>
                <?php } ?>
            </div>

            <div class="caption">
                <span class="cursive_text"><?php echo esc_html( $banner_title_1 ); ?></span>
                <span class="bigtext"><?php echo esc_html( $banner_content_1 ); ?></span>
                <span class="normal_text"><?php echo esc_html( $banner_title_2 ); ?></span>
                <span class="banner_caption"><?php echo esc_html( $banner_content_2 ); ?></span>
            </div>
        </div>
    </header>
    <?php
}
