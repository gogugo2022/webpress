<?php
/**
 * Services section
 *
 * @package corporate-one
 */


// section title -page.
$corporate_one_services_title_subtitle = get_theme_mod( 'corporate_one_services_title_subtitle' );

$corporate_one_services_category_1 = get_theme_mod( 'corporate_one_services_category_1' );
$corporate_one_services_category_2 = get_theme_mod( 'corporate_one_services_category_2' );
$corporate_one_services_category_3 = get_theme_mod( 'corporate_one_services_category_3' );

$work_args_all = array(
    'posts_per_page'   => 30,
    'offset'           => 0,
    'cat'              => array( $corporate_one_services_category_1, $corporate_one_services_category_2, $corporate_one_services_category_3 ),
    'orderby'          => 'post_date',
    'order'            => 'ASC',
    'post_type'        => 'post',
    'post_status'      => 'publish',
    'suppress_filters' => false,
);
if ( ( ! empty( $corporate_one_services_category_1 ) ) || ( ! empty( $corporate_one_services_category_2 ) ) || ( ! empty( $corporate_one_services_category_3 ) ) ) {
    $corporate_one_services_category_all_posts = new WP_Query( $work_args_all );
}

if ( ! empty( $corporate_one_services_category_1 ) ) {
    $cat_obj                       = get_term( $corporate_one_services_category_1, 'category' );
    $corporate_one_services_1_name = $cat_obj->name;
    $corporate_one_services_1_slug = $cat_obj->slug;
}

if ( ! empty( $corporate_one_services_category_2 ) ) {
    $cat_obj2                      = get_term( $corporate_one_services_category_2, 'category' );
    $corporate_one_services_2_name = $cat_obj2->name;
    $corporate_one_services_2_slug = $cat_obj2->slug;
}
if ( ! empty( $corporate_one_services_category_3 ) ) {
    $cat_obj3                      = get_term( $corporate_one_services_category_3, 'category' );
    $corporate_one_services_3_name = $cat_obj3->name;
    $corporate_one_services_3_slug = $cat_obj3->slug;
}
?>

    <section id="services" class="services-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- page title and description -->
                    <?php
                    if ( $corporate_one_services_title_subtitle ) {
                        remove_filter( 'the_excerpt', 'wpautop' );
                        $corporate_one_services_title_subtitle_query = new WP_Query(
                            array(
                                'page_id' => $corporate_one_services_title_subtitle,
                            )
                        );

                        if ( $corporate_one_services_title_subtitle_query->have_posts() ) {
                            while ( $corporate_one_services_title_subtitle_query->have_posts() ) {
                                $corporate_one_services_title_subtitle_query->the_post();
                                ?>
                                <h1><?php the_title(); ?></h1>
                                <?php
                                if ( get_the_content() != '' ) {
                                    ?>
                                    <p class="subtitle fancy"><span>
									<?php
                                    add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                    the_excerpt();
                                    remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_subtitle' );
                                    ?>
								</span></p>
                                    <?php
                                }
                                ?>
                                <?php
                            }
                        }
                        wp_reset_postdata();
                        add_filter( 'the_excerpt', 'wpautop' );
                    }
                    ?>
                    <?php if ( ( ! empty( $corporate_one_services_category_1 ) ) || ( ! empty( $corporate_one_services_category_2 ) ) || ( ! empty( $corporate_one_services_category_3 ) ) ) { ?>
                        <div id="project_gallery" class="button-group filters-button-group corporate_one_tabs">
                            <button class="is-checked" data-filter="*"><?php echo esc_html( __( 'All', 'corporate-one' ) ); ?></button>
                            <?php if ( ! empty( $corporate_one_services_1_slug ) ) { ?>
                                <button class="" data-filter=".<?php echo esc_attr( $corporate_one_services_1_slug ); ?>"><?php echo esc_html( $corporate_one_services_1_name ); ?>
                                </button>
                            <?php } ?>
                            <?php if ( ! empty( $corporate_one_services_2_slug ) ) { ?>
                                <button class="" data-filter=".<?php echo esc_attr( $corporate_one_services_2_slug ); ?>"><?php echo esc_html( $corporate_one_services_2_name ); ?>
                                </button>
                            <?php } ?>
                            <?php if ( ! empty( $corporate_one_services_3_slug ) ) { ?>
                                <button class="" data-filter=".<?php echo esc_attr( $corporate_one_services_3_slug ); ?>"><?php echo esc_html( $corporate_one_services_3_name ); ?>
                                </button>
                            <?php } ?>
                        </div>
                    <?php } ?>
                    <div class="grid row">
                        <?php

                        $wn = 0;
                        if ( ! empty( $corporate_one_services_category_all_posts ) ) {
                            if ( $corporate_one_services_category_all_posts->have_posts() ) {

                                while ( $corporate_one_services_category_all_posts->have_posts() ) :
                                    $corporate_one_services_category_all_posts->the_post();
                                    $wn++;
                                    $post_id = get_the_ID();

                                    $test = get_the_terms( $post_id, 'category' );
                                    foreach ( $test as $singleterm ) {
                                        $value_new[] = $singleterm->slug;
                                    }

                                    $co_portfolio_img = wp_get_attachment_url( get_post_thumbnail_id( $post_id ) );
                                    $thumbnail_id     = get_post_thumbnail_id( $post_id );
                                    $img_alt          = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                                    ?>
                                    <div class="element-item col-lg-4 col-md-4 col-sm-4 col-xs-6 text-center tw_portfolio_each <?php echo esc_attr( implode( ' ', $value_new ) ); ?>" >
                                        <figure class="imghvr-push-up">
                                            <img src="<?php echo esc_url( $co_portfolio_img ); ?>" class="img-responsive tw_work_img" alt="<?php echo esc_attr( $img_alt ); ?>">
                                            <figcaption>
                                                <div class="magnific-popup">
                                                    <div class="tw_portfolio_title_metabox"><?php the_title(); ?></div>
                                                    <div class="tw_portfolio_desc_metabox">
                                                        <?php
                                                        add_filter( 'excerpt_length', 'corporate_one_sections_excerpt_length' );
                                                        the_excerpt();
                                                        remove_filter( 'excerpt_length', 'corporate_one_sections_excerpt_length' );
                                                        ?>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <?php
                                    unset( $value_new );
                                endwhile;
                                wp_reset_postdata();
                            } // end of if
                        }
                        ?>
                    </div><!-- end of class .grid -->

                </div>
            </div>
        </div>
    </section>
