<?php
/**
 * Template part for displaying a post's summary
 *
 * @package buddyx
 */

namespace BuddyX\Buddyx;

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
