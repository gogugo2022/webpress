    <div class="content-block">
	  <div class="content-block-inner">
	    <?php dynamic_sidebar('wpappninja-after'); ?>
	  </div>
	</div>
	
  </div>

  <?php wp_footer(); ?>

</body>
</html>
