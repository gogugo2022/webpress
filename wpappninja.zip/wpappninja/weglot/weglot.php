<?php

require(dirname(__FILE__) . '/lib/WG.php');
require(dirname(__FILE__) . '/lib/WGClient.php');
require(dirname(__FILE__) . '/lib/WGUtils.php');
require(dirname(__FILE__) . '/lib/WeglotException.php');
