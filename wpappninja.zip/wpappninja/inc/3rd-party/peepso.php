<?php
defined( 'ABSPATH' ) or die( 'Cheatin\' uh?' );


add_action('init', 'wpmobile_remove_shortcode_filter_peepso', PHP_INT_MAX);
function wpmobile_remove_shortcode_filter_peepso() {

    if (class_exists('PeepSo')) {
        remove_action( 'pre_get_posts', 'wpmobileapp_pre_get_posts' );
    }
}
