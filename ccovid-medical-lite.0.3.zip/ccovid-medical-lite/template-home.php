<?php
/**
 * @package CCovid Medical Lite
 */
?>
<?php
$boxvariable = array();
for ($k = 1; $k <= 3; $k++) {
    ?>
    <?php $boxid    = absint(get_theme_mod('ccovid_medical_lite_box' . $k)); ?>
    <?php $boxquery = new WP_query('page_id=' . $boxid); ?>
    <?php
    if ($boxquery->have_posts() && $boxid > 0) :
        while ($boxquery->have_posts()) : $boxquery->the_post();
            $thumbnail_id  = get_post_thumbnail_id($post->ID);
            $alt           = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
            $image         = get_the_post_thumbnail_url($post->ID, 'ccovid-medical-lite-home-box-size');
            $boxtitle      = get_the_title($post->ID);
            $my_postid     = $post->ID;
            $content       = ccovid_medical_lite_get_excerpt($my_postid, '250');
            $url           = get_the_permalink($my_postid);
            $boxvariable[] = array('boxid' => $post->ID, 'boximage' => $image, 'alt' => $alt, 'box_title' => $boxtitle, 'box_content' => $content, 'url' => $url);
        endwhile;
        wp_reset_postdata();
    endif;
    ?>

<?php } ?>
<section style="background-color:#ffffff; " id="pageboxes">
    <div class="container">
        <div class="pageclmn fadeInRight">

            <?php
            $ccovid_medical_lite_sort_id = 1;
            foreach ($boxvariable as $boxvariables) {
                ?>
                <div class="threebox threebox-<?php echo esc_html($ccovid_medical_lite_sort_id); ?>">
                    <a href="<?php echo esc_url($boxvariables['url']); ?>">
                        <div class="thumbbx img-responsive img-thumbnail"><img alt="<?php echo esc_attr($boxvariables['alt']); ?>" src="<?php echo esc_url($boxvariables['boximage']); ?>"></div>
                    </a>
                    <div class="resourcebox">
                        <div class="top-resourcebox">
                            <a href="<?php echo esc_url($boxvariables['url']); ?>"><h3><?php echo esc_html($boxvariables['box_title']); ?></h3> </a>
                        </div><!--top-resourcebox-->
                        <p><?php
                            $boxid                       = esc_html($boxvariables['boxid']);
                            echo esc_html(ccovid_medical_lite_get_excerpt($boxid, 150));
                            ?>
                        </p>
                        <?php
                        $ccovid_medical_lite_box_cta = get_theme_mod('ccovid_medical_lite_box_cta');
                        if (!empty($ccovid_medical_lite_box_cta)) {
                            ?>
                            <a class="rdmore" href="<?php echo esc_url($boxvariables['url']); ?>"><?php echo esc_html($ccovid_medical_lite_box_cta) ?></a>
                        <?php } ?>
                    </div><!--resourcebox-->
                </div>
                <?php
                $ccovid_medical_lite_sort_id++;
            }
            ?>

        </div><!-- middle-align -->
        <div class="clear"></div>
    </div><!-- container -->
</section>