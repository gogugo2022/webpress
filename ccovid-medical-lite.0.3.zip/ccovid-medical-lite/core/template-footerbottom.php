<div class="footerinner-bottom">
    <div class="container">
        <div class="footer-bottom">
            <div class="copyright mainwidth">
                <div class="creditcopy">
                    <?php $ccovid_medical_lite_copyright = get_theme_mod('ccovid_medical_lite_copyright'); ?>
                    <?php if (get_theme_mod('ccovid_medical_lite_copyright')) { ?>
                        <?php echo esc_html($ccovid_medical_lite_copyright); ?>
                    <?php } ?>

                </div><!--creditcopy-->
                <div class="creditlink">
                    <?php $ccovid_medical_lite_design = get_theme_mod('ccovid_medical_lite_design'); ?>
                    <?php if (get_theme_mod('ccovid_medical_lite_design')) { ?>
                        <?php echo esc_html($ccovid_medical_lite_design); ?>
                    <?php } ?>
                </div><!--creditlink-->

                <div class="clear"></div>
            </div>
        </div><!--footer-bottom-->
    </div>

</div><!--footerinner-bottom-->