<?php

function ccovid_medical_lite_style() {
    wp_enqueue_style('ccovid-medical-lite-basic-style', get_stylesheet_uri());
    wp_enqueue_style('ccovid-medical-lite-style', get_template_directory_uri() . '/skin/css/main.css');
    wp_enqueue_style('ccovid-medical-lite-responsive', get_template_directory_uri() . '/skin/css/responsive.css');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/skin/css/font-awesome.css');
    wp_enqueue_script('ccovid-medical-lite-toggle', get_template_directory_uri() . '/skin/js/toggle.js', array('jquery'));
    wp_enqueue_script('ccovid-medical-lite-customjs', get_template_directory_uri() . '/skin/js/customjs.js', array('jquery'));
}

add_action('wp_enqueue_scripts', 'ccovid_medical_lite_style');
?>
<?php

function ccovid_medical_lite_header_style() {
    $ccovid_medical_lite_header_text_color = get_header_textcolor();
    if (get_theme_support('custom-header', 'default-text-color') === $ccovid_medical_lite_header_text_color) {
        return;
    }
    echo '<style id="ccovid-medical-lite-custom-header-styles" type="text/css">';
    if ('blank' !== $ccovid_medical_lite_header_text_color) {
        echo '.header_top .logo a,
            .blog-post h3 a,
            .blog-post .pageheading h1
			 {
				color: #' . esc_attr($ccovid_medical_lite_header_text_color) . '
			}';
    }
    echo '</style>';
}
