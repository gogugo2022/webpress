<?php
if (!isset($content_width))
    $content_width = 900;

add_action('admin_menu', 'ccovid_medical_lite_pros');

function ccovid_medical_lite_pros() {
    add_theme_page(esc_html__('CCovid Medical Lite Details', 'ccovid-medical-lite'), esc_html__('CCovid Medical Lite Details', 'ccovid-medical-lite'), 'edit_theme_options', 'ccovid_medical_lite_pro', 'ccovid_medical_lite_pro_details');
}

function ccovid_medical_lite_pro_details() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('CCovid Medical Lite', 'ccovid-medical-lite'); ?></h1>

        <div>
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/skin/images/innerbanner.jpg" alt="<?php bloginfo('name'); ?>" style=" width: 100%;"> 
        </div>

        <p><strong> <?php esc_html_e('Description: ', 'ccovid-medical-lite'); ?></strong><?php esc_html_e('CCovid Medical Lite WordPress theme is beautiful & clean and its free multipurpose medical theme, Which is used most of SARS, Covid-19, general clinics, dental, hospital, gynecology, veterinary clinics, nursing home and overall medial websites as well as personal portfolio sites for surgeons, gynecologist, general therapist, doctors and for all medical sector people. It also used for ambulance services, government hospitals, private clinics, covid center, blood test, multi slice CT Scan,Radiography, CT angiography, CT Urography, Digital S-Ray, 4D Sonography, Elastography, Pathology, Health checkup, Color Doppler, 5D Sonography, medical stores, nursing homes, veterinary clinics, pharmaceuticals, physiotherapy centers and spa and massage centers. This Free Medical theme is fully responsive, cross-browser compatible. CCovid Medical Lite is supported to the latest WordPress version and easily customize all sections.', 'ccovid-medical-lite'); ?></p>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_THEMEURL); ?>" target="_blank"><?php esc_html_e('Theme Url', 'ccovid-medical-lite'); ?></a>	
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_PROURL); ?>" target="_blank"><?php esc_html_e('Pro Theme Url', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_PURCHASEURL); ?>" target="_blank"><?php esc_html_e('Click To Purchase', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_PURCHASEURL); ?>" target="_blank"><?php esc_html_e('Price: $29 Only', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_DOCURL); ?>" target="_blank"><?php esc_html_e('Documentation', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_DEMOURL); ?>" target="_blank"><?php esc_html_e('View Demo', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="<?php echo esc_url(ccovid_medical_lite_SUPPORTURL); ?>" target="_blank"><?php esc_html_e('Support', 'ccovid-medical-lite'); ?></a>
        <a class="button button-primary button-large" href="mailto:<?php echo esc_html(ccovid_medical_lite_SUPPORT_EMAIL); ?>" target="_blank"><?php esc_html_e('Support Email', 'ccovid-medical-lite'); ?></a>

    </div> 
    </div>
<?php
}

add_action('customize_register', 'ccovid_medical_lite_customize_register');
define('ccovid_medical_lite_PROURL', 'https://www.themescave.com/themes/wordpress-theme-ccovid-medical-lite/');
define('ccovid_medical_lite_THEMEURL', 'https://www.themescave.com/themes/wordpress-theme-ccovid-medical-lite/');
define('ccovid_medical_lite_DOCURL', 'https://www.themescave.com/demo/ccovid-medical-pro');
define('ccovid_medical_lite_DEMOURL', 'https://www.themescave.com/demo/ccovid-medical-pro');
define('ccovid_medical_lite_SUPPORTURL', 'https://www.themescave.com/forums/forum/ccovid-medical/');
define('ccovid_medical_lite_PURCHASEURL', 'https://www.themescave.com/themes/?add-to-cart=3404');
define('ccovid_medical_lite_SUPPORT_EMAIL', 'support@themescave.com');

