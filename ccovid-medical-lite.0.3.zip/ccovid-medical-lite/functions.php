<?php

/**
 * @package CCovid Medical Lite
 */
require_once get_template_directory() . "/basic/setup-functions.php";
require_once get_template_directory() . "/core/customization.php";
require_once get_template_directory() . "/basic/style-functions.php";
require_once get_template_directory() . "/basic/widget-functions.php";
require_once get_template_directory() . "/basic/theme-functions.php";
if (!function_exists('wp_body_open')) {

    function wp_body_open() {
        do_action('wp_body_open');
    }

}

function ccovid_medical_lite_embed_html($html) {
    return '<div class="video-container">' . $html . '</div>';
}

add_filter('embed_oembed_html', 'ccovid_medical_lite_embed_html', 10, 3);
add_filter('video_embed_html', 'ccovid_medical_lite_embed_html');
add_image_size('ccovid-medical-lite-home-box-size', 400, 250, true);

function ccovid_medical_lite_get_excerpt($postid, $post_count_size) {
    $excerpt = get_post_field('post_content', $postid);

    $excerpt = preg_replace(" ([.*?])", '', $excerpt);
    $excerpt = strip_shortcodes($excerpt);
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, $post_count_size);
    $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
    return $excerpt;
}

function ccovid_medical_lite_sanitize_phone_number($phone) {
    return preg_replace('/[^\d+]/', '', $phone);
}

if (!function_exists('ccovid_medical_lite_entry_meta')) :

    /**
     * Prints HTML with meta information for the categories, tags and comments.
     */
    function ccovid_medical_lite_entry_meta() {
        // Hide category and tag text for pages.
        if ('post' === get_post_type()) {
            /* translators: used between list items, there is a space after the comma */
            $categories_list = get_the_category_list(esc_html__(', ', 'ccovid-medical-lite'));
            if ($categories_list && ccovid_medical_lite_categorized_blog()) {
                printf('<span class="cat-links">%1$s</span>', $categories_list); // WPCS: XSS OK.
            }
        }

        if (is_single() && !post_password_required() && ( comments_open() || get_comments_number() )) {
            echo '<span class="comments-link">';
            /* translators: %s: post title */
            comments_popup_link(sprintf(wp_kses(__('Leave a Comment<span class="screen-reader-text"> on %s</span>', 'ccovid-medical-lite'), array('span' => array('class' => array()))), get_the_title()));
            echo '</span>';
        }
    }

endif;

/**

  /**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function ccovid_medical_lite_categorized_blog() {
    if (false === ( $all_the_cool_cats = get_transient('ccovid_medical_lite_categories') )) {
        // Create an array of all the categories that are attached to posts.
        $all_the_cool_cats = get_categories(array(
            'fields'     => 'ids',
            'hide_empty' => 1,
            // We only need to know if there is more than one category.
            'number'     => 2,
        ));

        // Count the number of categories that are attached to the posts.
        $all_the_cool_cats = count($all_the_cool_cats);

        set_transient('ccovid_medical_lite_categories', $all_the_cool_cats);
    }

    if ($all_the_cool_cats > 1) {
        // This blog has more than 1 category so ccovid_medical_lite_categorized_blog should return true.
        return true;
    } else {
        // This blog has only 1 category so ccovid_medical_lite_categorized_blog should return false.
        return false;
    }
}

if (!function_exists('ccovid_medical_lite_posted_on')) :

    /**
     * Prints HTML with meta information for the current post-date/time and author.
     */
    function ccovid_medical_lite_posted_on() {
        $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';


        $time_string = sprintf(
                $time_string,
                esc_attr(get_the_date(DATE_W3C)),
                esc_html(get_the_date())
        );
        echo '<span class="posted-on">';
        printf(
                /* translators: %s: Publish date. */
                esc_html('%s'),
                $time_string // phpcs:ignore WordPress.Security.EscapeOutput
        );
        echo '</span>';
    }

endif;

