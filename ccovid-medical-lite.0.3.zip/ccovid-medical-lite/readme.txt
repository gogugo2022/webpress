=== CCovid Medical Lite ===
Contributors: themescave
Tags: custom-menu,one-column,right-sidebar,theme-options,threaded-comments,translation-ready,blog,custom-background,custom-colors,custom-header,featured-images,full-width-template,two-columns,portfolio,sticky-post,news
Requires at least: 4.0
Tested up to: 5.7.2
Requires PHP: 5.2
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Theme License & Copyright == 
CCovid Medical Lite WordPress Theme, Copyright 2020 themescave(themescave.com)
CCovid Medical Lite is distributed under the terms of the GNU GPL

== Description ==
CCovid Medical Lite WordPress theme is beautiful & clean and its free multipurpose medical theme, Which is used most of SARS, Covid-19, general clinics, dental, hospital, gynecology, veterinary clinics, nursing home and overall medial websites as well as personal portfolio sites for surgeons, gynecologist, general therapist, doctors and for all medical sector people. It also used for ambulance services, government hospitals, private clinics, covid center, blood test, multi slice CT Scan,Radiography, CT angiography, CT Urography, Digital S-Ray, 4D Sonography, Elastography, Pathology, Health checkup, Color Doppler, 5D Sonography, medical stores, nursing homes, veterinary clinics, pharmaceuticals, physiotherapy centers and spa and massage centers. This Free Medical theme is fully responsive, cross-browser compatible. CCovid Medical Lite is supported to the latest WordPress version and easily customize all sections

== Frequently Asked Questions ==

= How to Customize Theme =

Just click on Appearance -> customize
Then you will find section to edit and update it

= How to Customize Header Phone, Email and address =
Just click on Appearance -> Customize -> Header Phone, Email and address.

= How to Customize Header Social Link =
Just click on Appearance -> Customize -> Social Link.

= How to Customize Header Home banner =
Just click on Appearance -> Customize -> Header Image

= How to Customize Header Home banner heading and subheading =
Just click on Appearance -> Customize ->  Home banner Text

= How to Customize footer Copyright =
Just click on Appearance -> Customize -> Footer

= How to Customize top 3 resource box =
Just click on Appearance -> Customize -> resource section


== Changelog ==

= 0.1 =
* Launched this version

= 0.2 =
* changed in readme.txt file
* changed function file name
* solved issue related global variable

= 0.3 =
* changed esc_html to esc_attr.
* added underline to link

== Upgrade Notice ==

= 0.3 =
* changed esc_html to esc_attr.
* added underline to link

= Font Awesome =
* https://fontawesome.com/icons

# Icons: CC BY 4.0 License (https://creativecommons.org/licenses/by/4.0/)
        In the Font Awesome Free download, the CC BY 4.0 license applies to all icons packaged as SVG and JS file types.

# Fonts: SIL OFL 1.1 License (https://scripts.sil.org/OFL)
        In the Font Awesome Free download, the SIL OFL license applies to all icons packaged as web and desktop font files.

# Code: MIT License (https://opensource.org/licenses/MIT)
        In the Font Awesome Free download, the MIT license applies to all non-font and non-icon files.


= Images =

*	https://stocksnap.io/photo/doctor-mask-GWE6UQDBTN
*	License: stocksnap provides images under CC0 license
* 	https://creativecommons.org/about/cc0

*	https://stocksnap.io/photo/doctor-mask-9BIAIEZCTX
*	License: stocksnap provides images under CC0 license
* 	https://creativecommons.org/about/cc0    

*	https://stocksnap.io/photo/chair-dentist-3J10QN5PTS
*	License: stocksnap provides images under CC0 license
* 	https://creativecommons.org/about/cc0    

*	https://stocksnap.io/photo/coronavirus-disease-FKFWYPC2DM
*	License: pxhere provides images under CC0 license
* 	https://creativecommons.org/about/cc0  

*	https://stocksnap.io/photo/caregiver-nurse-TBEMNLXLVQ
*	License: pxhere provides images under CC0 license
* 	https://creativecommons.org/about/cc0  