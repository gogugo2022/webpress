<?php
/**
 * footer Template.
 *
 * @package CCovid Medical Lite
 */
?>
<footer>	
	<?php get_template_part('core/template', 'footerbottom');?>		
</footer>
<?php wp_footer(); ?>

</body>
</html>