<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $post;

// Ensure visibility.
if ( empty( $post ) ) {
    return;
}
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

get_header(); 
?>

<div id="inner-content-wrapper" class="wrapper page-section">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
            <div class="single-wrapper">
		<?php 
        do_action( 'single_company_before_start' );
        do_action( 'single_company_start' );
        do_action( 'single_company' );
        do_action( 'single_company_end' );
        do_action( 'single_company_after_end' );
        ?>
            </div><!-- single-wrapper-->
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php  
	if ( onjob_is_sidebar_enable() ) {
		get_sidebar();
	}
	?>
</div><!-- .page-section -->
<?php
get_footer();

