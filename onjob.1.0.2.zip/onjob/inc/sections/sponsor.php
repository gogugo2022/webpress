<?php
/**
 * Banner section
 *
 * This is the template for the content of sponsor section
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */
if ( ! function_exists( 'onjob_add_sponsor_section' ) ) :
    /**
    * Add sponsor section
    *
    *@since  Onjob 1.0.0
    */
    function onjob_add_sponsor_section() {
    	$options = onjob_get_theme_options();
        // Check if sponsor is enabled on frontpage
        $sponsor_enable = apply_filters( 'onjob_section_status', true, 'sponsor_section_enable' );

        if ( true !== $sponsor_enable ) {
            return false;
        }
        // Get sponsor section details
        $section_details = array();
        $section_details = apply_filters( 'onjob_filter_sponsor_section_details', $section_details );

        if ( empty( $section_details ) ) {
            return;
        }

        // Render sponsor section now.
        onjob_render_sponsor_section( $section_details );
}

endif;

if ( ! function_exists( 'onjob_get_sponsor_section_details' ) ) :
    /**
    * sponsor section details.
    *
    * @since  Onjob 1.0.0
    * @param array $input sponsor section details.
    */
    function onjob_get_sponsor_section_details( $input ) {
        $options = onjob_get_theme_options();

        // Content type.
        $sponsor_content_type    = $options['sponsor_content_type'];
        $sponsor_count           = ! empty( $options['sponsor_count'] ) ? $options['sponsor_count'] : 5;
        
        $content = array();
        $page_ids = array();

        for ( $i = 1; $i <= $sponsor_count; $i++ ) {
            if ( ! empty( $options['sponsor_content_page_' . $i] ) )
                $page_ids[] = $options['sponsor_content_page_' . $i];
        }

        $args = array(
            'post_type'         => 'page',
            'post__in'          => ( array ) $page_ids,
            'posts_per_page'    => absint( $sponsor_count ),
            'orderby'           => 'post__in',
        );                    
       
        // Run The Loop.
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) : while ( $query->have_posts() ) :
            $query->the_post();
            $page_post['id']        = get_the_id();
            $page_post['title']     = get_the_title();
            $page_post['url']       = get_the_permalink();
            $page_post['image']     = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_id(), 'thumbnail' ) : get_template_directory_uri().'/assets/uploads/no-featured-image-600x450.jpg';

            // Push to the main array.
            array_push( $content, $page_post );
        endwhile; endif;

        wp_reset_postdata();

        if ( ! empty( $content ) ) {
            $input = $content;
        }
        return $input;
    }
endif;
// sponsor section content details.
add_filter( 'onjob_filter_sponsor_section_details', 'onjob_get_sponsor_section_details' );


if ( ! function_exists( 'onjob_render_sponsor_section' ) ) :
  /**
   * Start sponsor section
   *
   * @return string sponsor content
   * @since  Onjob 1.0.0
   *
   */
   function onjob_render_sponsor_section( $content_details = array() ) {
        $options = onjob_get_theme_options();

        if ( empty( $content_details ) ) {
            return;
        } ?>
        
            <div id="sponsor-section" class="relative page-section same-background">
                <div class="wrapper">
                    <div class="section-content col-5 clear">
                        <?php foreach ( $content_details as $content ) : ?>
                        <article>
                            <div class="featured-image">
                                <a href="<?php echo esc_url( $content['url'] ); ?>" target="_blank"><img src="<?php echo esc_url($content['image']); ?>" alt="<?php echo esc_attr($content['title']); ?>"></a>
                            </div><!-- .featured-image -->
                        </article>
                        <?php endforeach; ?>
                    </div><!-- .col-5 -->                        
                </div><!-- .wrapper -->
            </div><!-- #sponsor-section -->
    <?php
    }    
endif;

