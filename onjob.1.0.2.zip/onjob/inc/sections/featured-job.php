<?php
/**
 * Featured Jobs section
 *
 * This is the template for the content of Featured Jobs section
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */
if ( ! function_exists( 'onjob_add_featured_job_section' ) ) :
    /**
    * Add Featured Jobs section
    *
    *@since  Onjob 1.0.0
    */
    function onjob_add_featured_job_section() {
        $options = onjob_get_theme_options();
        // Check if Featured Jobs is enabled on frontpage
        $featured_job_enable = apply_filters( 'onjob_section_status', true, 'featured_job_section_enable' );

        if ( true !== $featured_job_enable ) {
            return false;
        }
        // Get Featured Jobs section details
        $section_details = array();
        $section_details = apply_filters( 'onjob_filter_featured_job_section_details', $section_details );

        if ( empty( $section_details ) ) {
            return;
        }

        // Render Featured Jobs section now.
        onjob_render_featured_job_section( $section_details );
    }
endif;

if ( ! function_exists( 'onjob_get_featured_job_section_details' ) ) :
    /**
    * Featured Jobs section details.
    *
    * @since  Onjob 1.0.0
    * @param array $input Featured Jobs section details.
    */
    function onjob_get_featured_job_section_details( $input ) {
        $options = onjob_get_theme_options();

        // Content type.
        
        $featured_job_content_type = ! empty( $options['featured_job_content_type'] ) ? $options['featured_job_content_type'] : 'category';
        $featured_job_count = ! empty( $options['featured_job_count'] ) ? $options['featured_job_count'] : 5;
        
        $content = array();
        
        switch ( $featured_job_content_type ) {

            case 'category':
                $cat_ids = array();
                
                for ( $i = 0; $i < $featured_job_count; $i++ ) {
                    if ( ! empty( $options['featured_job_content_category_' . $i] ) ) :
                        $cat_ids[] = $options['featured_job_content_category_' . $i];
                    endif;
                }
                $args = array(
                    'taxonomy'             => 'category',
                    'terms'                =>  $cat_ids ,
                );                    
            break;

            case 'job_listing_category':
                $cat_ids = array();
                
                for ( $i = 0; $i < $featured_job_count; $i++ ) {
                    if ( ! empty( $options['featured_job_content_job_listing_category_' . $i] ) ) :
                        $cat_ids[] = $options['featured_job_content_job_listing_category_' . $i];
                    endif;
                }
                $args = array(
                    'taxonomy'             => 'job_listing_category',
                    'terms'                =>  $cat_ids ,
                );                 
            break;
      
            default:
            break;
        }

        foreach($args['terms'] as $tax_id):
            $term = get_term($tax_id, $args['taxonomy']);
            $page_post['title']     = $term->name;
            $page_post['id']        = $term->term_id;
            $page_post['url']       = get_term_link($term->slug, $args['taxonomy']);
            $page_post['excerpt']   = onjob_trim_description(15, $term);

            array_push( $content, $page_post );
        endforeach;

        if ( ! empty( $content ) ) {
            $input = $content;
        }
        return $input;
    }
endif;
// Featured Jobs section content details.
add_filter( 'onjob_filter_featured_job_section_details', 'onjob_get_featured_job_section_details' );


if ( ! function_exists( 'onjob_render_featured_job_section' ) ) :
  /**
   * Start Featured Jobs section
   *
   * @return string Featured Jobs content
   * @since  Onjob 1.0.0
   *
   */
   function onjob_render_featured_job_section( $content_details = array() ) {
        $options                = onjob_get_theme_options(); ?>

        <div id="featured-jobs" class="relative page-section">
            <div class="wrapper">
                <div class="section-header">
                    <p class="section-subtitle"><?php echo esc_html($options['featured_job_sub_title']); ?></p>
                    <h2 class="section-title"><?php echo esc_html($options['featured_job_title']); ?></h2>
                </div><!-- .section-header -->
            </div><!-- .wrapper -->

            <div class="career-slider wrapper" data-slick='{"slidesToShow": 4, "slidesToScroll": 1, "infinite": true, "speed": 1000, "dots": false, "arrows": true, "autoplay": true, "draggable": true }'>
                <?php foreach($content_details as $i=>$content): ?>
                <article>
                    <div class="item-wrapper">
                        <div class="icon-wrapper">
                            <a href="<?php echo esc_url($content['url']); ?>"><i class="fa <?php echo esc_attr( !empty( $options['featured_job_icon_' . (absint($i))] ) ? $options['featured_job_icon_' . (absint($i))] : 'fa-briefcase' ); ?>"></i></a>
                        </div><!-- .icon-wrapper -->

                        <header class="entry-header">
                            <h2 class="entry-title"><a href="<?php echo esc_url($content['url']); ?>"><?php echo esc_html($content['title']); ?></a></h2>
                        </header>

                        <div class="entry-content">
                            <p><?php echo wp_kses_post($content['excerpt']); ?></p>
                        </div><!-- .entry-content -->
                    </div><!-- .item-wrapper -->
                </article>
                <?php endforeach; ?>
            </div><!-- .career-slider -->
        </div><!-- #featured-jobs -->
       
<?php }
endif;  ?>