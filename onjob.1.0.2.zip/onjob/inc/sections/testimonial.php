<?php
/**
 * Testimonial section
 *
 * This is the template for the content of Testimonial section
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

if ( ! function_exists( 'onjob_add_testimonial_section' ) ) :
    /**
    * Add testimonial section
    *
    *@since  Onjob 1.0.0
    */
    function onjob_add_testimonial_section() {
    	$options = onjob_get_theme_options();
        // Check if testimonial is enabled on frontpage
        $testimonial_enable = apply_filters( 'onjob_section_status', true, 'testimonial_section_enable' );

        if ( true !== $testimonial_enable ) {
            return false;
        }
        // Get testimonial section details
        $section_details = array();
        $section_details = apply_filters( 'onjob_filter_testimonial_section_details', $section_details );
        if ( empty( $section_details ) ) {
            return ;
        }

        // Render testimonial section now.
        onjob_render_testimonial_section( $section_details );
    }
endif;

if ( ! function_exists( 'onjob_get_testimonial_section_details' ) ) :
    /**
    * testimonial section details.
    *
    * @since  Onjob 1.0.0
    * @param array $input testimonial section details.
    */
    function onjob_get_testimonial_section_details( $input ) {
        $options = onjob_get_theme_options();

        // Content type.
        $testimonial_count          = isset($options['testimonial_posts_count'] ) ? $options['testimonial_posts_count'] : 4;

        $content = array();
        $page_ids = array();

        for ( $i = 1; $i <= $testimonial_count; $i++ ) {
            if ( ! empty( $options['testimonial_content_page_' . $i] ) )
                $page_ids[] = $options['testimonial_content_page_' . $i];
        }

        $args = array(
            'post_type'         => 'page',
            'post__in'          => ( array ) $page_ids,
            'posts_per_page'    => absint( $testimonial_count ),
            'orderby'           => 'post__in',
        );

        // Run The Loop.
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) :
            $i = 1;
            while ( $query->have_posts() ) : $query->the_post();
                $page_post['content']        = onjob_trim_content(25);
                $page_post['title']          = get_the_title();
                $page_post['url']            = get_the_permalink();
                $page_post['image']          = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_id(), 'thumbnail' ) : get_template_directory_uri() . '/assets/uploads/no-featured-image-600x450.jpg';
                $page_post['designation']    = isset($options['testimonial_post_designation_'.$i])?$options['testimonial_post_designation_'.$i] : '';
                // Push to the main array.
                array_push( $content, $page_post );
                $i++;
            endwhile;
        endif;
        wp_reset_postdata();

        if ( ! empty( $content ) ) {
            $input = $content;
        }
        return $input;
    }
endif;
// testimonial section content details.
add_filter( 'onjob_filter_testimonial_section_details', 'onjob_get_testimonial_section_details' );


if ( ! function_exists( 'onjob_render_testimonial_section' ) ) :
  /**
   * Start testimonial section
   *
   * @return string testimonial content
   * @since  Onjob 1.0.0
   *
   */
   function onjob_render_testimonial_section( $content_details = array() ) {
    $options            = onjob_get_theme_options();
    $testimonial_bg_image = !empty($options['testimonial_bg_image']) ? $options['testimonial_bg_image'] : '';

    if ( empty( $content_details ) ) {
        return;
    } ?>

        <div id="testimonial-section" class="relative page-section">
            <div class="wrapper">
                <div class="testimonial-featured-image"
                    style="background-image: url('<?php echo esc_url($testimonial_bg_image); ?>');">
                </div><!-- .testimonial-featured-image -->

                <div class="testimonial-content">
                    <div class="section-header">
                        <p class="section-subtitle"><?php echo esc_html($options['testimonial_section_sub_title']); ?></p>
                        <h2 class="section-title"><?php echo esc_html($options['testimonial_section_title']); ?></h2>
                    </div><!-- .section-header -->

                    <div class="testimonial-slider" data-slick='{"slidesToShow": 1, "slidesToScroll": 1, "infinite": true, "speed": 1000, "dots": false, "arrows": true, "autoplay": true, "draggable": false, "fade": false }'>
                        <?php foreach($content_details as $content): ?>

                        <article>
                            <div class="entry-content">
                                <p><?php echo wp_kses_post($content['content']); ?></p>
                            </div><!-- .entry-content -->

                            <header class="entry-header">
                                <h2 class="entry-title"><a href="<?php echo esc_url($content['url']); ?>"><?php echo esc_html($content['title']); ?></a></h2>
                                <span class="position"><?php echo esc_html($content['designation']); ?></span>
                            </header>
                        </article>
                        <?php endforeach; ?>

                    </div><!-- .section-content -->
                </div><!-- .testimonial-content -->
            </div><!-- .wrapper -->
        </div><!-- #testimonial-section -->

<?php
    }
endif; ?>