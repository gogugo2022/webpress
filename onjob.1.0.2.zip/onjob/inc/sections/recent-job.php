<?php
/**
 * Recent Jobs section
 *
 * This is the template for the content of recent_job section
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */
if ( ! function_exists( 'onjob_add_recent_job_section' ) ) :
    /**
    * Add recent_job section
    *
    *@since  Onjob 1.0.0
    */
    function onjob_add_recent_job_section() {
    	$options = onjob_get_theme_options();

        // Check if recent_job is enabled on frontpage
        $recent_job_enable = apply_filters( 'onjob_section_status', true, 'recent_job_section_enable' );
        if(!class_exists('WP_Job_Manager') ) $recent_job_enable = false;

        if ( true !== $recent_job_enable ) {
            return false;
        }

        // Get recent_job section details
        $section_details = array();
        $section_details = apply_filters( 'onjob_filter_recent_job_section_details', $section_details );

        if ( empty( $section_details ) ) {
            return;
        }
        // Render recent_job section now.
        onjob_render_recent_job_section( $section_details );
    }
endif;

if ( ! function_exists( 'onjob_get_recent_job_section_details' ) ) :
    /**
    * recent_job section details.
    *
    * @since  Onjob 1.0.0
    * @param array $input recent_job section details.
    */
    function onjob_get_recent_job_section_details( $input ) {
        $options = onjob_get_theme_options();

        // Content type.
        $recent_job_count = ! empty( $options['recent_job_count'] ) ? $options['recent_job_count'] : 3;
        
        $content = array();
        $job_ids = array();

        for ( $i = 1; $i <= $recent_job_count; $i++ ) {
            if ( ! empty( $options['recent_job_content_post_' . $i] ) ) :
                $job_ids[] = $options['recent_job_content_post_' . $i];
            endif;
        }
        
        $args = array(
            'post_type'             => 'job_listing',
            'post__in'              => ( array ) $job_ids,
            'posts_per_page'        => absint( $recent_job_count ),
            'orderby'               => 'post__in',
            'ignore_sticky_posts'   => true,
        );                    

            // Run The Loop.
            $query = new WP_Query( $args );
            if ( $query->have_posts() ) : 
                while ( $query->have_posts() ) : $query->the_post();
                    $page_post['title']     = get_the_title();
                    $page_post['id']        = get_the_ID();
                    $page_post['excerpt']   = onjob_trim_content( 20);
                    $page_post['url']       = get_the_permalink();
                    $page_post['image']     = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_id(), 'thumbnail' ) : get_template_directory_uri() . '/assets/uploads/no-featured-image-600x450.jpg';

                    // Push to the main array.
                    array_push( $content, $page_post );
                endwhile;
            endif;
            wp_reset_postdata();
            
        if ( ! empty( $content ) ) {
            $input = $content;
        }
        return $input;
    }
endif;
// recent_job section content details.
add_filter( 'onjob_filter_recent_job_section_details', 'onjob_get_recent_job_section_details' );


if ( ! function_exists( 'onjob_render_recent_job_section' ) ) :
  /**
   * Start recent_job section
   *
   * @return string recent_job content
   * @since  Onjob 1.0.0
   *
   */
   function onjob_render_recent_job_section( $content_details = array() ) {
        $options = onjob_get_theme_options();

        if ( empty( $content_details ) ) {
            return;
        } ?>

        <div id="recent-jobs" class="relative page-section">
            <div class="wrapper">
                <div class="section-header-wrapper">
                    <div class="section-header">
                        <p class="section-subtitle"><?php echo esc_html($options['recent_job_sub_title']); ?></p>
                        <h2 class="section-title"><?php echo esc_html($options['recent_job_title']); ?></h2>
                    </div><!-- .section-header -->
                </div><!-- .section-header-wrapper -->

                <div class="section-content col-3 clear">
                <?php foreach ( $content_details as $content ) : ?>

                    <article>
                        <div class="item-wrapper">
                            <div class="entry-container">
                                <header class="entry-header">
                                    <h2 class="entry-title"><a href="<?php echo esc_url( $content['url'] )?>"><?php echo esc_html( $content['title'] )?></a></h2>
                                </header>

                                <?php if(class_exists('WP_Job_Manager') ): ?>
                                    <div class="entry-meta">
                                        <span class="location"><a href="#"><?php echo esc_html( get_the_job_location( $content['id'] ) ); ?></a></span>
                                        <span class="cat-links"><a href="#"><?php echo wpjm_the_job_types($content['id']); ?></a></span>
                                    </div><!-- .entry-meta -->
                                <?php endif; ?>
                            </div><!-- .entry-container -->

                            <div class="company-detail-wrapper">
                                <div class="company-detail">
                                    <div class="featured-image">
                                        <a href="<?php echo esc_url( $content['url'] )?>">
                                            <img src="<?php echo esc_url( $content['image'] )?>" alt="<?php echo esc_attr( $content['title'] )?>">
                                        </a>
                                    </div><!-- .featured-image -->
                                <?php if(class_exists('WP_Job_Manager') ) echo '<h3 class="company-name">'. get_the_company_name($content['id']). '</h3>'; ?>
                                </div>
                                <span class="posted-time"><?php onjob_posted_on( $content['id'] ); ?></span>
                            </div><!-- .company-detail-wrapper -->
                        </div><!-- .item-wrapper -->
                    </article>
                    <?php endforeach; ?>

                </div><!-- .section-content -->
            </div><!-- .wrapper -->
        </div><!-- #recent-jobs -->
<?php 
    }
endif;