<?php
/**
 * Banner section
 *
 * This is the template for the content of search section
 *
 * @package Theme Palace
 * @subpackage Onjob
 * @since Onjob 1.0.0
 */
if ( ! function_exists( 'onjob_add_search_section' ) ) :
    /**
    * Add search section
    *
    *@since Onjob 1.0.0
    */
    function onjob_add_search_section() {
    	$options = onjob_get_theme_options();
        // Check if search is enabled on frontpage
        $search_enable = apply_filters( 'onjob_section_status', true, 'search_section_enable' ) ;

        if ( true !== $search_enable ) {
            return false;
        }
        // Get search section details
        $section_details = array();
        $section_details = apply_filters( 'onjob_filter_search_section_details', $section_details );
        if ( empty( $section_details ) ) {
            return ;
        }

        // Render search section now.
        onjob_render_search_section( $section_details );
    }
endif;

if ( ! function_exists( 'onjob_get_search_section_details' ) ) :
    /**
    * search section details.
    *
    * @since Onjob 1.0.0
    * @param array $input search section details.
    */
    function onjob_get_search_section_details( $input ) {
        $options = onjob_get_theme_options();
        
        $content = array();
        $page_id = '';
        if ( ! empty( $options['search_content_page'] ) )
            $page_id = isset($options['search_content_page']) ? $options['search_content_page'] : '' ;
            
        $args = array(
            'post_type'             => 'page',
            'p'                     =>  absint( $page_id ),
            'ignore_sticky_posts'   => true,
        );

        // Run The Loop.
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) : 
            while ( $query->have_posts() ) : $query->the_post();
                $page_post['id']        = get_the_id();
                $page_post['excerpt']   = onjob_trim_content(40);
                $page_post['title']     = get_the_title();
                $page_post['url']       = get_the_permalink( );
                $page_post['image']     = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_id(), 'large' ) : get_template_directory_uri() . '/assets/uploads/no-featured-image-600x450.jpg';

                // Push to the main array.
                array_push( $content, $page_post );
            endwhile;
        endif;
        wp_reset_postdata();

        if ( ! empty( $content ) ) {
            $input = $content;
        }
        return $input;
    }
endif;
// search section content details.
add_filter( 'onjob_filter_search_section_details', 'onjob_get_search_section_details' );


if ( ! function_exists( 'onjob_render_search_section' ) ) :
  /**
   * Start search section
   *
   * @return string search content
   * @since Onjob 1.0.0
   *
   */
   function onjob_render_search_section( $content_details = array() ) {
        $options        = onjob_get_theme_options();
        
        if ( empty( $content_details ) ) {
            return;
        } ?>

        <?php $content = $content_details[0];?>

            <div id="search-section" class="slider-section">
                <div class="wrapper">
                    <article>
                        <div class="search-content-wrapper">
                            <div class="entry-container">
                                <header class="entry-header">
                                    <h2 class="entry-title"><?php echo esc_html($content['title']); ?></h2>
                                </header>

                                <div class="entry-content">
                                    <p><?php echo wp_kses_post( $content['excerpt'] ); ?></p>
                                </div><!-- .entry-content -->
                            </div><!-- .entry-container -->
                        </div><!-- .search-content-wrapper -->

                        <?php if(class_exists('WP_Job_Manager')) : ?>
                            <form id="search-jobs" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <div class="form-column">
                                    <label for="jobtitle"><?php esc_html_e('Search', 'onjob'); ?></label>
                                    <input type="text" id="search_keywords" value="<?php echo the_search_query(); ?>" name="s" placeholder="Job title or keyword">
                                </div><!-- .form-column -->

                                <div class="form-column">
                                    <label for="jobcategory"><?php esc_html_e('Choose', 'onjob'); ?></label>
                                    <select id="search_category" name="taxonomy">
                                        <option value="0"><?php echo esc_html__( 'All', 'onjob' ); ?></option>
                                    <?php foreach ( get_job_listing_categories() as $cat ) : ?>
                                        <option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
                                    <?php endforeach; ?>
                                    </select>
                                </div><!-- .form-column -->

                                <div class="form-column">
                                    <label for="jobcategory"><?php esc_html_e('Job Type', 'onjob'); ?></label>
                                    <select id="search_type" name="search_type">
                                        <option><?php echo esc_html( 'Select JobType', 'onjob'); ?></option>
                                        <?php foreach ( get_job_listing_types() as $cat ) : ?>
                                            <option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div><!-- .form-column -->

                                <div class="form-column">
                                    <input type="hidden" value="job_listing" name="post_type" id="post_type" />
                                    <button type="submit"><span><?php echo esc_html($options['search_btn_txt']); ?></span></button>
                                </div><!-- .form-column -->
                            </form><!-- #search-jobs -->
                        <?php endif; ?>

                        <div class="featured-image" style="background-image: url('<?php echo esc_url( $content['image']); ?>');"></div><!-- .featured-image -->
                    </article>
                </div><!-- .wrapper -->
            </div><!-- #search-section -->

    <?php
    }    
endif; 
