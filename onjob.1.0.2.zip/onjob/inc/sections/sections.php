<?php
/**
 * Home Page sections
 *
 * This is the template that includes all the other files for home page sections
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// search section 
require get_template_directory() . '/inc/sections/search.php';

// recent-job section 
require get_template_directory() . '/inc/sections/recent-job.php';

// testimonial section
require get_template_directory() . '/inc/sections/testimonial.php';

// blog section
require get_template_directory() . '/inc/sections/blog.php';

// sponsor section
require get_template_directory() . '/inc/sections/sponsor.php';

// featured-job section
require get_template_directory() . '/inc/sections/featured-job.php';