<?php
/**
 * Theme Palace widgets inclusion
 *
 * This is the template that includes all custom widgets of Onjob
 *
 * @package Theme Palace
 * @subpackage Onjob
 * @since Onjob 1.0.0
 */

/*

/*
 * Add popular post widget
 */
require get_template_directory() . '/inc/widgets/social-link-widget.php';
/*

/**
 * Register widgets
 */
function onjob_register_widgets() {

	register_widget( 'Onjob_Social_Link' );

}
add_action( 'widgets_init', 'onjob_register_widgets' );