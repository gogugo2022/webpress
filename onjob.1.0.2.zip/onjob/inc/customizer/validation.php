<?php
/**
* Customizer validation functions
*
* @package Theme Palace
* @subpackage  Onjob
* @since  Onjob 1.0.0
*/

if ( ! function_exists( 'onjob_validate_long_excerpt' ) ) :
    function onjob_validate_long_excerpt( $validity, $value ){
        $value = intval( $value );
        if ( empty( $value ) || ! is_numeric( $value ) ) {
            $validity->add( 'required', esc_html__( 'You must supply a valid number.', 'onjob' ) ); 
        } elseif ( $value < 5 ) {
            $validity->add( 'min_no_of_words', esc_html__( 'Minimum no of words is 5', 'onjob' ) );
        } elseif ( $value > 100 ) {
            $validity->add( 'max_no_of_words', esc_html__( 'Maximum no of words is 100', 'onjob' ) );
        }
        return $validity;
    }
endif;

if ( ! function_exists( 'onjob_validate_featured_job_category_count' ) ) :
    function onjob_validate_featured_job_category_count( $validity, $value ){
        if ( empty( $value ) || ! is_array( $value ) ) {
           $validity->add( 'required',  esc_html__( 'You must Select the  options.', 'onjob') );
        } elseif ( count($value) < 2 ) {
           $validity->add( 'min_no_of_posts', esc_html__( 'Minimum no of posts is 2', 'onjob' ) );
        } elseif ( count($value) > 12 ) {
           $validity->add( 'max_no_of_posts', esc_html__( 'Maximum no of posts is 12', 'onjob' ) );
        }
       return $validity;
    }
endif;
