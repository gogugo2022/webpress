<?php
/**
* Partial functions
*
* @package Theme Palace
* @subpackage  Onjob
* @since  Onjob 1.0.0
*/

// blog btn title
if ( ! function_exists( 'onjob_copyright_text_partial' ) ) :
    function onjob_copyright_text_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['copyright_text'] );
    }
endif;

//Testimonial section sub title selective refresh
if ( ! function_exists( 'onjob_testimonial_section_partial_sub_title' ) ) :
    function onjob_testimonial_section_partial_sub_title() {
        $options = onjob_get_theme_options();
        return esc_html( $options['testimonial_section_sub_title'] );
    }
endif;

//Testimonial section title selective refresh
if ( ! function_exists( 'onjob_testimonial_section_partial_title' ) ) :
    function onjob_testimonial_section_partial_title() {
        $options = onjob_get_theme_options();
        return esc_html( $options['testimonial_section_title'] );
    }
endif;

// blog_title selective refresh
if ( ! function_exists( 'onjob_blog_title_partial' ) ) :
    function onjob_blog_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['blog_title'] );
    }
endif;

// search_btn_txt selective refresh
if ( ! function_exists( 'onjob_search_btn_txt_partial' ) ) :
    function onjob_search_btn_txt_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['search_btn_txt'] );
    }
endif;

// featured_job_sub_title selective refresh
if ( ! function_exists( 'onjob_featured_job_sub_title_partial' ) ) :
    function onjob_featured_job_sub_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['featured_job_sub_title'] );
    }
endif;

// featured_job_title selective refresh
if ( ! function_exists( 'onjob_featured_job_title_partial' ) ) :
    function onjob_featured_job_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['featured_job_title'] );
    }
endif;

// recent_job_sub_title selective refresh
if ( ! function_exists( 'onjob_recent_job_sub_title_partial' ) ) :
    function onjob_recent_job_sub_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['recent_job_sub_title'] );
    }
endif;

// recent_job_title selective refresh
if ( ! function_exists( 'onjob_recent_job_title_partial' ) ) :
    function onjob_recent_job_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['recent_job_title'] );
    }
endif;

// footer_search_title selective refresh
if ( ! function_exists( 'onjob_footer_search_title_partial' ) ) :
    function onjob_footer_search_title_partial() {
        $options = onjob_get_theme_options();
        return esc_html( $options['footer_search_title'] );
    }
endif;
