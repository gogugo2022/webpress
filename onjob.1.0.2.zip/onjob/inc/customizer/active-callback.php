<?php
/**
 * Customizer active callbacks
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

if ( ! function_exists( 'onjob_is_loader_enable' ) ) :
	/**
	 * Check if loader is enabled.
	 *
	 * @since  Onjob 1.0.0
	 * @param WP_Customize_Control $control WP_Customize_Control instance.
	 * @return bool Whether the control is active to the current preview.
	 */
	function onjob_is_loader_enable( $control ) {
		return $control->manager->get_setting( 'onjob_theme_options[loader_enable]' )->value();
	}
endif;

if ( ! function_exists( 'onjob_is_static_homepage_enable' ) ) :
	/**
	 * Check if static homepage is enabled.
	 *
	 * @since Onjob 1.0.0
	 * @param WP_Customize_Control $control WP_Customize_Control instance.
	 * @return bool Whether the control is active to the current preview.
	 */
	function onjob_is_static_homepage_enable( $control ) {
		return ( 'page' == $control->manager->get_setting( 'show_on_front' )->value() );
	}
endif;

if ( ! function_exists( 'onjob_is_breadcrumb_enable' ) ) :
	/**
	 * Check if breadcrumb is enabled.
	 *
	 * @since  Onjob 1.0.0
	 * @param WP_Customize_Control $control WP_Customize_Control instance.
	 * @return bool Whether the control is active to the current preview.
	 */
	function onjob_is_breadcrumb_enable( $control ) {
		return $control->manager->get_setting( 'onjob_theme_options[breadcrumb_enable]' )->value();
	}
endif;

if ( ! function_exists( 'onjob_is_pagination_enable' ) ) :
	/**
	 * Check if pagination is enabled.
	 *
	 * @since  Onjob 1.0.0
	 * @param WP_Customize_Control $control WP_Customize_Control instance.
	 * @return bool Whether the control is active to the current preview.
	 */
	function onjob_is_pagination_enable( $control ) {
		return $control->manager->get_setting( 'onjob_theme_options[pagination_enable]' )->value();
	}
endif;

/**
 * Check if search section is enabled.
 *
 * @since Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_search_section_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[search_section_enable]' )->value() );
}


/**
 * Check if testimonial section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_testimonial_section_enable( $control ) {
    return ( $control->manager->get_setting( 'onjob_theme_options[testimonial_section_enable]' )->value() );
}

/**
 * Check if blog section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_blog_section_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[blog_section_enable]' )->value() );
}

/**
 * Check if sponsor section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[sponsor_section_enable]' )->value() );
}

/**
 * Check if sponsor section content type is post.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_content_post_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[sponsor_content_type]' )->value();
	return onjob_is_sponsor_section_enable( $control ) && ( 'post' == $content_type );
}

/**
 * Check if sponsor section content type is page.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_content_page_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[sponsor_content_type]' )->value();
	return onjob_is_sponsor_section_enable( $control ) && ( 'page' == $content_type );
}

/**
 * Check if sponsor section content type is custom.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_content_custom_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[sponsor_content_type]' )->value();
	return onjob_is_sponsor_section_enable( $control ) && ( 'custom' == $content_type );
}
/**
 * Check if sponsor section content type is category.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_content_category_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[sponsor_content_type]' )->value();
	return onjob_is_sponsor_section_enable( $control ) && ( 'category' == $content_type );
}
/**
 * Check if sponsor separator section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_sponsor_section_separator_enable( $control ) {

    $content_type = $control->manager->get_setting( 'onjob_theme_options[sponsor_content_type]' )->value();
    return onjob_is_sponsor_section_enable( $control ) && !( 'category' == $content_type );
}

/**
 * Check if recent_job section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_recent_job_section_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[recent_job_section_enable]' )->value() && class_exists('WP_Job_Manager') );
}

/**
 * Check if featured_job section is enabled.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_featured_job_section_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[featured_job_section_enable]' )->value() );
}

/**
 * Check if featured_job section content type is category.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_featured_job_section_content_category_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[featured_job_content_type]' )->value();
	return onjob_is_featured_job_section_enable( $control ) && ( 'category' == $content_type );
}

/**
 * Check if featured_job section content type is job job_listing_category.
 *
 * @since  Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_featured_job_section_content_job_listing_category_enable( $control ) {
	$content_type = $control->manager->get_setting( 'onjob_theme_options[featured_job_content_type]' )->value();
	return onjob_is_featured_job_section_enable( $control ) && ( 'job_listing_category' == $content_type && class_exists('WP_Job_Manager'));
}

/**
 * Check if footer search is enable.
 *
 * @since Onjob 1.0.0
 * @param WP_Customize_Control $control WP_Customize_Control instance.
 * @return bool Whether the control is active to the current preview.
 */
function onjob_is_footer_search_enable( $control ) {
	return ( $control->manager->get_setting( 'onjob_theme_options[enable_footer_search]' )->value() );
}
