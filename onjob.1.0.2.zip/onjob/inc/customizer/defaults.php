<?php
/**
 * Customizer default options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 * @return array An array of default values
 */

function onjob_get_default_theme_options() {
	$theme_data = wp_get_theme();
	$onjob_default_options = array(
		// Color Options
		'header_title_color'			    => '#fff',
		'header_tagline_color'			    => '#fff',
		'header_txt_logo_extra'			    => 'show-all',
		'colorscheme_hue'				    => '#fe463a',
		'colorscheme'					    => 'default',
		'theme_version'						=> 'lite-version',

		// loader
		'loader_enable'         		    => (bool) false,
		'loader_icon'         			    => 'default',

		// breadcrumb
		'breadcrumb_enable'				    => (bool) true,
		'breadcrumb_separator'			    => '/',
				
		// homepage options
		'enable_frontpage_content' 			=> false,

		// layout 
		'site_layout'         			    => 'wide',
		'sidebar_position'         		    => 'right-sidebar',
		'post_sidebar_position' 		    => 'right-sidebar',
		'page_sidebar_position' 		    => 'right-sidebar',
		'menu_sticky'					    => (bool) false,

		// excerpt options
		'long_excerpt_length'               => 25,
		'read_more_text'           		    => esc_html__( 'Read More', 'onjob' ),

		// pagination options
		'pagination_enable'         	    => (bool) true,
		'pagination_type'         		    => 'default',

		// footer options
		'copyright_text'           		    => sprintf( esc_html_x( 'Copyright &copy; %1$s %2$s. ', '1: Year, 2: Site Title with home URL', 'onjob' ), '[the-year]', '[site-link]' ),
		'scroll_top_visible'        	    => (bool) true,

		// reset options
		'reset_options'      			    => (bool) false,
		
		// homepage sections sortable
		'sortable' 						    => 'search,sponsor,featured_job,testimonial,recent_job,blog',

		// blog/archive options
		'your_latest_posts_title' 		    => esc_html__( 'Blogs', 'onjob' ),
		'blog_column'						=> 'col-2',
		'hide_date'							=> (bool) false,
		'hide_category'						=> (bool) false,


		// single post theme options
		'single_post_hide_date' 		    => (bool) false,
		'single_post_hide_author'		    => (bool) false,
		'single_post_hide_category'		    => (bool) false,
		'single_post_hide_tags'			    => (bool) false,

		/* Front Page */

		//search 
		'search_section_enable'			    => (bool) false,
		'search_btn_txt'                    => esc_html__('Search Now','onjob'),

		//testimonial
        'testimonial_section_enable'        => (bool) false,
        'testimonial_autoplay_enable'       => (bool) true,
		'testimonial_section_sub_title'     => esc_html__('Testimonial','onjob'),
		'testimonial_section_title'	        => esc_html__('What They Say About Our Company?','onjob'),
		'testimonial_posts_count'           => 4,
		
		// blog
		'blog_section_enable'			    => (bool) false,
		'blog_title'					    => esc_html__( 'Find what’s happening around our circle', 'onjob' ),
		'blog_count'					    => 3,

		// featured_job
		'featured_job_section_enable'			    => (bool) false,
		'featured_job_title'					    => esc_html__( 'Search by category', 'onjob' ),
		'featured_job_sub_title'				    => esc_html__( 'Choose career', 'onjob' ),
		'featured_job_content_type'				    => 'category',
		'featured_job_count'					    => 5,
		
		// recent_job
		'recent_job_section_enable'				=> (bool) false,
		'recent_job_title'					    => esc_html__( 'Top jobs this week', 'onjob' ),
		'recent_job_sub_title'          		=> esc_html__('12000+ jobs available','onjob'),
		'recent_job_count'						=> 3,

		// Sponsor
		'sponsor_section_enable'			=> (bool) false,
		'sponsor_content_type'				=> 'custom',
		'sponsor_count'						=> 5,
				
		'enable_footer_search'			   => (bool) false,
		'footer_search_title'		  	  => esc_html__( 'You are now seeing jobs from Nepal.', 'onjob' ),
	);

	$output = apply_filters( 'onjob_default_theme_options', $onjob_default_options );

	// Sort array in ascending order, according to the key:
	if ( ! empty( $output ) ) {
		ksort( $output );
	}

	return $output;
}