<?php
/**
 * Layout options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// Add sidebar section
$wp_customize->add_section( 'onjob_layout',
	array(
		'title'               => esc_html__('Layout','onjob'),
		'description'         => esc_html__( 'Layout section options.', 'onjob' ),
		'panel'               => 'onjob_theme_options_panel',
	)
);

// Site layout setting and control.
$wp_customize->add_setting( 'onjob_theme_options[site_layout]',
	array(
		'sanitize_callback'   => 'onjob_sanitize_select',
		'default'             => $options['site_layout'],
	)
);

$wp_customize->add_control(  new  Onjob_Custom_Radio_Image_Control ( $wp_customize,
	'onjob_theme_options[site_layout]',
		array(
			'label'               => esc_html__( 'Site Layout', 'onjob' ),
			'section'             => 'onjob_layout',
			'choices'			  => onjob_site_layout(),
		)
	)
);

// Sidebar position setting and control.
$wp_customize->add_setting( 'onjob_theme_options[sidebar_position]',
	array(
		'sanitize_callback'   => 'onjob_sanitize_select',
		'default'             => $options['sidebar_position'],
	)
);

$wp_customize->add_control(  new  Onjob_Custom_Radio_Image_Control ( $wp_customize,
	'onjob_theme_options[sidebar_position]',
		array(
			'label'               => esc_html__( 'Global Sidebar Position', 'onjob' ),
			'section'             => 'onjob_layout',
			'choices'			  => onjob_global_sidebar_position(),
		)
	)
);

// Post sidebar position setting and control.
$wp_customize->add_setting( 'onjob_theme_options[post_sidebar_position]',
	array(
		'sanitize_callback'   => 'onjob_sanitize_select',
		'default'             => $options['post_sidebar_position'],
	)
);

$wp_customize->add_control(  new  Onjob_Custom_Radio_Image_Control ( $wp_customize,
	'onjob_theme_options[post_sidebar_position]',
		array(
			'label'               => esc_html__( 'Posts Sidebar Position', 'onjob' ),
			'section'             => 'onjob_layout',
			'choices'			  => onjob_sidebar_position(),
		)
	)
);

// Post sidebar position setting and control.
$wp_customize->add_setting( 'onjob_theme_options[page_sidebar_position]',
	array(
		'sanitize_callback'   => 'onjob_sanitize_select',
		'default'             => $options['page_sidebar_position'],
	)
);

$wp_customize->add_control( new  Onjob_Custom_Radio_Image_Control( $wp_customize,
	'onjob_theme_options[page_sidebar_position]',
		array(
			'label'               => esc_html__( 'Pages Sidebar Position', 'onjob' ),
			'section'             => 'onjob_layout',
			'choices'			  => onjob_sidebar_position(),
		)
	)
);