<?php
/**
 * Footer options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// Footer Section
$wp_customize->add_section( 'onjob_section_footer',
	array(
		'title'      			=> esc_html__( 'Footer Options', 'onjob' ),
		'priority'   			=> 900,
		'panel'      			=> 'onjob_theme_options_panel',
	)
);

// footer text
$wp_customize->add_setting( 'onjob_theme_options[copyright_text]',
	array(
		'default'       		=> $options['copyright_text'],
		'sanitize_callback'		=> 'onjob_santize_allow_tag',
		'transport'				=> 'postMessage',
	)
);

$wp_customize->add_control( 'onjob_theme_options[copyright_text]',
    array(
		'label'      			=> esc_html__( 'Copyright Text', 'onjob' ),
		'section'    			=> 'onjob_section_footer',
		'type'		 			=> 'textarea',
    )
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[copyright_text]',
		array(
			'selector'            => '.site-info .wrapper',
			'settings'            => 'onjob_theme_options[copyright_text]',
			'container_inclusive' => false,
			'fallback_refresh'    => true,
			'render_callback'     => 'onjob_copyright_text_partial',
		)
	);
}

// scroll top visible
$wp_customize->add_setting( 'onjob_theme_options[scroll_top_visible]',
	array(
		'default'       	=> $options['scroll_top_visible'],
		'sanitize_callback' => 'onjob_sanitize_switch_control',
	)
);

$wp_customize->add_control( new  Onjob_Switch_Control( $wp_customize,
	'onjob_theme_options[scroll_top_visible]',
		array(
			'label'      		=> esc_html__( 'Display Scroll Top Button', 'onjob' ),
			'section'    		=> 'onjob_section_footer',
			'on_off_label' 		=> onjob_switch_options(),
		)
	)
);


// scroll top visible
$wp_customize->add_setting( 'onjob_theme_options[enable_footer_search]',
	array(
		'default'       	=> $options['enable_footer_search'],
		'sanitize_callback' => 'onjob_sanitize_switch_control',
	)
);

$wp_customize->add_control( new  Onjob_Switch_Control( $wp_customize,
	'onjob_theme_options[enable_footer_search]',
		array(
			'label'      		=> esc_html__( 'Footer Search Enable', 'onjob' ),
			'section'    		=> 'onjob_section_footer',
			'on_off_label' 		=> onjob_switch_options(),
		)
	)
);

// Blog content setting
$wp_customize->add_setting('onjob_theme_options[footer_search_title]',
    array(
        'sanitize_callback' => 'sanitize_text_field',
        'transport'			=> 'postMessage',
        'default'           => $options['footer_search_title']

    )
);

$wp_customize->add_control('onjob_theme_options[footer_search_title]',
    array(
        'section'			=> 'onjob_section_footer',
        'label'				=> esc_html__( 'Search Title', 'onjob' ),
        'type'          	=> 'text',
        'active_callback'	=> 'onjob_is_footer_search_enable'
    )
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[footer_search_title]',
        array(
            'selector'            => '#colophon .search-jobs h2.entry-title',
            'settings'            => 'onjob_theme_options[footer_search_title]',
            'fallback_refresh'    => true,
            'container_inclusive' => false,
            'render_callback'     => 'onjob_footer_search_title_partial',
        ) 
    );
}