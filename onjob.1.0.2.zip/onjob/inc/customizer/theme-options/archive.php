<?php
/**
 * Archive options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// Add archive section
$wp_customize->add_section( 'onjob_archive_section',
	array(
		'title'             => esc_html__( 'Blog/Archive','onjob' ),
		'description'       => esc_html__( 'Archive section options.', 'onjob' ),
		'panel'             => 'onjob_theme_options_panel',
	)
);

// Your latest posts title setting and control.
$wp_customize->add_setting( 'onjob_theme_options[your_latest_posts_title]',
	array(
		'default'           => $options['your_latest_posts_title'],
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control( 'onjob_theme_options[your_latest_posts_title]',
	array(
		'label'             => esc_html__( 'Your Latest Posts Title', 'onjob' ),
		'description'       => esc_html__( 'This option only works if Static Front Page is set to "Your latest posts."', 'onjob' ),
		'section'           => 'onjob_archive_section',
		'type'				=> 'text',
		'active_callback'   => 'onjob_is_latest_posts'
	)
);

// features content type control and setting
$wp_customize->add_setting( 'onjob_theme_options[blog_column]',
	array(
		'default'          	=> $options['blog_column'],
		'sanitize_callback' => 'onjob_sanitize_select',
		//'transport'			=> 'refresh',
	)
);

$wp_customize->add_control( 'onjob_theme_options[blog_column]',
	array(
		'label'             => esc_html__( 'Column Layout', 'onjob' ),
		'section'           => 'onjob_archive_section',
		'type'				=> 'select',
		'choices'			=> array( 
			'col-1'		=> esc_html__( 'One Column', 'onjob' ),
			'col-2'		=> esc_html__( 'Two Column', 'onjob' ),
			'col-3'		=> esc_html__( 'Three Column', 'onjob' ),
		),
	)
);

// read more text setting and control
$wp_customize->add_setting( 'onjob_theme_options[read_more_text]',
	array(
		'sanitize_callback' => 'sanitize_text_field',
		'default'			=> $options['read_more_text'],
	)
);

$wp_customize->add_control( 'onjob_theme_options[read_more_text]',
	array(
		'label'           	=> esc_html__( 'Read More Text Label', 'onjob' ),
		'section'        	=> 'onjob_archive_section',
		'type'				=> 'text',
	)
);

