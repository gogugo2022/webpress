<?php
/**
 * Blog Section options
 *
 * @package Theme Palace
 * @subpackage Onjob
 * @since Onjob 1.0.0
 */

// Add Blog section
$wp_customize->add_section( 'onjob_featured_job_section',
    array(
        'title'             => esc_html__( 'Featured Jobs','onjob' ),
        'description'       => esc_html__( 'Featured Jobs Section options.', 'onjob' ),
        'panel'             => 'onjob_front_page_panel',
    )
);

// Featured Jobs content enable control and setting
$wp_customize->add_setting( 'onjob_theme_options[featured_job_section_enable]',
    array(
        'default'           =>  $options['featured_job_section_enable'],
        'sanitize_callback' => 'onjob_sanitize_switch_control',
    )
);

$wp_customize->add_control( new Onjob_Switch_Control( $wp_customize,
    'onjob_theme_options[featured_job_section_enable]',
        array(
            'label'             => esc_html__( 'Featured Jobs Section Enable', 'onjob' ),
            'section'           => 'onjob_featured_job_section',
            'on_off_label'      => onjob_switch_options(),
        ) 
    )
);

// blog title setting and control
$wp_customize->add_setting( 'onjob_theme_options[featured_job_sub_title]',
    array(
        'sanitize_callback' => 'sanitize_text_field',
        'default'           => $options['featured_job_sub_title'],
        'transport'         => 'postMessage',
    )
);

$wp_customize->add_control( 'onjob_theme_options[featured_job_sub_title]',
    array(
        'label'             => esc_html__( 'Section Title', 'onjob' ),
        'section'           => 'onjob_featured_job_section',
        'active_callback'   => 'onjob_is_featured_job_section_enable',
        'type'              => 'text',
    ) 
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[featured_job_sub_title]',
        array(
            'selector'            => '#featured-jobs div.section-header p',
            'settings'            => 'onjob_theme_options[featured_job_sub_title]',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
            'render_callback'     => 'onjob_featured_job_sub_title_partial',
        )
    );
}

// blog title setting and control
$wp_customize->add_setting( 'onjob_theme_options[featured_job_title]',
    array(
        'sanitize_callback' => 'sanitize_text_field',
        'default'           => $options['featured_job_title'],
        'transport'         => 'postMessage',
    )
);

$wp_customize->add_control( 'onjob_theme_options[featured_job_title]',
    array(
        'label'             => esc_html__( 'Section Title', 'onjob' ),
        'section'           => 'onjob_featured_job_section',
        'active_callback'   => 'onjob_is_featured_job_section_enable',
        'type'              => 'text',
    ) 
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[featured_job_title]',
        array(
            'selector'            => '#featured-jobs div.section-header h2.section-title',
            'settings'            => 'onjob_theme_options[featured_job_title]',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
            'render_callback'     => 'onjob_featured_job_title_partial',
        )
    );
}

// Featured Jobs content type control and setting
$wp_customize->add_setting( 'onjob_theme_options[featured_job_content_type]',
    array(
        'default'           => $options['featured_job_content_type'],
        'sanitize_callback' => 'onjob_sanitize_select',
    ) 
);

$wp_customize->add_control( 'onjob_theme_options[featured_job_content_type]',
    array(
        'label'             => esc_html__( 'Content Type', 'onjob' ),
        'description'	    => sprintf( esc_html__( '%1$sWP Job Manager %2$s should be installed and active to enable job and company content type', 'onjob' ), '<a target="_blank" href="'.admin_url('themes.php?page=tgmpa-install-plugins&plugin_status=install').'">', '</a>' ),
        'section'           => 'onjob_featured_job_section',
        'type'              => 'select',
        'active_callback'   => 'onjob_is_featured_job_section_enable',
        'choices'           => onjob_featured_job_content_type()
    ) 
);


for($i = 0; $i < $options['featured_job_count']; $i ++):

    // Onjob_Customize_Horizontal_Line
    $wp_customize->add_setting('onjob_theme_options[featured_job_separator_'. $i .']',
		array(
			'sanitize_callback'      => 'onjob_sanitize_html',
		)
	);

    $wp_customize->add_control(new  Onjob_Customize_Horizontal_Line($wp_customize,
		'onjob_theme_options[featured_job_separator_'. $i .']',
			array(
				'active_callback'       => 'onjob_is_featured_job_section_enable',
				'type'                  => 'hr',
				'section'               => 'onjob_featured_job_section',
			)
		)
	);

    if(class_exists('WP_Job_Manager')){

        // Add dropdown category setting and control.
        $wp_customize->add_setting(  'onjob_theme_options[featured_job_content_job_listing_category_'.$i.']',
            array(
                'sanitize_callback' => 'onjob_sanitize_single_job_listing_category',
            )
        );

        $wp_customize->add_control( new  Onjob_Dropdown_Taxonomies_Control( $wp_customize,
            'onjob_theme_options[featured_job_content_job_listing_category_'.$i.']',
                array(
                    'label'             => sprintf( esc_html__( 'Select Jobs Category %d', 'onjob' ), ($i+1) ),
                    'section'           => 'onjob_featured_job_section',
                    'type'              => 'dropdown-taxonomies',
                    'taxonomy'          => 'job_listing_category',
                    'active_callback'	=> 'onjob_is_featured_job_section_content_job_listing_category_enable'
                )
            )
        );
    }
            
    // Add dropdown category setting and control.
    $wp_customize->add_setting(  'onjob_theme_options[featured_job_content_category_'.$i.']',
        array(
            'sanitize_callback' => 'onjob_sanitize_single_category',
        )
    );

    $wp_customize->add_control( new  Onjob_Dropdown_Taxonomies_Control( $wp_customize,
        'onjob_theme_options[featured_job_content_category_'.$i.']',
            array(
                'label'             => sprintf( esc_html__( 'Select Category %d', 'onjob' ), ($i+1) ),
                'section'           => 'onjob_featured_job_section',
                'type'              => 'dropdown-taxonomies',
                'active_callback'	=> 'onjob_is_featured_job_section_content_category_enable'
            )
        )
    );
    
    $wp_customize->add_setting( 'onjob_theme_options[featured_job_icon_' . $i . ']', 
        array(
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'fa-briefcase',
        )
    );

	$wp_customize->add_control( new Onjob_Icon_Picker( $wp_customize,
		'onjob_theme_options[featured_job_icon_' . $i . ']',
			array(
				'label'             => sprintf( esc_html__( 'Service Icon %d', 'onjob' ), ($i+1) ),
				'section'           => 'onjob_featured_job_section',
				'active_callback'	=> 'onjob_is_featured_job_section_enable',
			)
		)
	);


endfor;