<?php
/**
 * Sponsor Section options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// Add Sponsor section
$wp_customize->add_section( 'onjob_sponsor_section',
	array(
		'title'             => esc_html__( 'Sponsor','onjob' ),
		'description'       => esc_html__( 'Sponsor Section options.', 'onjob' ),
		'panel'             => 'onjob_front_page_panel',
	)
);

// Sponsor content enable control and setting
$wp_customize->add_setting( 'onjob_theme_options[sponsor_section_enable]', 
	array(
		'default'			=> 	$options['sponsor_section_enable'],
		'sanitize_callback' => 'onjob_sanitize_switch_control',
	) 
);

$wp_customize->add_control( new  Onjob_Switch_Control( $wp_customize,
	'onjob_theme_options[sponsor_section_enable]',
		array(
			'label'             => esc_html__( 'Sponsor Section Enable', 'onjob' ),
			'section'           => 'onjob_sponsor_section',
			'on_off_label' 		=> onjob_switch_options(),
		)
	)
);

// Sponsor content type control and setting
$wp_customize->add_setting( 'onjob_theme_options[sponsor_content_type]',
	array(
		'default'          	=> $options['sponsor_content_type'],
		'sanitize_callback' => 'onjob_sanitize_select',
	)
);

$wp_customize->add_control( 'onjob_theme_options[sponsor_content_type]',
	array(
		'label'             => esc_html__( 'Content Type', 'onjob' ),
		'section'           => 'onjob_sponsor_section',
		'type'				=> 'select',
		'active_callback' 	=> 'onjob_is_sponsor_section_enable',
		'choices'			=> array( 
			'page' 		=> esc_html__( 'Page', 'onjob' ),
			'post' 		=> esc_html__( 'Post', 'onjob' ),
			'category' 	=> esc_html__( 'Category', 'onjob' ),
			'custom' 	=> esc_html__( 'Custom', 'onjob' ),
		),
	)
);


for ( $i = 1; $i <= $options['sponsor_count']; $i++ ) :

	// sponsor pages drop down chooser control and setting
	$wp_customize->add_setting( 'onjob_theme_options[sponsor_content_page_'. $i .']', 
		array(
			'sanitize_callback' => 'onjob_sanitize_page',
		)
	);

	$wp_customize->add_control( new  Onjob_Dropdown_Chooser( $wp_customize,
		'onjob_theme_options[sponsor_content_page_'. $i .']', 
			array(
				'label'             => sprintf(esc_html__( 'Select Page: %d', 'onjob'), $i ),
				'section'           => 'onjob_sponsor_section',
				'choices'			=> onjob_page_choices(),
				'active_callback'	=> 'onjob_is_sponsor_section_content_page_enable',
			)
		)
	);

	// sponsor posts drop down chooser control and setting
	$wp_customize->add_setting( 'onjob_theme_options[sponsor_content_post_'. $i .']', 
		array(
			'sanitize_callback' => 'onjob_sanitize_page',
		)
	);

	$wp_customize->add_control( new  Onjob_Dropdown_Chooser( $wp_customize,
		'onjob_theme_options[sponsor_content_post_'. $i .']',
			array(
				'label'             => sprintf(esc_html__( 'Select Post : %d', 'onjob'), $i ),
				'section'           => 'onjob_sponsor_section',
				'choices'			=> onjob_post_choices(),
				'active_callback'	=> 'onjob_is_sponsor_section_content_post_enable',
			)
		)
	);

	// Onjob_Customize_Horizontal_Line
    $wp_customize->add_setting('onjob_theme_options[sponsor_separator'. $i .']',
		array(
			'sanitize_callback'      => 'onjob_sanitize_html',
		)
	);

    $wp_customize->add_control(new Onjob_Customize_Horizontal_Line($wp_customize,
		'onjob_theme_options[sponsor_separator'. $i .']',
			array(
				'active_callback'       => 'onjob_is_sponsor_section_separator_enable',
				'type'                  =>'hr',
				'section'               =>'onjob_sponsor_section',
			)
		)
	);

        
    // About image setting
    $wp_customize->add_setting('onjob_theme_options[sponsor_image_'.$i.']',
		array(
			'sanitize_callback' => 'onjob_sanitize_image',
		)
	);

    $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,
		'onjob_theme_options[sponsor_image_'.$i.']',
			array(
				'section'			=> 'onjob_sponsor_section',
				'label'				=> esc_html__( 'Image:', 'onjob' ),
				'active_callback' 	=> 'onjob_is_sponsor_section_content_custom_enable',
			)
		)
	);

            
    $wp_customize->add_setting( 'onjob_theme_options[sponsor_url_'.$i.']',
        array(
            'sanitize_callback' => 'esc_url_raw',
        )
    );

    $wp_customize->add_control( 'onjob_theme_options[sponsor_url_'.$i.']',
        array(
			'label'             => sprintf(esc_html__( 'Sponsor URL : %d', 'onjob'), $i ),
            'section'        	=> 'onjob_sponsor_section',
            'active_callback' 	=> 'onjob_is_sponsor_section_content_custom_enable',
            'type'				=> 'url',
        ) 
    );


endfor;

// sponsor posts drop down chooser control and setting
$wp_customize->add_setting( 'onjob_theme_options[sponsor_category]',
	array(
		'sanitize_callback' => 'onjob_sanitize_single_category',
	)
);

$wp_customize->add_control( new  Onjob_Dropdown_Taxonomies_Control( $wp_customize,
	'onjob_theme_options[sponsor_category]', 
		array(
			'label'             => esc_html__( 'Select Categories', 'onjob' ),
			'description'       => esc_html__( 'Note: Latest selected no of posts will be shown from selected category', 'onjob' ),
			'type'           	=> 'dropdown-taxonomies',
			'section'           => 'onjob_sponsor_section',
			'active_callback'	=> 'onjob_is_sponsor_section_content_category_enable',
		)
	)
); 

