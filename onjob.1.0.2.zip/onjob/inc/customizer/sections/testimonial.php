<?php

/**
 * Testimonial Section options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

// Add Testimonial section
$wp_customize->add_section('onjob_testimonial_section',
    array(
        'title'             => esc_html__('Testimonials', 'onjob'),
        'description'       => esc_html__('Testimonials Section options.', 'onjob'),
        'panel'             => 'onjob_front_page_panel',
    )
);

// Testimonial content enable control and setting
$wp_customize->add_setting('onjob_theme_options[testimonial_section_enable]',
    array(
        'default'           => $options['testimonial_section_enable'],
        'sanitize_callback' => 'onjob_sanitize_switch_control',
    )
);

$wp_customize->add_control(new  Onjob_Switch_Control($wp_customize,
    'onjob_theme_options[testimonial_section_enable]',
        array(
            'label'         => esc_html__('Testimonial Section Enable', 'onjob'),
            'section'       => 'onjob_testimonial_section',
            'on_off_label'  => onjob_switch_options(),
        )
    )
);

// Testimonial autoplay enable control and setting
$wp_customize->add_setting( 'onjob_theme_options[testimonial_autoplay_enable]',
	array(
		'default'			=> 	$options['testimonial_autoplay_enable'],
		'sanitize_callback' => 'onjob_sanitize_switch_control',
	)
);

$wp_customize->add_control( new  Onjob_Switch_Control( $wp_customize,
	'onjob_theme_options[testimonial_autoplay_enable]',
		array(
			'label'             => esc_html__( 'Testimonial Autoplay Enable', 'onjob' ),
			'section'           => 'onjob_testimonial_section',
			'active_callback'   => 'onjob_is_testimonial_section_enable',
			'on_off_label' 		=> onjob_switch_options(),
		)
	)
);

// Testimonial section sub title control and setting
$wp_customize->add_setting('onjob_theme_options[testimonial_section_sub_title]',
    array(
        'sanitize_callback'     => 'sanitize_text_field',
        'transport'             => 'postMessage',
        'default'               => $options['testimonial_section_sub_title'],
    )
);

$wp_customize->add_control('onjob_theme_options[testimonial_section_sub_title]',
    array(
        'label'             => esc_html__('Section Sub Title', 'onjob'),
        'section'           => 'onjob_testimonial_section',
        'type'              => 'text',
        'active_callback'   => 'onjob_is_testimonial_section_enable',
    )
);

$wp_customize->selective_refresh->add_partial('onjob_theme_options[testimonial_section_sub_title]',
    array(
        'selector'          => '#testimonial-section .section-subtitle',
        'render_callback'   => 'onjob_testimonial_section_partial_sub_title',
    )
);

// Testimonial section title control and setting
$wp_customize->add_setting('onjob_theme_options[testimonial_section_title]',
    array(
        'default'               => $options['testimonial_section_title'],
        'sanitize_callback'     => 'sanitize_text_field',
        'transport'             => 'postMessage'
    )
);

$wp_customize->add_control('onjob_theme_options[testimonial_section_title]',
    array(
        'label'                 => esc_html__('Section Title', 'onjob'),
        'section'               => 'onjob_testimonial_section',
        'type'                  => 'text',
        'active_callback'       => 'onjob_is_testimonial_section_enable',
    )
);

$wp_customize->selective_refresh->add_partial('onjob_theme_options[testimonial_section_title]',
    array(
        'selector'          => '#testimonial-section .section-title',
        'render_callback'   => 'onjob_testimonial_section_partial_title',
    )
);

for ($i = 1; $i <= $options['testimonial_posts_count']; $i++):

    // Testimonial pages drop down chooser control and setting
    $wp_customize->add_setting('onjob_theme_options[testimonial_content_page_' . $i . ']',
        array(
            'sanitize_callback' => 'onjob_sanitize_page',
        )
    );

    $wp_customize->add_control(new  Onjob_Dropdown_Chooser($wp_customize,
        'onjob_theme_options[testimonial_content_page_' . $i . ']',
            array(
                'label'             => sprintf(esc_html__('Select Page : %d', 'onjob'), $i),
                'section'           => 'onjob_testimonial_section',
                'choices'           => onjob_page_choices(),
                'active_callback'   => 'onjob_is_testimonial_section_enable',
            )
        )
    );

    // Testimonial posts sub title control and setting
    $wp_customize->add_setting('onjob_theme_options[testimonial_post_designation_' . $i . ']',
        array(
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    $wp_customize->add_control(new  Onjob_Dropdown_Chooser($wp_customize,
        'onjob_theme_options[testimonial_post_designation_' . $i . ']',
            array(
                'label'             => sprintf(esc_html__('Select Designation : %d', 'onjob'), $i),
                'section'           => 'onjob_testimonial_section',
                'active_callback'   => 'onjob_is_testimonial_section_enable',
                'type'              => 'text',
            )
        )
    );

    //testimonial separator
    $wp_customize->add_setting('onjob_theme_options[testimonial_separator'. $i .']',
        array(
            'sanitize_callback'      => 'onjob_sanitize_html',
        )
    );

    $wp_customize->add_control(new  Onjob_Customize_Horizontal_Line($wp_customize,
        'onjob_theme_options[testimonial_separator'. $i .']',
            array(
                'active_callback'       => 'onjob_is_testimonial_section_enable',
                'type'                  =>'hr',
                'section'               =>'onjob_testimonial_section',
            )
        )
    );

endfor;

// testimonial Background image setting
$wp_customize->add_setting('onjob_theme_options[testimonial_bg_image]',
    array(
        'sanitize_callback' => 'onjob_sanitize_image',
    )
);

$wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,
    'onjob_theme_options[testimonial_bg_image]',
        array(
            'section'			=> 'onjob_testimonial_section',
            'label'				=> esc_html__( 'Background Image:', 'onjob' ),
            'active_callback' 	=> 'onjob_is_testimonial_section_enable',
        )
    )
);
