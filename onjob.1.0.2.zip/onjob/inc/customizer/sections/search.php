<?php
/**
 * Search Section options
 *
 * @package Theme Palace
 * @subpackage Onjob
 * @since Onjob 1.0.0
 */

// Add Search section
$wp_customize->add_section( 'onjob_search_section',
	array(
		'title'             => esc_html__( 'Search Section','onjob' ),
        'description'	    => sprintf( esc_html__( '%1$sWP Job Manage%2$s should be installed and active for this section to work.', 'onjob' ), '<a target="_blank" href="'.admin_url('themes.php?page=tgmpa-install-plugins&plugin_status=install').'">', '</a>' ),
		'panel'             => 'onjob_front_page_panel',
	)
);

// Search content enable control and setting
$wp_customize->add_setting( 'onjob_theme_options[search_section_enable]',
	array(
		'default'			=> 	$options['search_section_enable'],
		'sanitize_callback' => 'onjob_sanitize_switch_control',
	)
);

$wp_customize->add_control( new Onjob_Switch_Control( $wp_customize,
	'onjob_theme_options[search_section_enable]',
		array(
			'label'             => esc_html__( 'Search Section Enable', 'onjob' ),
			'section'           => 'onjob_search_section',
			'on_off_label' 		=> onjob_switch_options(),
		)
	)
);

// search pages drop down chooser control and setting
$wp_customize->add_setting( 'onjob_theme_options[search_content_page]',
	array(
		'sanitize_callback' => 'onjob_sanitize_page',
	)
);

$wp_customize->add_control( new Onjob_Dropdown_Chooser( $wp_customize,
	'onjob_theme_options[search_content_page]',
		array(
			'label'             => esc_html__( 'Select Page', 'onjob' ),
			'section'           => 'onjob_search_section',
			'choices'			=> onjob_page_choices(),
			'active_callback'	=> 'onjob_is_search_section_enable',
		)
	)
);

//slider_btn_txt
$wp_customize->add_setting('onjob_theme_options[search_btn_txt]',
    array(
        'sanitize_callback' => 'sanitize_text_field',
        'transport'			=> 'postMessage',
        'default'           => $options['search_btn_txt'],
    )
);

$wp_customize->add_control('onjob_theme_options[search_btn_txt]',
    array(
        'section'			=> 'onjob_search_section',
        'label'				=> esc_html__( 'Button Text:', 'onjob' ),
        'type'          	=>'text',
        'active_callback' 	=> 'onjob_is_search_section_enable'
    )
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[search_btn_txt]',
		array(
			'selector'            => '#search-section div.form-column button > span',
			'settings'            => 'onjob_theme_options[search_btn_txt]',
			'fallback_refresh'    => true,
			'container_inclusive' => false,
			'render_callback'     => 'onjob_search_btn_txt_partial',
		)
	);
}
