<?php
/**
 * Blog Section options
 *
 * @package Theme Palace
 * @subpackage Onjob
 * @since Onjob 1.0.0
 */

// Add Blog section
$wp_customize->add_section( 'onjob_blog_section',
    array(
        'title'             => esc_html__( 'Blog','onjob' ),
        'description'       => esc_html__( 'Blog Section options.', 'onjob' ),
        'panel'             => 'onjob_front_page_panel',
    )
);

// Blog content enable control and setting
$wp_customize->add_setting( 'onjob_theme_options[blog_section_enable]',
    array(
        'default'           =>  $options['blog_section_enable'],
        'sanitize_callback' => 'onjob_sanitize_switch_control',
    )
);

$wp_customize->add_control( new Onjob_Switch_Control( $wp_customize,
    'onjob_theme_options[blog_section_enable]',
        array(
            'label'             => esc_html__( 'Blog Section Enable', 'onjob' ),
            'section'           => 'onjob_blog_section',
            'on_off_label'      => onjob_switch_options(),
        ) 
    )
);

// blog title setting and control
$wp_customize->add_setting( 'onjob_theme_options[blog_title]',
    array(
        'sanitize_callback' => 'sanitize_text_field',
        'default'           => $options['blog_title'],
        'transport'         => 'postMessage',
    )
);

$wp_customize->add_control( 'onjob_theme_options[blog_title]',
    array(
        'label'             => esc_html__( 'Section Title', 'onjob' ),
        'section'           => 'onjob_blog_section',
        'active_callback'   => 'onjob_is_blog_section_enable',
        'type'              => 'text',
    ) 
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'onjob_theme_options[blog_title]',
        array(
            'selector'            => '#latest-posts .section-header h2.section-title',
            'settings'            => 'onjob_theme_options[blog_title]',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
            'render_callback'     => 'onjob_blog_title_partial',
        )
    );
}
