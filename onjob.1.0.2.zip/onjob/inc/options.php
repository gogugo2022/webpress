<?php
/**
 * Theme Palace options
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

/**
 * List of pages for page choices.
 * @return Array Array of page ids and name.
 */
function onjob_page_choices() {
    $pages = get_pages();
    $choices = array();
    $choices[0] = esc_html__( '--Select--', 'onjob' );
    foreach ( $pages as $page ) {
        $choices[ $page->ID ] = $page->post_title;
    }
    return  $choices;
}

/**
 * List of posts for post choices.
 * @return Array Array of post ids and name.
 */
function onjob_post_choices() {
    $posts = get_posts( array( 'numberposts' => -1 ) );
    $choices = array();
    $choices[0] = esc_html__( '--Select--', 'onjob' );
    foreach ( $posts as $post ) {
        $choices[ $post->ID ] = $post->post_title;
    }
    wp_reset_postdata();
    return  $choices;
}

/**
 * List of jobs for post choices.
 * @return Array Array of post ids and name.
 */
function onjob_job_listing_choices() {
    $posts = get_posts( array( 'post_type' => 'job_listing', 'numberposts' => -1 ) );
    $choices = array();
    $choices[0] = esc_html__( '--Select--', 'onjob' );
    foreach ( $posts as $post ) {
        $choices[ $post->ID ] = $post->post_title;
    }
    return  $choices;
}

/**
 * List of companies for post choices.
 * @return Array Array of post ids and name.
 */
function onjob_company_choices() {
    $posts = get_posts( array( 'post_type' => 'company', 'numberposts' => -1 ) );
    $choices = array();
    $choices[0] = esc_html__( '--Select--', 'onjob' );
    foreach ( $posts as $post ) {
        $choices[ $post->ID ] = $post->post_title;
    }
    return  $choices;
}

/**
 * List of products for post choices.
 * @return Array Array of post ids and name.
 */
function onjob_product_choices() {
    $posts = get_posts( array( 'numberposts' => -1, 'post_type' => 'product' ) );
    $choices = array();
    $choices[0] = esc_html__( '--Select--', 'onjob' );
    foreach ( $posts as $post ) {
        $choices[ $post->ID ] = $post->post_title;
    }
    return  $choices;
}


/**
 * List of category for category choices.
 * @return Array Array of post ids and name.
 */
function onjob_category_choices() {
    if(!taxonomy_exists('job_listing_category')) return;
    $tax_args = array(
        'hide_empty' => false,
        'hierarchical' => 0,
        'taxonomy'     => 'job_listing_category',
    );
    $taxonomies = get_terms( $tax_args );
    $choices = array();
    if(!is_wp_error($taxonomies)){
        $choices[0] = esc_html__( '--Select--', 'onjob' );
        foreach ( $taxonomies as $tax ) {
            $choices[ $tax->term_id ] = $tax->name;
        }
    }
    return  $choices;
}


if ( ! function_exists( 'onjob_site_layout' ) ) :
    /**
     * Site Layout
     * @return array site layout options
     */
    function onjob_site_layout() {
        $onjob_site_layout = array(
            'wide'          => esc_url( get_template_directory_uri() . '/assets/images/full.png' ),
            'boxed-layout'  => esc_url( get_template_directory_uri() . '/assets/images/boxed.png' ),
        );

        $output = apply_filters( 'onjob_site_layout', $onjob_site_layout );
        return $output;
    }
endif;

if ( ! function_exists( 'onjob_selected_sidebar' ) ) :
    /**
     * Sidebars options
     * @return array Sidbar positions
     */
    function onjob_selected_sidebar() {
        $onjob_selected_sidebar = array(
            'sidebar-1'             => esc_html__( 'Default Sidebar', 'onjob' ),
            'optional-sidebar'      => esc_html__( 'Optional Sidebar 1', 'onjob' ),
            'optional-sidebar-2'    => esc_html__( 'Optional Sidebar 2', 'onjob' ),
        );

        $output = apply_filters( 'onjob_selected_sidebar', $onjob_selected_sidebar );

        return $output;
    }
endif;


if ( ! function_exists( 'onjob_global_sidebar_position' ) ) :
    /**
     * Global Sidebar position
     * @return array Global Sidebar positions
     */
    function onjob_global_sidebar_position() {
        $onjob_global_sidebar_position = array(
            'right-sidebar' => esc_url( get_template_directory_uri() . '/assets/images/right.png' ),
            'no-sidebar'    => esc_url( get_template_directory_uri() . '/assets/images/full.png' ),
        );

        $output = apply_filters( 'onjob_global_sidebar_position', $onjob_global_sidebar_position );

        return $output;
    }
endif;


if ( ! function_exists( 'onjob_sidebar_position' ) ) :
    /**
     * Sidebar position
     * @return array Sidbar positions
     */
    function onjob_sidebar_position() {
        $onjob_sidebar_position = array(
            'right-sidebar'         => esc_url( get_template_directory_uri() . '/assets/images/right.png' ),
            'no-sidebar'            => esc_url( get_template_directory_uri() . '/assets/images/full.png' ),
            'no-sidebar-content'    => esc_url( get_template_directory_uri() . '/assets/images/boxed.png' ),
        );

        $output = apply_filters( 'onjob_sidebar_position', $onjob_sidebar_position );

        return $output;
    }
endif;

if ( ! function_exists( 'onjob_pagination_options' ) ) :
    /**
     * Pagination
     * @return array site pagination options
     */
    function onjob_pagination_options() {
        $onjob_pagination_options = array(
            'numeric'   => esc_html__( 'Numeric', 'onjob' ),
            'default'   => esc_html__( 'Default(Older/Newer)', 'onjob' ),
        );

        $output = apply_filters( 'onjob_pagination_options', $onjob_pagination_options );

        return $output;
    }
endif;

if ( ! function_exists( 'onjob_switch_options' ) ) :
    /**
     * List of custom Switch Control options
     * @return array List of switch control options.
     */
    function onjob_switch_options() {
        $arr = array(
            'on'        => esc_html__( 'Enable', 'onjob' ),
            'off'       => esc_html__( 'Disable', 'onjob' )
        );
        return apply_filters( 'onjob_switch_options', $arr );
    }
endif;

if ( ! function_exists( 'onjob_hide_options' ) ) :
    /**
     * List of custom Switch Control options
     * @return array List of switch control options.
     */
    function onjob_hide_options() {
        $arr = array(
            'on'        => esc_html__( 'Yes', 'onjob' ),
            'off'       => esc_html__( 'No', 'onjob' )
        );
        return apply_filters( 'onjob_hide_options', $arr );
    }
endif;

if ( ! function_exists( 'onjob_sortable_sections' ) ) :
    /**
     * List of sections Control options
     * @return array List of Sections control options.
     */
    function onjob_sortable_sections() {
        $options = onjob_get_theme_options();
        $sections = array();
            $sections = array(
                'search'                => esc_html__( 'Search Section', 'onjob' ),
                'sponsor'               => esc_html__( 'Sponsor', 'onjob' ),
                'featured_job'          => esc_html__( 'Featured Jobs', 'onjob' ),
                'recent_job'            => esc_html__( 'Recent Jobs', 'onjob' ),
                'testimonial'           => esc_html__( 'Testimonial', 'onjob' ),
                'blog'                  => esc_html__( 'Blog', 'onjob' ),
            );
     
        return apply_filters( 'onjob_sortable_sections', $sections );
    }
endif;

if ( ! function_exists( 'onjob_featured_job_content_type' ) ) :
    /**
     * Destination Options
     * @return array site gallery options
     */
    function onjob_featured_job_content_type() {
        $onjob_featured_job_content_type = array(
            'category'          => esc_html__( 'Category', 'onjob' ),

        );

        if ( class_exists( 'WP_Job_Manager' ) ) {
            $onjob_featured_job_content_type = array_merge( $onjob_featured_job_content_type, array(
                'job_listing_category'      => esc_html__( 'Job Categories', 'onjob' ),
            ) );
        }

        $output = apply_filters( 'onjob_featured_job_content_type', $onjob_featured_job_content_type );

        return $output;
    }
endif;
