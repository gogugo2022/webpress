<?php
	/**
	 * The header for our theme.
	 *
	 * This is the template that displays all of the <head> section and everything up until <div id="content">
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
	 *
	 * @package Theme Palace
	 * @subpackage  Onjob
	 * @since  Onjob 1.0.0
	 */

	/**
	 * onjob_doctype hook
	 *
	 * @hooked onjob_doctype -  10
	 *
	 */
	do_action( 'onjob_doctype' );

?>
<head>
<?php
	/**
	 * onjob_before_wp_head hook
	 *
	 * @hooked onjob_head -  10
	 *
	 */
	do_action( 'onjob_before_wp_head' );

	wp_head(); 
?>
</head>

<body <?php body_class(); ?>>

<?php do_action( 'wp_body_open' ); ?>
<?php
	/**
	 * onjob_page_start_action hook
	 *
	 * @hooked onjob_page_start -  10
	 *
	 */
	do_action( 'onjob_page_start_action' ); 

	/**
	 * onjob_loader_action hook
	 *
	 * @hooked onjob_loader -  10
	 *
	 */
	do_action( 'onjob_before_header' );

	/**
	 * onjob_header_action hook
	 *
	 * @hooked onjob_site_branding -  10
	 * @hooked onjob_header_start -  20
	 * @hooked onjob_site_navigation -  30
	 * @hooked onjob_header_end -  50
	 *
	 */
	do_action( 'onjob_header_action' );

	/**
	 * onjob_content_start_action hook
	 *
	 * @hooked onjob_content_start -  10
	 *
	 */
	do_action( 'onjob_content_start_action' );

    /**
     * onjob_header_image_action hook
     *
     * @hooked onjob_header_image -  10
     *
     */
    do_action( 'onjob_header_image_action' );
	
