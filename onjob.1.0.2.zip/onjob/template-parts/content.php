<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Theme Palace
 * @subpackage  Onjob
 * @since  Onjob 1.0.0
 */

$options = onjob_get_theme_options();
$readmore = ! empty( $options['read_more_text'] ) ? $options['read_more_text'] : '';
?>
<article id="post-<?php the_ID(); ?>">
    <div class="post-wrapper">
            <div class="featured-image">
                <a href="<?php the_permalink(); ?>"><img src="<?php echo (has_post_thumbnail()) ? the_post_thumbnail_url( 'medium' ) : get_template_directory_uri().'/assets/uploads/no-featured-image-600x450.jpg'; ?>" alt="<?php the_title_attribute(); ?>"></a>
            </div><!-- .featured-image -->

       <div class="entry-container">
            <header class="entry-header">
                <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            </header>

            <div class="entry-meta">
               <?php onjob_posted_on(); ?>
               <span class="cat-links">
                    <?php echo get_the_category_list(' ', ' ')?>
                </span>
            </div>
        </div><!-- .entry-container -->
    </div>
</article>
