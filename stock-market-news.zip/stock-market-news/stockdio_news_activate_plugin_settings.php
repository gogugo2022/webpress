<div class="updated" style="padding: 0; margin: 0; border: none; background: none;">
    <div class="stockdio_header"></div>
</div>
