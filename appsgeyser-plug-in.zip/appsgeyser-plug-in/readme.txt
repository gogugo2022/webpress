=== Plugin Name ===
Contributors: appsgeyser
Tags: appsgeyser, android, app, mobile, smartphone, application, convert, create


AppsGeyser Plug-in for WordPress allows you to convert your blog into a native Android app. Make your blog easy to read on mobile devices. 

== Description ==

Use AppsGeyser Plugin to convert your blog to a native Android app. Make your blog easy to read on mobile devices. Submit your app to Android Market and increase your audience.

AppsGeyser is the web platform that allows you to convert any web content to an Android App. With AppsGeyser you can convert any web content or widget into an App in 2 simple steps

http://www.youtube.com/watch?v=-kA6miefsfM

This Plug-in utilizes AppsGeyser API that allows creating Android Apps on-the-fly from any third-party software. 

http://www.youtube.com/watch?v=2el7_PO0Xpw

== Installation ==


1. Download Plugin
2. Extract archive to your blog Plugns directory, usually yourblog.com/wp-content/plugins/
3. Login to Admin Dashboard, open Plugins, find AppsGeyser Plugin and activate it.
4. In order to create native Android apps you need to active Wordpress Mobile Pack or Carrington Mobile theme
5. Open Tools->AppsGeyser Plugin and input your app name, e-mail and desired password. Click Create to create your account with AppsGeyser
6. You account and app will be created. You'll get the link where you can download your app.
7. Use your e-mail and password to modify your Android App
 