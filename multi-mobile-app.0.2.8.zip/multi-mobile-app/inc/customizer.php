<?php
/**
 * Multi Mobile App: Customizer
 *
 * @subpackage Multi Mobile App
 * @since 1.0
 */

use WPTRT\Customize\Section\Multi_Mobile_App_Button;

add_action( 'customize_register', function( $manager ) {

	$manager->register_section_type( Multi_Mobile_App_Button::class );

	$manager->add_section(
		new Multi_Mobile_App_Button( $manager, 'multi_mobile_app_pro', [
			'title'       => esc_html__( 'Multi Mobile App Pro', 'multi-mobile-app' ),
			'priority'    => 0,
			'button_text' => esc_html__( 'Go Pro', 'multi-mobile-app' ),
			'button_url'  => esc_url('https://www.luzuk.com/products/wordpress-mobile-app-theme/')
		] )
	);

} );

// Load the JS and CSS.
add_action( 'customize_controls_enqueue_scripts', function() {

	$version = wp_get_theme()->get( 'Version' );

	wp_enqueue_script(
		'multi-mobile-app-customize-section-button',
		get_theme_file_uri( 'vendor/wptrt/customize-section-button/public/js/customize-controls.js' ),
		[ 'customize-controls' ],
		$version,
		true
	);

	wp_enqueue_style(
		'multi-mobile-app-customize-section-button',
		get_theme_file_uri( 'vendor/wptrt/customize-section-button/public/css/customize-controls.css' ),
		[ 'customize-controls' ],
 		$version
	);

} );

function multi_mobile_app_customize_register( $wp_customize ) {

	$wp_customize->add_setting('multi_mobile_app_logo_padding',array(
       'sanitize_callback'	=> 'esc_html'
    ));
    $wp_customize->add_control('multi_mobile_app_logo_padding',array(
       'label' => __('Logo Padding','multi-mobile-app'),
       'section' => 'title_tagline'
    ));

	$wp_customize->add_setting('multi_mobile_app_logo_top_padding',array(
       'default' => '',
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_float'
    ));
    $wp_customize->add_control('multi_mobile_app_logo_top_padding',array(
       'type' => 'number',
       'description' => __('Top','multi-mobile-app'),
       'section' => 'title_tagline',
    ));

	$wp_customize->add_setting('multi_mobile_app_logo_bottom_padding',array(
       'default' => '',
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_float'
    ));
    $wp_customize->add_control('multi_mobile_app_logo_bottom_padding',array(
       'type' => 'number',
       'description' => __('Bottom','multi-mobile-app'),
       'section' => 'title_tagline',
    ));

	$wp_customize->add_setting('multi_mobile_app_logo_left_padding',array(
       'default' => '',
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_float'
    ));
    $wp_customize->add_control('multi_mobile_app_logo_left_padding',array(
       'type' => 'number',
       'description' => __('Left','multi-mobile-app'),
       'section' => 'title_tagline',
    ));

	$wp_customize->add_setting('multi_mobile_app_logo_right_padding',array(
       'default' => '',
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_float'
    ));
    $wp_customize->add_control('multi_mobile_app_logo_right_padding',array(
       'type' => 'number',
       'description' => __('Right','multi-mobile-app'),
       'section' => 'title_tagline',
    ));

	$wp_customize->add_setting('multi_mobile_app_show_site_title',array(
       'default' => true,
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_checkbox'
    ));
    $wp_customize->add_control('multi_mobile_app_show_site_title',array(
       'type' => 'checkbox',
       'label' => __('Show / Hide Site Title','multi-mobile-app'),
       'section' => 'title_tagline'
    ));

    $wp_customize->add_setting('multi_mobile_app_show_tagline',array(
       'default' => true,
       'sanitize_callback'	=> 'multi_mobile_app_sanitize_checkbox'
    ));
    $wp_customize->add_control('multi_mobile_app_show_tagline',array(
       'type' => 'checkbox',
       'label' => __('Show / Hide Site Tagline','multi-mobile-app'),
       'section' => 'title_tagline'
    ));

	$wp_customize->add_panel( 'multi_mobile_app_panel_id', array(
	    'priority' => 10,
	    'capability' => 'edit_theme_options',
	    'theme_supports' => '',
	    'title' => __( 'Theme Settings', 'multi-mobile-app' ),
	    'description' => __( 'Description of what this panel does.', 'multi-mobile-app' ),
	) );

	$wp_customize->add_section( 'multi_mobile_app_theme_options_section', array(
    	'title'      => __( 'General Settings', 'multi-mobile-app' ),
		'priority'   => 30,
		'panel' => 'multi_mobile_app_panel_id'
	) );

	// Add Settings and Controls for Layout
	$wp_customize->add_setting('multi_mobile_app_theme_options',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'multi_mobile_app_sanitize_choices'	        
	));

	$wp_customize->add_control('multi_mobile_app_theme_options',array(
        'type' => 'radio',
        'label' => __('Do you want this section','multi-mobile-app'),
        'section' => 'multi_mobile_app_theme_options_section',
        'choices' => array(
            'Left Sidebar' => __('Left Sidebar','multi-mobile-app'),
            'Right Sidebar' => __('Right Sidebar','multi-mobile-app'),
            'One Column' => __('One Column','multi-mobile-app'),
            'Three Columns' => __('Three Columns','multi-mobile-app'),
            'Four Columns' => __('Four Columns','multi-mobile-app'),
            'Grid Layout' => __('Grid Layout','multi-mobile-app')
        ),
	));

	// Top Bar
	$wp_customize->add_section( 'multi_mobile_app_top_bar', array(
    	'title'      => __( 'Contact Details', 'multi-mobile-app' ),
		'priority'   => null,
		'panel' => 'multi_mobile_app_panel_id'
	) );

	$wp_customize->add_setting('multi_mobile_app_hide_show_topbar',array(
    	'default' => false,
    	'sanitize_callback'	=> 'multi_mobile_app_sanitize_checkbox'
	));
	$wp_customize->add_control('multi_mobile_app_hide_show_topbar',array(
   	'type' => 'checkbox',
   	'label' => __('Show / Hide Topbar','multi-mobile-app'),
   	'section' => 'multi_mobile_app_top_bar',
	));

	$wp_customize->add_setting('multi_mobile_app_email_address',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_email'
	));	
	$wp_customize->add_control('multi_mobile_app_email_address',array(
		'label'	=> __('Add Email Address','multi-mobile-app'),
		'section'=> 'multi_mobile_app_top_bar',
		'setting'=> 'multi_mobile_app_email_address',
		'type'=> 'text'
	));

	$wp_customize->add_setting('multi_mobile_app_phone_number',array(
		'default'=> '',
		'sanitize_callback'	=> 'multi_mobile_app_sanitize_phone_number'
	));	
	$wp_customize->add_control('multi_mobile_app_phone_number',array(
		'label'	=> __('Add Phone Number','multi-mobile-app'),
		'section'=> 'multi_mobile_app_top_bar',
		'setting'=> 'multi_mobile_app_phone_number',
		'type'=> 'text'
	));

	//social icons
	$wp_customize->add_section( 'multi_mobile_app_social', array(
    	'title'      => __( 'Social Icons', 'multi-mobile-app' ),
		'priority'   => null,
		'panel' => 'multi_mobile_app_panel_id'
	) );

	$wp_customize->add_setting('multi_mobile_app_facebook_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('multi_mobile_app_facebook_url',array(
		'label'	=> __('Add Facebook link','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_social',
		'setting'	=> 'multi_mobile_app_facebook_url',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('multi_mobile_app_twitter_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('multi_mobile_app_twitter_url',array(
		'label'	=> __('Add Twitter link','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_social',
		'setting'	=> 'multi_mobile_app_twitter_url',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('multi_mobile_app_instagram_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));	
	$wp_customize->add_control('multi_mobile_app_instagram_url',array(
		'label'	=> __('Add Instagram link','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_social',
		'setting'	=> 'multi_mobile_app_instagram_url',
		'type'	=> 'url'
	));

	$wp_customize->add_setting('multi_mobile_app_linkedin_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));
	$wp_customize->add_control('multi_mobile_app_linkedin_url',array(
		'label'	=> __('Add Linkedin link','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_social',
		'setting'	=> 'multi_mobile_app_linkedin_url',
		'type'	=> 'url'
	));

	//home page slider
	$wp_customize->add_section( 'multi_mobile_app_slider_section' , array(
    	'title'      => __( 'Slider Settings', 'multi-mobile-app' ),
		'priority'   => null,
		'panel' => 'multi_mobile_app_panel_id'
	) );

	$wp_customize->add_setting('multi_mobile_app_slider_hide_show',array(
    	'default' => false,
    	'sanitize_callback'	=> 'multi_mobile_app_sanitize_checkbox'
	));
	$wp_customize->add_control('multi_mobile_app_slider_hide_show',array(
   	'type' => 'checkbox',
   	'label' => __('Show / Hide slider','multi-mobile-app'),
   	'description' => __('Image Size ( 1400px x 800px )','multi-mobile-app'),
   	'section' => 'multi_mobile_app_slider_section',
	));

	for ( $count = 1; $count <= 4; $count++ ) {

		$wp_customize->add_setting( 'multi_mobile_app_slider' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'multi_mobile_app_sanitize_dropdown_pages'
		) );

		$wp_customize->add_control( 'multi_mobile_app_slider' . $count, array(
			'label'    => __( 'Select Slide Image Page', 'multi-mobile-app' ),
			'section'  => 'multi_mobile_app_slider_section',
			'type'     => 'dropdown-pages'
		) );
	}

	// Our Services 
	$wp_customize->add_section('multi_mobile_app_services_section',array(
		'title'	=> __('Our Services','multi-mobile-app'),
		'description'=> __('This section will appear below the Slider section.','multi-mobile-app'),
		'panel' => 'multi_mobile_app_panel_id',
	));
	
	$wp_customize->add_setting('multi_mobile_app_services_title',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('multi_mobile_app_services_title',array(
		'label'	=> __('Section Title','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_services_section',
		'setting'	=> 'multi_mobile_app_services_title',
		'type'		=> 'text'
	));

	$categories = get_categories();
	$cats = array();
	$i = 0;
	$cat_pst4[]= 'select';
	foreach($categories as $category){
		if($i==0){
			$default = $category->slug;
			$i++;
		}
		$cat_pst4[$category->slug] = $category->name;
	}

	$wp_customize->add_setting('multi_mobile_app_services_cat',array(
		'default'	=> 'select',
		'sanitize_callback' => 'multi_mobile_app_sanitize_select',
	));
	$wp_customize->add_control('multi_mobile_app_services_cat',array(
		'type'    => 'select',
		'choices' => $cat_pst4,
		'label' => __('Select Category to display Service Posts','multi-mobile-app'),
		'section' => 'multi_mobile_app_services_section',
	));

	$wp_customize->add_setting('multi_mobile_app_service_section_padding',array(
		'default' => '',
		'sanitize_callback'	=> 'multi_mobile_app_sanitize_float'
	));
	$wp_customize->add_control('multi_mobile_app_service_section_padding',array(
		'type' => 'number',
		'label' => __('Section Top Bottom Padding','multi-mobile-app'),
		'section' => 'multi_mobile_app_services_section',
	));

	//Footer
   $wp_customize->add_section( 'multi_mobile_app_footer', array(
    	'title'      => __( 'Footer Text', 'multi-mobile-app' ),
		'priority'   => null,
		'panel' => 'multi_mobile_app_panel_id'
	) );

   $wp_customize->add_setting('multi_mobile_app_show_back_totop',array(
    	'default' => true,
      'sanitize_callback'	=> 'multi_mobile_app_sanitize_checkbox'
   ));
   $wp_customize->add_control('multi_mobile_app_show_back_totop',array(
      'type' => 'checkbox',
      'label' => __('Show / Hide Back to Top','multi-mobile-app'),
      'section' => 'multi_mobile_app_footer'
   ));

 	$wp_customize->add_setting('multi_mobile_app_footer_copy',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('multi_mobile_app_footer_copy',array(
		'label'	=> __('Footer Text','multi-mobile-app'),
		'section'	=> 'multi_mobile_app_footer',
		'setting'	=> 'multi_mobile_app_footer_copy',
		'type'		=> 'text'
	));

	$wp_customize->get_setting( 'blogname' )->transport          = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport   = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport  = 'postMessage';

	$wp_customize->selective_refresh->add_partial( 'blogname', array(
		'selector' => '.site-title a',
		'render_callback' => 'multi_mobile_app_customize_partial_blogname',
	) );
	$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
		'selector' => '.site-description',
		'render_callback' => 'multi_mobile_app_customize_partial_blogdescription',
	) );
}
add_action( 'customize_register', 'multi_mobile_app_customize_register' );

function multi_mobile_app_customize_partial_blogname() {
	bloginfo( 'name' );
}

function multi_mobile_app_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

function multi_mobile_app_is_static_front_page() {
	return ( is_front_page() && ! is_home() );
}

function multi_mobile_app_is_view_with_layout_option() {
	// This option is available on all pages. It's also available on archives when there isn't a sidebar.
	return ( is_page() || ( is_archive() && ! is_active_sidebar( 'sidebar-1' ) ) );
}

//select sanitization function
function multi_mobile_app_sanitize_select( $input, $setting ){
  
    //input must be a slug: lowercase alphanumeric characters, dashes and underscores are allowed only
    $input = sanitize_key($input);

    //get the list of possible select options 
    $choices = $setting->manager->get_control( $setting->id )->choices;
                      
    //return input if valid or return default option
    return ( array_key_exists( $input, $choices ) ? $input : $setting->default );                
      
}