# Change Log

All notable changes to this project will be documented in this file.
See our latest change on project website (finpose.com/changelog)

## [4.3.2] - 2021-12-06
### Added:
- Vendor select option in spendings form
- Settings and reports update

## [4.3.1] - 2021-11-18
### Fixed:
- Import stock on Inventory page
- Choose vendor while adding new stock

## [4.3.0] - 2021-11-13
### Changed:
- Moved menu to top
### Added:
- Settings page
- Fiscal year setting
- Date format setting

## [4.1.3] - 2021-10-18
### Added:
- Documentation links for all pages
- Balance sheet


## [4.0.1] - 2021-07-16
### Added:
- Error handling

## [3.3.0] - 2021-07-16
### Added:
- Advanced filters and search tab for inventory page
### Fixed:
- Profit Loss report

## [3.2.4] - 2021-05-31
### Added:
- Invoice ID, Net Price for Tax List
- Invoice ID and Date for Order Reports
- Fixed Decimal Length for Tax Page

## [3.2.1] - 2021-04-20
### Added:
- Translation files for 42 languages
- List page for taxes payable (exportable)

## [3.2.0] - 2021-03-31
### Added:
- Timeframe selectors
- Bug fixes
- Layout updates

## [3.1.0] - 2021-03-22
### Added:
- Attachments for spendings

## [3.0.1] - 2020-12-16
### Added:
- Multisite support added
- Bug fixes

## [3.0.0] - 2020-12-06
### Added:
- Profit / Loss Report
- New Dashboard with combined spendings, sales, profitability insights
- Export feature for spendings

## [2.2.2] - 2019-11-17
### Added:
- Inventory units edit page for each product
### Fixed : 
- Single quote text problems fixed
  Stay on same page after adding new items to inventory

## [2.2.1] - 2019-11-02
### Added:
- Added translation files for Arabic, German, French, Spanish and Russian
### Fixed : 
- Bug fixes

## [2.2.0] - 2019-09-04
### Added:
- Advanced order filtering & export page
### Fixed:
- Adjusted all fonts for better readability

## [2.1.1] - 2019-08-03
### Fixed:
- WP notices when no data provided

## [2.1.0] - 2019-07-18
### Added:
- Inventory module
- Currency sign on accounts page

## [2.0.3] - 2019-07-05
### Fixed:
- Currency length increased to 11 digits
### Added:
- Digits seperator (comma) for all currency numbers added

## [2.0.2] - 2019-06-08
### Fixed:
- Default starting point set to 0 for horizontal chart
- Auto reload when adding a new spending
- Account transactions display for each account
- Edit/remove capability for accounts
- Fixed nan dashboard numbers when no sales

## [2.0.1] - 2019-06-06
### Added:
- Delete spending categories ability
- Link for automatically adding existing gateways as accounts

## [2.0.0] - 2019-05-04
### Added:
- Sales Dashboard and Insights
- Sales Data by Top Countries, Bestsellers, Payment Methods
- Spendings Data by Top Categories, Type and Payment Methods

### Changed
- Entire Layout
- Merged Costs, Expenses, Acquisition into Spendings
- Account records moved to WP options from Database table

### Fixed

## [1.0.1] - 2019-12-14
### Added:

### Changed
- Reports : Removed trailing .00 decimals if value equals 0

### Fixed
- Product reports : number of products in report were limited to 10, fix applied to show unlimited products
- Product reports : division by zero error
- Taxes : fixed order tax totals

## [1.0.0] - 2019-12-11
### Added:
- Initial Release
### Changed
### Fixed
### Removed
