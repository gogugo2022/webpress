var app = new Vue({
	el: '#finapp',
	data: {
		quarters: {},
	},
	mounted: function() {
		
	},
	methods: {

	},
	created() {
		this.$root.$refs.app = this;
	}
});