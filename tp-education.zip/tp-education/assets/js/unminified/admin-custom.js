jQuery(document).ready(function () {
	jQuery("#event_date_id, #excursion_start_date_id, #excursion_end_date_id").datepicker(), jQuery("#event_time_from_id").timepicker(), jQuery("#event_time_to_id").timepicker()
});