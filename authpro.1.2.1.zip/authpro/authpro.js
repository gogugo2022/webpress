// Add AuthPro sid to comments form

function ap_comments_sid() {
  if((typeof(usid)!="undefined")&&(document.getElementById('commentform')!=null)) {
    var ap_sid=document.createElement('input');
    ap_sid.setAttribute('type','hidden');
    ap_sid.setAttribute('name','ap_sid');
    ap_sid.setAttribute('value',usid);
    document.getElementById('commentform').appendChild(ap_sid);
  }
}

document.addEventListener("DOMContentLoaded", ap_comments_sid);
