###  CHANGELOG Version Numbers: 1.2.3

1. An increment in the major version indicates a break in backward compatibility.
2. An increment in the minor version indicates the addition of new features or a significant change to existing features.
3. An increment in the patch version indicates that minor features have been changed or bugs have been fixed.


### 1.0.5 - August 6, 2020

**Changes:** 

- Fixed the Changelog page error showing up in the theme info page within the admin area.
- Added WordPress required information in the style.css file for: Requires at least, Requires PHP, Tested up to.
- Added a special wp_body_open function to the header file: now required by WordPress.
- Updated the language translation .pot file.
- Updated the readme.txt file with some corrections to the contributor name--needs to be username.
- Updated image credits for the screenshot.
- Updated the theme screenshot.


### 1.0.4 - January 10, 2020

**Changes:** 

- Customizer: Link Colour fix in inc/inline-styles.php


### 1.0.3 - June 26, 2019

**Changes:** 

- Coupon updates and small bug fixes.


### 1.0.2 - June 8, 2019

**Changes:** 

- Updates to various documentation links.
- Changed minimum WordPress required version to 4.7


### 1.0.1 - February 6, 2019

**Changes:** 

- Updated URLs to Blogging Theme Styles
- Added a $5 discount for upgrade to pro
- Updated the Customizer and About page upgrade/upsell information
- Updated the language .pot translation file


### 1.0.0 - November 21, 2017

**Changes:** 

- Theme release as first version

