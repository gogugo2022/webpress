(function () {
	let $ = jQuery	
	var js_stockdio_popular_array = null
	var js_stockdio_form;
	var js_stockdio_popular_array_special = null
	var js_default_exchange_id = "#default_exchange"
	var js_default_symbol_id = "#default_symbols"
	var js_from_blocks = false;
	var js_exchange_modal= false;
	var js_setAttributes = null;
	var js_current_type = '';
	var js_p_valdiate_text = '';
	var js_filter_param = '';
	var js_is_market_overview = false;
	var js_is_single_symbol= false;

	initAll = function(){
		js_from_blocks = false;
		js_exchange_modal= false;
		js_setAttributes = null;
		js_current_type = '';
		js_p_valdiate_text = '';
		js_filter_param = '';
		js_is_market_overview = false;
		js_is_single_symbol= false;
	}
	
	stockdio_open_exchange_modal =  function(e, setAttributes){
		initAll();
		var button = $(e);		
		js_exchange_modal = true;
		if (setAttributes){
			js_from_blocks = true;
			js_setAttributes = setAttributes
			js_default_exchange_id = "#select-exchange"
			js_default_symbol_id = "#default_symbols"
			js_stockdio_form = $('body');	
		}
		else {
			js_stockdio_form = button.closest('form');		
		}
		if (!js_stockdio_popular_array){
			js_stockdio_popular_array =  stockdio_get_popular_array();
		}
		else{
			s_s_init();
		}		
	}
	stockdio_open_search_single_modal_from_block=  function(setAttributes, type){
		initAll();
		js_default_exchange_id = "#select-exchange"
		js_default_symbol_id = "#default_symbol";
		js_is_single_symbol=true;
		js_exchange_modal = false;
		js_from_blocks = true;		
		js_setAttributes = setAttributes
		js_stockdio_form = $('body');		
		if (type){
			js_current_type = type;
		}
		if (!js_stockdio_popular_array){
			js_stockdio_popular_array =  stockdio_get_popular_array();
		}
		else{
			s_s_init();
		}		
	}
	stockdio_open_search_modal_from_block =  function(setAttributes, type){
		initAll();
		js_exchange_modal = false;
		js_default_exchange_id = "#select-exchange"
		js_default_symbol_id = "#default_symbols"
		js_from_blocks = true;		
		js_setAttributes = setAttributes
		js_stockdio_form = $('body');		
		if (type){
			js_current_type = type;
		}
		if (!js_stockdio_popular_array){
			js_stockdio_popular_array =  stockdio_get_popular_array();
		}
		else{
			s_s_init();
		}
	}

	stockdio_open_search_symbol_modal  =  function(e, type){
		initAll();
		js_default_symbol_id = "#default_symbol";
		js_is_single_symbol=true;
		stockdio_open_search_modal_global(e,type);
	}

	stockdio_open_search_modal =  function(e, type){
		initAll();
		stockdio_open_search_modal_global(e,type);
	}

	stockdio_open_search_modal_global =  function(e, type){
		js_exchange_modal = false;
		var button = $(e);
		js_current_type = type;
		js_stockdio_form = button.closest('form');		
		if (!js_stockdio_popular_array){
			js_stockdio_popular_array =  stockdio_get_popular_array();
		}
		else{
			s_s_init();
		}
	}

	s_s_init =  function(){		
		var modal = js_stockdio_form.find('.stockdio_search_modal')
		var default_ExchangeObj = js_stockdio_form.find(js_default_exchange_id);
		var default_SymbolsObj = js_stockdio_form.find(js_default_symbol_id);

		if (js_exchange_modal){
			if (modal.length <= 0){
				modal = $(stockdio_create_search_modal('Select Exchange', "s_s_modal_exchange"))
				var symbols = default_SymbolsObj.val()
				var exchange = default_ExchangeObj.val()		
				var modalBody = $(stockdio_get_modal_exchange_body(exchange))			
				modal.find(".stockdio_modal_body").append(modalBody);
				js_stockdio_form.append(modal);
				if (js_stockdio_popular_array)
					stockdio_fill_popular_elemets(modal);
				for(var i=0; i< js_stockdio_popular_array.length; i++){
					if (js_stockdio_popular_array[i][1] === exchange && js_stockdio_popular_array[i][3] == 2){
						$(`.s_s_modal_exchange .s_s_li_${js_stockdio_popular_array[i][5]} a`).click();
						break;
					}
				}							
			}
		}
		else{
			if (modal.length <= 0){
				var sMainClass = s_s_get_main_class();
				modal = $(stockdio_create_search_modal('Select data to display',sMainClass))
				var symbols = s_s_get_default_symbols(default_SymbolsObj);
				var exchange = default_ExchangeObj.val()
				var modalBody = $(stockdio_get_modal_body(exchange))			
				modal.find(".stockdio_modal_body").append(modalBody);
				js_stockdio_form.append(modal);
				$(".stockdio_search_loading").show();
				js_stockdio_form.find(".stockdio_close_modal").click(function(){
					modal.remove();
				})
				modal.find(".stockdio_search_input_text").val(symbols);	

				modal.find(".stockdio_search_symbols_div .stockdio_search_inner_div").show();
				var js_totalRowHeight = $(".s_s_h_td1").outerHeight()

				if (js_stockdio_popular_array)
					stockdio_fill_popular_elemets(modal);

					//<p class="s_s_p_validate_text">Select your default Stock Exchange and type or paste the list of symbols, separated by semi-colon (;)</p> js_current_type
				if (js_current_type)
					modal.find(".s_s_p_validate_text").text(`Type or paste the list of ${js_current_type}, separated by semi-colon (;)`);
				//adjust size:
				var outerHeight = 0;
				$('.s_s_h').each(function() {
					outerHeight += $(this).outerHeight();
				});
				
				var maxHeight = js_totalRowHeight - outerHeight - 120;
				$(".stockdio_search_elements_list").css("min-height",maxHeight)
				//$(".stockdio_search_inner_div2").width($(".stockdio_search_inner_div2").parent().width() - 2);
				if (symbols && symbols.trim() !== ""){
					$(".stockdio_search_popular_div").addClass("s_s_long_tile");				
					$(".s_s_h_tr_own_symbols").show();				
					$(".s_s_choose_tile, .s_s_p_choose, .s_s_i_forward, .s_s_back").hide();
					$(".s_s_h_tr_bottom_back, .s_s_i_ok").show();	
				}
				else{
					$(".stockdio_search_loading").hide();
				}

				$(".s_s_stock_market_overview .s_s_h_tr_own_symbols").show();		
				$(".s_s_stock_market_overview .s_s_i_forward, .s_s_stock_market_overview .s_s_back").hide();
				$(".s_s_stock_market_overview .s_s_i_ok").show();	
				$(".s_s_stock_market_overview .s_s_h_tr_bottom_back").show();	
				if (js_is_single_symbol){
					$(".s_s_h_tr_own_symbols").show();
					$(".s_s_i_forward, .s_s_back").hide();
					$(".s_s_i_ok").show();	
					$(".s_s_h_tr_bottom_back").show();	
				}
			}
			stockdio_processSymbolsString(false,false);
		}
	}

	s_s_get_default_symbols = function(symbolsObj){
		if (js_current_type){
			return $("#default_" + js_current_type).val();
		}
		else
			return symbolsObj.val();
	}
	

	s_s_get_main_class= function(){
		

		if (js_is_single_symbol){
			return 's_s_single_symbol';
		}
		if (js_current_type === "indices" || js_current_type === "commodities" || js_current_type === "equities" ||js_current_type === "currencies"){
			js_is_market_overview = true;
			if (js_current_type === "indices" || js_current_type === "commodities")
				js_filter_param=js_current_type.toUpperCase();
			else{
				if (js_current_type === "currencies")
					js_filter_param='FOREX';
				else
					js_filter_param=$(js_default_exchange_id).val();
			}
			return 's_s_stock_market_overview';
		}
		return '';
	}

	stockdio_fill_popular_elemets = function(modal){
		var item; var exchangeDetails = []
		var categories = {}
		js_stockdio_popular_array_special = [];
		for (var i=0; i<js_stockdio_popular_array.length;i++){
			item = {}
			item["isGroup"] = js_stockdio_popular_array[i][4]
			item["name"] = js_stockdio_popular_array[i][0]
			item["dExch"] = js_stockdio_popular_array[i][1]
			item["symbols"] = js_stockdio_popular_array[i][2]
			item["category"] = js_stockdio_popular_array[i][3]
			item["country"] = js_stockdio_popular_array[i][5]
			item["dExchName"] = js_stockdio_popular_array[i][6]
			item["categoryName"] = js_stockdio_popular_array[i][7]
			item["countryName"] = js_stockdio_popular_array[i][8]
			item["inputPlaceholder"] = js_stockdio_popular_array[i][9]
			//item["categoryName"] = item["category"]==1?"Global Overview":item["category"]==2?"Market Overview for a specefic country":"Stocks by Industry"

			if (item["category"] == -1){
				js_stockdio_popular_array_special.push(item);
			}

			if (!categories[item["category"]])
				 categories[item["category"]] = []

			categories[item["category"]].push(item);
		}
		s_s_processPopularCategories(categories, modal)
		//console.log("____categories",categories)
	}

	s_s_processPopularCategories = function(categories, modal){
		var items;
		for (var i=1; i<6;i++){
			if (!categories[i])
				continue;				
			items = categories[i]
			if (items.length <= 0)
				continue;
			s_s_processPopularSingleCategory(items, modal)
		}
	}

	s_s_open_popular_cats= function(e){
	}

	s_group_by_country = function(items){
		var group = {};
		var item
		for(var i=0; i< items.length; i++){
			if (!group[items[i].countryName])
				group[items[i].countryName] = [];
			item = {};
			item.dExch = items[i].dExch;
			item.dExchName = items[i].dExchName;
			item.symbols = items[i].symbols;
			item.name = items[i].name;
			item.country = items[i].country;
			item.countryName = items[i].countryName;
			group[items[i].countryName].push(item);
		}
		return Object.entries(group).sort().reduce( (o,[k,v]) => (o[k]=v,o), {} );
		//return group;
	}

	s_s_processPopularSingleCategory= function(items, modal){
		var catName = items[0].categoryName
		var button
		var exchName = items[0].name;
		var exch = items[0].dExch;
		var symbols = items[0].symbols;
		var keyCountry="";
		var divList = ""
		var placeholder= items[0].inputPlaceholder;
		if (true){
			var flag = `<i class="s_s_i_separator"></i>`, rightCol = "", sClass=""; leftCol="";
			var groupItems = null
			if (items[0].isGroup){
				keyCountry= items[0].countryName;
				sClass="s_s_details_list_big"
				groupItems = s_group_by_country(items);
				exchName = "NYSE-Nasdaq-NYSE MKT";
				symbols = "AAPL;MSFT;GOOG;FB;ORCL;^SPX;^IXIC;^DJI;FOREX:EUR/USD;FOREX:GBP/USD;BONDS:US10YBY";
				exch = "NYSENASDAQ";
				flag = `<i class="stockdio_flag_icon stockdio_icon_mini" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/us.svg)"></i>`;
				rightCol = `<div class="s_s_details_list_inner_r">
						<ul class="s_s_ul_country_exchanges">							
						</ul>
					</div>`
				var restOfElements = ``;
				//<li><a onclick="stockdio_onclick_popular_li(this,'AAPL','COMMODITIES','','Commodities','')"><span class="s_s_list_link_text">Commodities</span></a></li>
				var sSelected;
				for (var k =0; k<js_stockdio_popular_array_special.length; k++){					
					restOfElements += `<li><a onmouseover="s_s_rest_of_elements_hover(true)" onclick="stockdio_onclick_popular_li(this,'','${js_stockdio_popular_array_special[k].dExch}','','${js_stockdio_popular_array_special[k].name}','')">
					<span class="s_s_list_link_text">${js_stockdio_popular_array_special[k].name}</span></a></li>`
				}
				leftCol = `<div class="s_s_details_list_inner_l1">
					<ul class="s_s_ul_exchanges_cats">	
						<li><a onmouseover="s_s_rest_of_elements_hover(false)"  onclick="s_s_show_exchanges()"><span class="s_s_list_link_text">Exchanges</span></a></li>
						${restOfElements}
					</ul>
				</div>`			

			}


			button = `<div type="button" class="stockdio_s_exchanges_details_button" onclick="stockdio_open_exchanges_details(this)">
			<span class="stockdio_s_pull_left">
			${flag}
			${exchName}</span>&nbsp;<span class="caret"></span>
			</div>`;
			 divList = `<div class="stockdio_s_details_list ${sClass}"  tabindex="0" >
					 <div class="s_s_details_list_header">					 	
						 <div class="s_s_right" onclick="stockdio_hide_exchanges_details()"><svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="-2 -2 24 24" role="img" aria-hidden="true" focusable="false"><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"></path></svg></div>					 						 
						 <div class="s_s_left"><input class="s_s_search_input" type="text" placeholder="${placeholder}"></input></div>
					</div>
					 <div class="s_s_details_list_inner">
					 	${leftCol}
					 	<div class="s_s_details_list_inner_l">
							<ul class="stockdio_s_exchanges_details_ul">																																																														
							</ul>
						</div>
						${rightCol}
					</div>
				</div>`
				var divListObj = $(divList);
				if (groupItems){
					for (var key in groupItems) {
						if (groupItems.hasOwnProperty(key)) {

							var li =  `<li class='s_s_li_${groupItems[key][0].country}'><a onclick="stockdio_onclick_popular_li_country(this, false)">
							<span class="stockdio_flag_icon stockdio_icon_mini" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/${groupItems[key][0].country}.svg)"></span>
							<span class="s_s_list_link_text">${key}</span><span class="fa fa-check check-mark"></span></a></li>`
							var liObj = $(li);
							liObj.data("items",groupItems[key])
							liObj.find("a").hover(function(){
								stockdio_onclick_popular_li_country(this, true)
							})
							divListObj.find("ul.stockdio_s_exchanges_details_ul").append(liObj);
						}
					}
				}
				else{
					for (var i=0; i< items.length;i++){
						sSelected = items[i].name === exchName?"class='s_selected'":"";
						divListObj.find("ul.stockdio_s_exchanges_details_ul").append(`<li ${sSelected}><a onclick="stockdio_onclick_popular_li(this,'${items[i].symbols}','${items[i].dExch}','${items[i].country}','${items[i].name}','${items[i].countryName}')">						
						<span class="s_s_list_link_text">${items[i].name}</span><span class="fa fa-check check-mark"></span></a></li>`)			
					}	
				}
	
			
		}


		
		if (items[0].isGroup){
			//create exchange
			if ($(".s_s_new_search_exchange div").length <=0 ){
				var default_ExchangeObj = js_stockdio_form.find(js_default_exchange_id);
				var butonObj = $(button)
				
				var exchangeInfo = s_s_search_exchange_info(default_ExchangeObj.val());
				butonObj.html(`<span class="stockdio_s_pull_left"><i class="stockdio_flag_icon stockdio_icon_mini" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/${exchangeInfo.country}.svg)"></i>
				${exchangeInfo.exchName}</span>`)					
				butonObj.data("exchange",exchangeInfo.exch);
				butonObj.data("keyCountry",exchangeInfo.country);
				//tileObj.find(".stockdio_s_exchanges_details_button").data("keyCountry",keyCountry);					
				//console.log("butonObj",butonObj.clone()[0].outerHTML)
				divListObj.clone(true).appendTo($(".s_s_h_tr_custom td"))
				butonObj.clone(true).appendTo($(".s_s_new_search_exchange"))

				//console.log("s_s_new_search_exchange",$(".s_s_new_search_exchange").html())
				$(".s_s_h_tr_custom").find(".s_s_details_list_header input").keyup(function(){
					s_filter_values(this, true);
				});

				s_s_set_exchange_value(exchangeInfo.exch);
				//$(".s_s_new_search_exchange").find(".stockdio_s_exchanges_details_button").data("exchange",exchangeInfo.exch);


			}
			//modal.find(".stockdio_search_exchange_select").val(default_ExchangeObj.val());
		}

		var iconName = `PopularTickers${items[0].category}.svg`
		var tile = `<div class="stockdio_s_tile s_s_small_tile">
						<div><i class="s_tile_icon" style="background-image: url(https://services.stockdio.com/assets/images/${iconName})"></i></div>
		
			<span class="s_s_tile_title">${catName}</span>
			${button}
			<div class="s_s_tile_button_continue" onclick="s_s_onchange_select_popular(this)"><span>Select</span></div>		
		</div>`

		var tileObj = $(tile);

		if (!js_exchange_modal) {
			tileObj.append(divListObj);	
			modal.find(".s_s_div_popular_tiles").append(tileObj);
		}
		else{
			modal.find(".s_s_exchange_selector_div").append(divListObj);
			modal.find(".s_s_exchange_selector_div").append(button);
			modal.find(".stockdio_s_exchanges_details_button").hide();			
			modal.find(".stockdio_s_exchanges_details_button").data("exchange",$(js_default_exchange_id).val());
		}

		tileObj.find(".stockdio_s_exchanges_details_button").data("exchange",exch);
		tileObj.find(".stockdio_s_exchanges_details_button").data("symbols",symbols);
		tileObj.find(".stockdio_s_exchanges_details_button").data("keyCountry",keyCountry);
		tileObj.find(".s_s_details_list_header input").keyup(function(){
			s_filter_values(this, false);
		});
		
	}
	
	s_s_rest_of_elements_hover = function(b){
		if (b){
			$(".s_s_h_tr_custom .stockdio_s_exchanges_details_ul,.s_s_h_tr_custom .s_s_ul_country_exchanges").hide();
		}
		else{
			$(".s_s_h_tr_custom .stockdio_s_exchanges_details_ul,.s_s_h_tr_custom .s_s_ul_country_exchanges").show();
		}
	}

	s_filter_values = function(t, forExchanges){
		var v = t.value? t.value.trim().toLowerCase():"";
			var obj = $(t);
			var list = obj.closest(".stockdio_s_details_list")
			var scrollObj = null;
			list.find(".stockdio_s_exchanges_details_ul .s_s_list_link_text").each(function(i,e) {
				if ($(e).text().toLowerCase().startsWith(v)) {
					$(e).closest("li").show();
					if (v!=="")
						scrollObj = $(e).closest("li").get(0)
						
				}
				else {
					$(e).closest("li").hide();
				}
			});
			if (scrollObj) scrollObj.scrollIntoView({block:'center'});
	}
	s_s_search_exchange_info= function(exchName, catName){
		if (!exchName){
			return { country:"us", exchName:"NYSE-Nasdaq-NYSE MKT", exch:"NYSENASDAQ", countryName:"United States"}
		}
		
		for (var i=0; i<js_stockdio_popular_array.length;i++){
			item = {}
			item["isGroup"] = js_stockdio_popular_array[i][4];
			item["dExch"] = js_stockdio_popular_array[i][1];
			item["country"] = js_stockdio_popular_array[i][5];
			item["dExchName"] = js_stockdio_popular_array[i][6];
			item["countryName"] = js_stockdio_popular_array[i][8]			
			if (!item["dExch"]) continue;
			if (exchName.toLowerCase().trim() === item["dExch"].toLowerCase().trim() && 
				(!catName || catName === js_stockdio_popular_array[i][7])){
				var country = item["country"];
				var countryName = item["countryName"];
				if (item["dExch"] === "NYSENASDAQ") {
					country = "us";
					countryName  = "United States"
				}
				return { country, exchName:item["dExchName"], exch:item["dExch"], countryName}
			}
		}
		if (exchName.toLowerCase() === "commodities") {
			return { country:"", exchName:"Commodities", exch:"COMMODITIES"}
		}
		else {
			return { country:"us", exchName:"NYSE-Nasdaq-NYSE MKT", exch:"NYSENASDAQ", countryName:"United States"}
		}
	}

	stockdio_open_exchanges_details = function(e){
		
		$(".stockdio_s_details_list").hide();
		var parent = $(e).closest(".s_s_small_tile");
		var isMainExchange = false;
		if (parent.length <= 0){
			parent = $(e).closest("td");	
			isMainExchange = true;
		}

		var list = parent.find(".stockdio_s_details_list");
		if (list.css("display") === "none"){
			list.show();
		}
		else
			list.hide();

		//if (isMainExchange)
		//	return;

		//var keyCountry = parent.find(".stockdio_s_exchanges_details_button").data("keyCountry");
		var exchange = parent.find(".stockdio_s_exchanges_details_button").data("exchange");
		var catName =parent.find(".s_s_tile_title").text().trim();
		var exchangeInfo = s_s_search_exchange_info(exchange, catName);
		var keyCountry = exchangeInfo.countryName

		parent.find(".stockdio_s_exchanges_details_ul li").removeClass("s_s_list_link_text");
		if (keyCountry){
			parent.find(".stockdio_s_exchanges_details_ul .s_s_list_link_text").each(function(i,el){
				var liTextObj = $(el);
				if (liTextObj.text() === keyCountry){
					//liTextObj.closest("a").click();
					stockdio_onclick_popular_li_country(liTextObj.closest("a")[0], true, true)
					//$(".s_s_details_list_inner").scrollTo(liTextObj);
					liTextObj.get(0).scrollIntoView({block:'center'});
					return;
				}

			})
		}


	}

	s_s_show_exchanges= function(){
		
	}

	stockdio_hide_exchanges_details = function(){
		$(".stockdio_s_details_list").hide();
	}
	stockdio_onclick_popular_li_country = function(e,isHover,init){
		var obj = $(e);		
		var isMainExchange = false
		var parent = obj.closest(".s_s_small_tile");
		if (parent.length <= 0){
			parent = $(e).closest("td");	
			isMainExchange = true;
		}		
		if(!isHover || init) {
			var li = obj.closest("li");
			parent.find(".stockdio_s_exchanges_details_ul li").removeClass("s_selected");
			li.addClass("s_selected");
			if (js_exchange_modal){
				li.get(0).scrollIntoView({block:'center'});
			}			
		}
		
		var ul = parent.find(".s_s_ul_country_exchanges")		
		ul.html("");
		var items = obj.closest("li").data("items")
		//console.log("items for " + key, items)
		var curentExchange = parent.find(".stockdio_s_exchanges_details_button").data("exchange");
		for(var i = 0; i< items.length; i++){
			ul.append(`<li ${curentExchange===items[i].dExch?"class='s_selected'":""}><a onclick="stockdio_onclick_popular_li(this,'${items[i].symbols}','${items[i].dExch}','${items[i].country}','${items[i].dExchName}','${items[i].countryName}')">						
			<span class="s_s_list_link_text">${items[i].dExchName}</span><span class="fa fa-check check-mark"></span></a></li>`)		
		}
		if (!isHover){
			ul.find("li").first().find("a").click();
		}

	}
	stockdio_onclick_popular_li = function(e,symbols, exchange, country, exchName, countryName){
		var parent = $(e).closest(".s_s_small_tile");
		var isMainExchange = false
		if (parent.length <= 0){
			parent = $(e).closest("td");	
			isMainExchange = true;
		}	
		
		parent.find(".stockdio_s_exchanges_details_button").data("exchange",exchange);
		parent.find(".stockdio_s_exchanges_details_button").data("symbols",symbols);

		var li = $(e).closest("li");
		if (!js_exchange_modal)
			parent.find(".stockdio_s_exchanges_details_ul li").removeClass("s_selected");
		parent.find(".s_s_ul_country_exchanges li").removeClass("s_selected");
		
		li.addClass("s_selected");

		//parent.find(".stockdio_s_exchanges_details_button").data("keyCountry",countryName);
		if (js_exchange_modal) return;

		if (country)
			parent.find(".stockdio_s_exchanges_details_button").html(`
				<span class="stockdio_s_pull_left"><i class="stockdio_flag_icon stockdio_icon_mini" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/${country}.svg)"></i>
				${exchName}</span>		
				`)
		else{
			parent.find(".stockdio_s_exchanges_details_button").html(`
			<i class="s_s_i_separator"></i><span class="stockdio_s_pull_left">
			${exchName}</span>		
			`)		
		}
		
		stockdio_hide_exchanges_details();
	}
	s_s_onchange_select_popular = function(e){
		$(".stockdio_search_loading").show();
		var obj = $(e);
		var parent = obj.closest(".s_s_small_tile");		
		var exchange, symbols;
		var exchange = parent.find(".stockdio_s_exchanges_details_button").data("exchange");
		var symbols = parent.find(".stockdio_s_exchanges_details_button").data("symbols");

		var modal = $(".stockdio_modal_body");
		var matchingValue = s_s_get_matching_value(exchange);  
		s_s_set_exchange_value(matchingValue);
		modal.find(".stockdio_search_input_text").val(symbols);
		
		stockdio_processSymbolsString(true, false);	
	}

	stockdio_get_popular_array = function(){
		$.ajax({
			url: `https://api.stockdio.com/freedata/financial/info/v1/getpopulartickers`,
			success: function (data, textStatus, xhr) {	
				if (data.status && data.status.code == 0){
					js_stockdio_popular_array = data.data.tickers.values	
					var modal = $(".stockdio_modal_body");
					stockdio_fill_popular_elemets(modal);
					s_s_init();				
				}			
			},
			error: function (xhr, status, error) { console.log(xhr, status, error); }
		});
	}
	
	stockdio_on_change_customname = function(e, symbol, exchange){
		//fix string
		console.log("stockdio_on_change_customname", symbol, exchange, e)
		stockdio_fix_string_from_elements();
	}
	stockdio_search_delete_element = function(e){
		//delete element and fix string
		$(e).closest(".stockdio_search_list_element").remove();
		stockdio_fix_string_from_elements();
		stockdio_processSymbolsString(false,false);
	}
	stockdio_fix_string_from_elements = function(){
		var modal = $(".stockdio_modal_body");
		var dExchange =s_s_get_echange_value();
		if (dExchange) dExchange=dExchange.toLowerCase();
		var s=""
		modal.find(".stockdio_search_elements_list .stockdio_search_list_element").each(function(i,e){
			if(s!="") s+=";";
			var div = $(e);
			div.find(".stockdio_search_element_index").text(i+1);
			var exchange = div.find(".stockdio_search_element_exchange").text(); 
			var symbol = div.find(".stockdio_search_element_symbol").text();
			var custom = div.find(".stockdio_search_element_custom_name").val();
			var real = div.find(".stockdio_search_element_custom_name").data("real");
			if (custom && custom.trim()!==real.trim()) 
				custom = `(${custom})`;
			else
				custom = '';
			if (dExchange == exchange.toLowerCase() || !exchange || exchange === "Index" ||exchange === "INDEX" || exchange ==="null" || exchange ==="?" || js_is_market_overview)
				s += `${symbol}${custom}`
			else
				s += `${exchange}:${symbol}${custom}`

		})
		$(".stockdio_modal_body .stockdio_search_input_text").val(s);
		
		if (s && s.trim()!==""){
			$(".stockdio_search_customsearch_p").css('visibility','visible');
		}
		else{
			$(".stockdio_search_customsearch_p").css('visibility','hidden');
		}
		
	}
	
	s_s_symbol_edit_onclick= function(e){
		
		var parent = $(e).closest(".stockdio_search_list_element");
		parent.find(".stockdio_search_element_custom_name").show();		
		parent.find(".s_s_apply_parent").css("display","inline-block")
		parent.find(".w3-rest .s_s_s_name, .s_s_edit_i").hide();
	}
	s_s_symbol_apply_onclick= function(e, a){		
		if (e) e.preventDefault();
		var parent = $(a).closest(".stockdio_search_list_element");
		var t =parent.find(".stockdio_search_element_custom_name").val()
		var actual = parent.find(".stockdio_search_element_custom_name").text()
		var real = parent.find(".stockdio_search_element_custom_name").data("real")
		if ((t && t.trim()))
			parent.find(".s_s_s_name").text(t)
		if (!t &&  actual !== real)			
			parent.find(".s_s_s_name").text(real)
		parent.find(".stockdio_search_element_custom_name").hide();
		parent.find(".w3-rest .s_s_s_name, .s_s_edit_i").show();
		parent.find(".s_s_apply_parent").css("display","none")
	}

	stockdio_processSymbolsString = function(hidePopular,scrollToBottom, validate){
		var modal = $(".stockdio_modal_body");
		var exchange =s_s_get_echange_value();
		var symbols = encodeURIComponent(modal.find(".stockdio_search_input_text").val());//AAPL;LSE:VOD;MSFT;GOOG;COMMODITIES:GC(Oro);^SPX
		if (js_is_market_overview){
			exchange = js_filter_param;
		}
		if (!symbols){
			$(".stockdio_search_loading").hide();
			modal.find(".stockdio_search_elements_list").html("");
			$(".stockdio_search_inputs span.s_error").css("color","black");
			$(".stockdio_search_inputs span.s_error").text(`Please enter a symbol`);
			$(".s_s_edit_symbols_div").hide();
			stockdio_fix_string_from_elements();
			$(".stockdio_search_loading").hide();
			return;
		}
		$.ajax({
			url: `https://api.stockdio.com/freedata/financial/info/v1/validateSymbols/?exchange=${exchange}&symbols=${symbols}`,
			success: function (data, textStatus, xhr) {				
				$(".stockdio_search_loading").hide();
				//console.log("stockdio_processSymbolsString data:",data);
				if (data.status.code == 0){
					var array = data.data.Symbols.values
					var newDefaultExchange = array[0][2]

					if (!validate) {
						var matchingValue = s_s_get_matching_value(newDefaultExchange);    
						if(!js_is_market_overview) 	s_s_set_exchange_value(matchingValue);

						if(js_is_market_overview) matchingValue = $(js_default_exchange_id).val();

						var url = js_url.replace("%exchange%",matchingValue).replace("%appkey%",s_s_get_app_key())

						if (js_filter_param){
							url = url.replace('%filter%', `&includeExchanges=${js_filter_param}`)
							url = url.replace('&includeExchangeValue=true', ``)
							url = url.replace('&includeExchange=true', ``)
						}
						if ($("#stockdio_iframe").attr("src") !== url)
							$("#stockdio_iframe").attr("src",url);
					}

					var symbol, exchange, customName, realName, countryCode, flagHtml;
					var elements  = modal.find(".stockdio_search_elements_list");
					elements.html("");
					var errorsSymbols = []; var isError; var eCount = 0; var sEditInput
					for( var i=1; i< array.length; i++){
						isError = false
						symbol = array[i][0]
						realName = array[i][1]
						exchange = array[i][2]
						customName = array[i][3]
						countryCode = array[i][4]
						if (!customName || customName ==null || customName ==="null")
							customName="";
						
						if ((!exchange || exchange ==null || exchange ==="null") && symbol && symbol[0] ==='^'){
							exchange = "INDEX";
						}
						if (!realName || realName === "null"){
							isError = true;
							realName = "Symbol was not Found";
						}
						if (exchange ==="null" || exchange ==null ){
							isError = true;
							exchange = "?"
							errorsSymbols.push(symbol)
						}

						if (isError){ 
							sEditInput="";
							eCount++;
						}
						else{
							sEditInput=`<i title="Change Display Name" class="s_s_edit_i" onclick="s_s_symbol_edit_onclick(this)" style="background-image: url(https://services.stockdio.com/assets/images/EditIcon.svg)"></i>`;
						}
						flagHtml = "";
						if (countryCode){
							flagHtml = `<span class="stockdio_flag_icon" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/${countryCode}.svg)"></span>`
						}
						else{
							flagHtml = '<span class="stockdio_flag_icon"></span>';
						}
						elements.append(`<div class="stockdio_search_list_element w3-row">	
						<span class="stockdio_search_element_index">${i}</span>
						<div class="stockdio_search_list_element_inner"	>
							<div class="w3-col s_s_firstscols">
								<span class="s_s_drag">
									<i style="background-image: url(https://services.stockdio.com/assets/images/DragLines.svg)"></i>
								</span>
								<span class="s_s_line_sep s_s_first">
									<svg width="1" height="30" viewBox="0 0 1 30" fill="none" xmlns="http://www.w3.org/2000/svg">
										<line x1="0.5" y1="2.18557e-08" x2="0.499998" y2="30" stroke="#28292D"/>
									</svg>
								</span>
								
								${flagHtml}						
								<span class="stockdio_search_element_exchange" style="${isError?'color:#EA0020':''}">${exchange}</span>
								<span class="s_s_line_sep">
									<svg width="1" height="30" viewBox="0 0 1 30" fill="none" xmlns="http://www.w3.org/2000/svg">
										<line x1="0.5" y1="2.18557e-08" x2="0.499998" y2="30" stroke="#28292D"/>
									</svg>
								</span>						
								<span class="stockdio_search_element_symbol" style="${isError?'color:#EA0020':''}">${symbol}</span>	
								<span class="s_s_line_sep">
									<svg width="1" height="30" viewBox="0 0 1 30" fill="none" xmlns="http://www.w3.org/2000/svg">
										<line x1="0.5" y1="2.18557e-08" x2="0.499998" y2="30" stroke="#28292D"/>
									</svg>
								</span>	
							</div>				
							<div class="w3-col w3-right s_s_rightcol">
								<div>								
									<i onclick="stockdio_search_delete_element(this)" class="stockdio_search_list_element_delete_i"  style="background-image: url(https://services.stockdio.com/assets/images/WizardDelete.svg)"></i>
								</div>
							</div>
							<div class="w3-rest">
								<span class="s_s_s_name" style="${isError?'color:#EA0020':''}" >${customName?customName:realName}</span>							
								<input data-real="${realName}" type="text" class="stockdio_search_element_custom_name" value="${customName || realName}" onchange="stockdio_on_change_customname(this,'${symbol}', '${exchange}')"></input>
								${sEditInput}
								<div class="s_s_apply_parent"><a class="s_s_apply_a" onclick="s_s_symbol_apply_onclick(event, this)">OK</a></div>							
							</div>
						</div>
						
						</div>`);
					}
					modal.find('.stockdio_search_element_custom_name, .stockdio_search_input_text').keypress(function(event) {
						if (event.keyCode == 13) {
							event.preventDefault();
						}
					});
					//sortable(".stockdio_search_elements_list");
					if (!validate) {
						stockdio_fix_string_from_elements();
					}

					var el = document.getElementById('stockdio_search_elements_list');
					new Sortable(el, {
						handle:'.s_s_firstscols,.s_s_s_name',
						//draggable: ".stockdio_search_list_element",
						ghostClass: "sortable-ghost",
						onUpdate: function (evt){
							stockdio_fix_string_from_elements();
						}
					});
					
					if (hidePopular) stockdio_hide_popular(true);
					if (scrollToBottom){
						$(".stockdio_search_elements_list").each( function() {
							var scrollHeight = Math.max(this.scrollHeight, this.clientHeight);
							this.scrollTop = scrollHeight - this.clientHeight;
							});
					}
					if (validate){
						if (errorsSymbols.length>0){
							////if (errors!="") errors+=", ";
							//errors += symbol;
							var errors = "";
							for(var i=0; i< errorsSymbols.length; i++){
								if (errors!="") { 
									if (i == errorsSymbols.length-1)
										errors+=" and ";
									else
										errors+=", ";
								}
								errors += errorsSymbols[i];
							}
							$(".stockdio_search_inputs span.s_error").css("color","red");
							//var sTextError = "The following symbols are not valid for the exchange you have selected:";
							var sTextError = "";
							if (eCount>=10)
								sTextError="There are several symbols not valid for the exchange you have selected.";
							else{
								if (eCount>1)
									sTextError+=`${errors} are not valid symbols.`
								else
									sTextError+=`${errors} is not a valid symbol.`
							}

							sTextError += " Review the Stock Exchange and/or symbols you have entered.";
							$(".stockdio_search_inputs span.s_error").text(sTextError);
						}
						else{
							$(".stockdio_search_inputs span.s_error").css("color","black");
							$(".stockdio_search_inputs span.s_error").text(`No errors found`)
						}
						$(".s_s_edit_symbols_div").show();
						$(".stockdio_search_loading").hide();
					}
				}
				else{
					//display an error
					$(".stockdio_search_loading").hide();
				}
			},
			error: function (xhr, status, error) { $(".stockdio_search_loading").hide();console.log(xhr, status, error); }
		});
	}
	stockdio_search_onclose= function(){
		var v = $(".stockdio_search_modal").parent().parent();
		if (v.length>0)
			v.remove();
	}

	
	stockdio_search_onclose_and_save = function(){
		var modal = $(".stockdio_modal_body");
		var exchange =s_s_get_echange_value();
		var exchangeName =s_s_get_exchange_text();
		if (js_exchange_modal) {
			exchange = $(".stockdio_s_exchanges_details_button").data("exchange") 
		}
		var symbols = modal.find(".stockdio_search_input_text").val();//AAPL;LSE:VOD;MSFT;GOOG;COMMODITIES:GC(Oro);^SPX
		if (!exchange) return;
		var mValue = $( js_default_exchange_id +  ' option').filter(function () { 
			return this.value.toLowerCase() === exchange.toLowerCase(); 
		} ).attr('value');  		
		var exchName = $(js_default_exchange_id + " option:selected").text();

		if (!mValue){
			mValue = exchange;
			exchName = exchangeName
		}

		if (js_exchange_modal) {
			$(js_default_exchange_id).val(mValue);
			if (!js_from_blocks){
				$('#default_exchange_label').text(`${exchName} (Exchange Code: ${mValue})`);
				$(".stockdio_modal_body .stockdio_close_modal").click();
				$("#submit").click();
			}
			else{
				$('.s_b_exch_name').text(exchName);
				$('.s_b_exch_code').text(mValue);
				js_setAttributes( { exchange: mValue} );
				$(".stockdio_modal_body .stockdio_close_modal").click();				
			}
		}
		else{
			if (!js_from_blocks){
				if (!js_current_type){
					$(js_default_exchange_id).val(mValue);
					$(js_default_symbol_id).val(symbols);
					$('#default_exchange_label').text(mValue);
					$('#default_symbols_label').text(symbols);
				}
				else{
					$('#default_' + js_current_type + '_label').text(symbols);
					$('#default_' + js_current_type).val(symbols);
				}
				$(".stockdio_modal_body .stockdio_close_modal").click();
				$("#submit").click();
			}
			else{
				//$(js_default_exchange_id).trigger('change');
				//$(js_default_symbol_id).trigger('change');			
				if (!js_current_type){
					$(js_default_exchange_id).val(mValue);
					$(js_default_symbol_id).val(symbols);
					$('.s_b_exch_name').text(exchName);
					$('.s_b_exch_code').text(mValue);
					js_setAttributes( { exchange: mValue} );
					$('.default_symbols_p').text(symbols);	
					js_setAttributes( { symbol: symbols} );								
					js_setAttributes( { symbols: symbols} );			
				}
				else{
					var o = {};
					o[js_current_type] = symbols
					js_setAttributes(o);	
				}
				
				$(".stockdio_modal_body .stockdio_close_modal").click();
			}
		}
		
		
	}

	stockdio_create_search_modal = function(headerTitle, parentClass){
		return `
			<div tabindex="-1">
				<div class="components-modal__screen-overlay">
					<div class="components-modal__frame stockdio_search_modal ${parentClass}" role="dialog" aria-labelledby="components-modal-header-search" tabindex="-1">
						<div class="components-modal__content stockdio_modal_body" tabindex="0" role="document">
						   <div class="components-modal__header">
								<div class="components-modal__header-heading-container">
									<h1 id="components-modal-header-search" class="components-modal__header-heading s_s_modal_header_h1">${headerTitle}</h1>
								</div>								 
								<button type="button" class="components-button has-icon stockdio_close_modal" aria-label="Close dialogue" onclick="stockdio_search_onclose()"><svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="-2 -2 24 24" role="img" aria-hidden="true" focusable="false"><path d="M14.95 6.46L11.41 10l3.54 3.54-1.41 1.41L10 11.42l-3.53 3.53-1.42-1.42L8.58 10 5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z"></path></svg></button>						
						   </div>
						</div>
					</div>
				</div>
			</div>
		`;
	}
	
	stockdio_processSelection = function(exchange,symbol){
		var modal = $(".stockdio_modal_body");
		var dExchange = s_s_get_echange_value();
		var stringToAdd = modal.find(".stockdio_search_input_text").val();
		var isEmpty = stringToAdd.trim().length <= 0;
		if (stringToAdd.trim().length > 0)
			stringToAdd +=  ";";
		if ((dExchange && (dExchange.toLowerCase() == exchange.toLowerCase() )) || exchange ==='{exchangevalue}')
			stringToAdd = js_is_single_symbol? `${symbol}`: `${stringToAdd}${symbol}`;
		else
			stringToAdd = js_is_single_symbol? `${exchange}:${symbol}`: `${stringToAdd}${exchange}:${symbol}`;
		modal.find(".stockdio_search_input_text").val(stringToAdd);
		stockdio_processSymbolsString(false,true);
	}


	var js_screen_open="";
	var js_back_screen="";
	var js_old_intut_text="";
	var js_old_exchange="";
	var js_old_exchange_edit="";	
	var js_old_intut_text_edit="";	
	
	s_s_back_onclose=function(){
		if (js_back_screen!=="" && js_screen_open===""){
			switch(js_back_screen){
				case "popular":
					stockdio_onclick_div_popular(true);
					break;
				case "symbols":
					stockdio_onclick_div_own_symbols(true);
					break;
				case "custom":
					stockdio_onclick_bottom_section(null,true);
					break;											
			}
		}
		else{
			//edit_symbols
			switch(js_screen_open){
				case "popular":
					stockdio_hide_popular(false);
					break;
				case "symbols":
					stockdio_hide_symbols(false)
					break;
				case "custom":
					stockdio_hide_bottom(false)
					break;						
				case "edit_symbols":
					s_s_edit_symbols_back()
					break;														
			}			
		}
	}
	s_check_old_string  = function(fromEdit){
		var symbols =  $(".stockdio_search_input_text").val()
		var exchange =  s_s_get_echange_value()
		if (fromEdit){
			if (symbols!==js_old_intut_text_edit || exchange != js_old_exchange_edit){
				$(".stockdio_search_input_text").val(js_old_intut_text_edit)
				s_s_set_exchange_value(js_old_exchange)			
				stockdio_processSymbolsString(false,false, true);
			}	
		}
		else{
			if (symbols!==js_old_intut_text || exchange != js_old_exchange){
				$(".stockdio_search_input_text").val(js_old_intut_text)
				s_s_set_exchange_value(js_old_exchange)			
				stockdio_processSymbolsString(false,false);
			}	
		}	
	}


	stockdio_hide_popular=function(fromContinue){
		js_back_screen = "popular"
		$(".s_s_h_tr_popular").hide();		
		s_hide_common(fromContinue);
	}
	stockdio_hide_symbols=function(fromContinue){
		js_back_screen = "symbols"		
		$(".s_s_p_choose, .s_s_back").hide();				
		s_hide_common(fromContinue);
	}

	stockdio_hide_bottom=function(fromContinue){		
		js_back_screen = "custom"		
		$(".s_s_h_tr_custom").hide();
		$(".s_s_h").show();	
		s_hide_common(fromContinue);
	}
	s_hide_common = function(fromContinue){
		js_screen_open = ""
		s_s_small_list()
		if (!$(".s_s_i_ok").hasClass("s_s_pull_right")){
			$(".s_s_i_ok").addClass("s_s_pull_right")
		}
		
		if(fromContinue){
			$(".stockdio_search_loading").hide();
			$(".s_s_h_tr_bottom").hide();
			$(".s_s_back").show();			
			s_s_big_list()
			$(".s_s_i_ok").removeClass("s_s_pull_right")
		}
		else{
			s_check_old_string();
			$(".s_s_h_tr_bottom").show();
			$(".s_s_back").hide();
		}
		$(".s_s_i_ok").css("display","inline-block")
		$(".s_s_h_tr_options").show();
		$("#stockdio_iframe").removeClass("s_s_stockdio_iframe_2")
		var symbols = $(".stockdio_search_input_text").val();	
		if (symbols && symbols.trim()!=="") {
			$(".s_s_h_tr_own_symbols,.s_s_i_ok").show();
			$(".s_s_i_forward, .s_s_choose_tile, .s_s_p_choose").hide();
			if (!$(".stockdio_search_popular_div").hasClass("s_s_long_tile")){
				$(".stockdio_search_popular_div").addClass("s_s_long_tile");									
			}
		}
		else{						
			$(".s_s_h_tr_own_symbols, .s_s_h_tr_bottom_back").hide();
			if (js_is_market_overview)
				$(".s_s_h_tr_own_symbols").show();
			$(".s_s_h_tr_options, .s_s_p_choose, .s_s_choose_tile").show();
			$(".stockdio_search_popular_div").removeClass("s_s_long_tile");	
		}
		if(fromContinue){
			$(".s_s_h_tr_options").hide();
			//s_s_elements_big_height
		}
		stockdio_hide_exchanges_details();
		
	}
	stockdio_onclick_bottom_section=function(e, fromBack){
		s_s_big_list()
		if (e) e.preventDefault();
		//set current exchagne:
		var currentExchange = s_s_get_echange_value();
		if (currentExchange !==""){
			var exchangeInfo = s_s_search_exchange_info(currentExchange);
			var butonObj = $(".s_s_h_tr_custom .stockdio_s_exchanges_details_button")
			butonObj.html(`<span class="stockdio_s_pull_left"><i class="stockdio_flag_icon stockdio_icon_mini" style="background-image: url(https://services.stockdio.com/assets/flags/4x3/${exchangeInfo.country}.svg)"></i>
			${exchangeInfo.exchName}</span>`)		
		}
		js_screen_open = "custom"
		if (!fromBack){
			js_old_intut_text = $(".stockdio_search_input_text").val()
			js_old_exchange=s_s_get_echange_value();
		}
		$(".s_s_h_tr_options, .s_s_h_tr_bottom, .s_s_i_forward").hide();
		$(".s_s_h_tr_custom, .s_s_h_tr_bottom_back, .s_s_i_ok, .s_s_back").show();	
		$(".s_s_h_tr_own_symbols").hide();	
		$(".s_s_edit_symbols_div").hide();
		$(".stockdio_search_inputs span.s_error").text("");
		$("#stockdio_iframe").removeClass("s_s_stockdio_iframe_2")
		$(".s_s_i_ok").removeClass("s_s_pull_right")
	}

	stockdio_onclick_div_popular = function(fromBack){
		s_s_big_list();
		js_screen_open = "popular"
		if (!fromBack){
			js_old_intut_text = $(".stockdio_search_input_text").val()
			js_old_exchange=s_s_get_echange_value();
		}
		$(".s_s_h_tr_options, .s_s_h_tr_bottom, .s_s_i_ok, .s_s_p_choose").hide();
		$(".s_s_h_tr_popular, .s_s_h_tr_bottom_back, .s_s_i_forward, .s_s_back").show();
		$(".s_s_h_tr_own_symbols").hide();
	}
	stockdio_onclick_div_own_symbols=function(fromBack){
		s_s_big_list()
		js_screen_open = "symbols"
		if (!fromBack){
			js_old_intut_text = $(".stockdio_search_input_text").val()
			js_old_exchange=s_s_get_echange_value();
		}
		$(".s_s_h_tr_options, .s_s_h_tr_bottom, .s_s_i_forward").hide();
		$(".s_s_h_tr_own_symbols, .s_s_h_tr_bottom_back, .s_s_i_ok, .s_s_back").show();
		$(".s_s_i_ok").removeClass("s_s_pull_right")
	}

	s_s_small_list = function(){
		if (!$(".stockdio_search_elements_list").hasClass("s_s_elements_small_height"))
			$(".stockdio_search_elements_list").addClass("s_s_elements_small_height");
	}
	s_s_big_list = function(){
		$(".stockdio_search_elements_list").removeClass("s_s_elements_small_height");
	}

	s_s_validate_symbols_click= function(e){
		if (e) e.preventDefault();
		stockdio_processSymbolsString(false,false, true)		
	}
	s_s_edit_symbols_back= function(){
		js_screen_open = "custom"
		s_check_old_string(true);
		$(".s_s_h_tr_own_symbols").hide();
		$(".s_s_h_tr_custom").show();	
	}
	s_s_edit_symbols_click= function(e){
		js_screen_open = "edit_symbols"		
		js_old_intut_text_edit = $(".stockdio_search_input_text").val()
		js_old_exchange_edit=s_s_get_echange_value();
		
		if (e) e.preventDefault();
		$(".s_s_h_tr_own_symbols").show();
		$(".s_s_h, .s_s_h_tr_custom").hide();		
		if (!$("#stockdio_iframe").hasClass("s_s_stockdio_iframe_2"))
			$("#stockdio_iframe").addClass("s_s_stockdio_iframe_2")
	}
	s_s_get_echange_value= function(){
		//return $(".stockdio_search_exchange_select").val();
		var v = $(".s_s_new_search_exchange .stockdio_s_exchanges_details_button").data("exchange") 
		return v;
	}

	s_s_get_exchange_text=function(){
		//return $(".stockdio_search_exchange_select").val();
		var v = $(".s_s_new_search_exchange .stockdio_s_exchanges_details_button").text().trim();
		return v;
	}

	s_s_set_exchange_value= function(v){
		//$(".stockdio_search_exchange_select").val(v);
		$(".s_s_new_search_exchange .stockdio_s_exchanges_details_button").data("exchange",v);
	}
	s_s_get_matching_value=function(exchange){
		/*
		return $('.stockdio_search_exchange_select option').filter(function () { 
			return this.value.toLowerCase() === exchange.toLowerCase(); 
		} ).attr('value');  
		*/
		return exchange;
	}
	s_s_exchange_onchange=function(){
		s_s_validate_symbols_click()
	}

	s_s_get_app_key=function(){
		if (typeof stockdio_economic_news_board_settings !== 'undefined') return stockdio_economic_news_board_settings.api_key;
		if (typeof stockdio_ticker_settings !== 'undefined' ) return stockdio_ticker_settings.api_key;		
		if (typeof stockdio_news_board_settings !== 'undefined') return stockdio_news_board_settings.api_key;
		if (typeof stockdio_market_overview_settings !== 'undefined') return stockdio_market_overview_settings.api_key;
		if (typeof stockdio_quotes_board_settings !== 'undefined') return stockdio_quotes_board_settings.api_key;
		if (typeof stockdio_historical_charts_settings !== 'undefined') return stockdio_historical_charts_settings.api_key;
		if (typeof optionsObj !== 'undefined') return  optionsObj.appKey;
		return "";
		
	}

	var js_url = `https://api.stockdio.com/visualization/financial/charts/v1/SymbolSearch?app-key=%appkey%&palette=financial-light&limit=8&height=60&width=100%&linkUrl=javascript:stockdio_processSelection(%22{exchangevalue}%22,%22{symbol}%22)&linkTarget=self&template=c117d249-212c-45ed-878b-1df46897ad54&OnLoad=stockdio_iframe&transparent=true&includeExchangeValue=true&stockExchange=%exchange%%filter%`;
//<button type="button" aria-expanded="false" aria-label="Close dialogue" class="components-button is-link" onclick="stockdio_search_onclose_and_save()">Apply Changes and Close</button>
	stockdio_get_modal_body = function(exch){
		var url = js_url.replace("%exchange%",exch).replace("%appkey%",s_s_get_app_key())
		if (js_filter_param){
			url = url.replace('%filter%', `&includeExchanges=${js_filter_param}`)
			url = url.replace('&includeExchangeValue=true', ``)
			url = url.replace('&includeExchange=true', ``)
		}
		return `
			<div class="stockdio_search_modal_body">
			<table class="stockdio_search_table"> 
				<tr class="s_s_h_tr_popular"> 
					<td valign="top" >					
						<p>Select one of our pre-made common lists from one of the categories below:</p>
						<div class="s_s_div_popular_tiles"></div>
					</td>
				</tr>
				<tr class="s_s_h_tr_custom" style="display:none"> 
					<td valign="top" >					
						<div class="stockdio_search_inner_div2 ">
							<div class="stockdio_search_inner_div_inner">								
								<div class="stockdio_search_inputs">
										<p class="s_s_p_validate_text">Select your default Stock Exchange and type or paste the list of symbols, separated by semi-colon (;)</p>						
										<div class="s_s_new_search_exchange"></div>
										<input type="text" class="stockdio_search_input_text" />										
									<div class="s_s_validate_div"><a class="s_s_validate_a" onclick="s_s_validate_symbols_click(event)" href="#">Validate symbols</a></div>
									<span class="s_error"></span>
									<div class="s_s_edit_symbols_div" style="display:none"><a onclick="s_s_edit_symbols_click(event)" href="#" >Edit symbols</a></div>
								</div>
							</div>	
						</div>	
					</td>
				</tr>						
				<tr class="s_s_h_tr_own_symbols" style="display:none"> 
					<td valign="top" >					
						<div class="stockdio_search_div_section stockdio_search_symbols_div s_s_section " >
							<p class="s_s_h" >You can adjust the list below by adding elements using the search bar, deleting symbols or changing their order:</p>
							<iframe referrerpolicy="no-referrer-when-downgrade" class="stockdio-search-block" id="stockdio_iframe" frameborder="0" scrolling="no" width="100%" height="60"  src="${url}"></iframe>	
							<div class="stockdio_search_customsearch stockdio_search_inner_div">											
								<div class="stockdio_search_elements_list s_s_elements_small_height" id="stockdio_search_elements_list"></div>
								<p class="stockdio_search_customsearch_p">You can change the order of the stocks by draging them on the handle bars next to the location number</p>
								<div class="s_s_elemets_fade_top"></div>
								<div class="s_s_elemets_fade_bottom"></div>
							</div>
						</div>
					</td>
				</tr>				
					
				<tr class="s_s_h_tr_options"> 					
					<td valign="top" class="s_s_h_td2">
						<p class="s_s_p_choose">Choose the option that best suits your needs.</p>
						<div onclick="stockdio_onclick_div_popular()" class="stockdio_search_div_section stockdio_search_popular_div s_s_section stockdio_s_tile stockdio_s_tile_main">
							<div class="s_tile_div_icon"><i class="s_tile_icon" style="background-image: url(https://services.stockdio.com/assets/images/PopularTickers.svg)"></i></div>
							<div class="s_s_tile_titles">
								<span class="s_s_tile_title s_s_tile_title1">Select from our pre-made common lists</span>
								<span class="s_s_tile_title s_s_tile_title2" >Or select from our pre-made common lists</span>
								<span class="s_s_tile_subtitle s_s_easiest">(easiest and fastest)</span>
							</div>
							<div class="s_s_tile_button_continue"><span>Continue</span></div>
						</div>

						<div onclick="stockdio_onclick_div_own_symbols(this)" class="s_s_section s_s_choose_tile stockdio_s_tile stockdio_s_tile_main">
							<div><i class="s_tile_icon" style="background-image: url(https://services.stockdio.com/assets/images/ChooseOwnData.svg)"></i></div>
							<span class="s_s_tile_title">Choose your data</span>
							<span class="s_s_tile_subtitle">(select your custom data)</span>
							<div class="s_s_tile_button_continue" ><span>Continue</span></div>
						</div>


					</td>
				</tr> 		
				
								
				<tr class="s_s_h_tr_bottom" > 
					<td valign="top">
						<div class="stockdio_search_div_section stockdio_search_custom_div">	
						<p >If you already have the preferred stock exchange and the list of symbols you want, you can enter them <a onclick="stockdio_onclick_bottom_section(event)" href="#">here</a>.</p>
				</div>												
					</td> 
				</tr> 

				<tr class="s_s_h_tr_bottom_back" > 
					<td valign="bottom">		
						<div class="s_s_back_buttons">
							<div class="s_s_div_back_button s_s_back" onclick="s_s_back_onclose()">
								<i class="s_s_icon_back_buttons" style="background-image: url(https://services.stockdio.com/assets/images/WizardBack.svg)"></i>
							</div>

							<i class="s_s_icon_back_buttons s_s_i_forward" style="background-image: url(https://services.stockdio.com/assets/images/WizardForwardSelected.svg)"></i>
							<div class="s_s_div_back_button s_s_i_ok s_s_pull_right" onclick="stockdio_search_onclose_and_save()" >
								<i class="s_s_icon_back_buttons" style="background-image: url(https://services.stockdio.com/assets/images/WizardOK.svg);position:relative">
								</i>
							</div>						
						</div>
					</td>
				</tr>					
			</table> 			
			
				

				<div class="stockdio_search_loading">
					<div class="s_s_dots">
						<div class="s_s_dot s_s_dot1"></div>
						<div class="s_s_dot s_s_dot2"></div>
						<div class="s_s_dot s_s_dot3"></div>
						<div class="s_s_dot s_s_dot4"></div>
						<div class="s_s_dot s_s_dot5"></div>
					</div>
				</div>
			</div>
		`;
	}

	stockdio_get_modal_exchange_body = function(exch){
		return `
			<div class="stockdio_search_modal_body s_s_exchange_modal">
			<table class="stockdio_search_table"> 
				<tr class="s_s_h_tr_popular"> 
					<td valign="top" >					
						<p>Select the exchange:</p>
						<div class="s_s_exchange_selector_div"></div>
					</td>
				</tr>		

				<tr class="s_s_h_tr_bottom_back" > 
					<td valign="bottom">		
						<div class="s_s_back_buttons">
							<div class="s_s_div_back_button s_s_i_ok s_s_pull_right" onclick="stockdio_search_onclose_and_save()" >
								<i class="s_s_icon_back_buttons" style="background-image: url(https://services.stockdio.com/assets/images/WizardOK.svg);position:relative">
								</i>
							</div>						
						</div>
					</td>
				</tr>					
			</table> 			
			
				

				<div class="stockdio_search_loading">
					<div class="s_s_dots">
						<div class="s_s_dot s_s_dot1"></div>
						<div class="s_s_dot s_s_dot2"></div>
						<div class="s_s_dot s_s_dot3"></div>
						<div class="s_s_dot s_s_dot4"></div>
						<div class="s_s_dot s_s_dot5"></div>
					</div>
				</div>
			</div>
		`;
	}


} ());
