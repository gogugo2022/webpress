<?php

/**
 * Template part for displaying single post content
 *
 *
 * @package Meta Store
 */
do_action('meta_store_blog_post_single');
