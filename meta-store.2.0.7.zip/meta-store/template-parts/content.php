<?php

/**
 * Template part for displaying posts
 *
 *
 * @package Meta Store
 */
do_action('meta_store_blog_post');
