<?php
/**
 * The template for displaying the footer
 *
 * @package Meta Store
 */
?>
<?php do_action('meta_store_container_end'); ?>
</div>

<?php do_action('meta_store_footer'); ?>

</div>

<?php wp_footer(); ?>

</body>
</html>
