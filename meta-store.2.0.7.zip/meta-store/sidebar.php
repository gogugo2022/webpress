<?php

/**
 * The sidebar containing the main widget area
 *
 * @package Meta Store
 */
do_action('meta_store_display_sidebar');
