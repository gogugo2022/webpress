<?php
/**
 * @package curtains
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="entry-content">
	<div class="post-thumb blog-thumb">
			<?php 
			$featured_image = get_theme_mod( 'featured_image',true );
		    if( $featured_image ) : ?>
				<div class="post-thumb blog-thumb">
				  <?php
					if( function_exists( 'curtains_featured_image' ) ) :
						curtains_featured_image();
			        endif;
				  ?>
			    </div><?php 
			endif; ?> 
			<span class="date-structure posted-on top-date">				
				<span class="dd"><?php the_time('j'); ?></span>
				<span class="mm"><?php the_time('M'); ?></span>
			 </span>
	</div>

	<?php do_action('curtains_before_entry_header'); ?>
		
	<div class="entry-body">
	    <h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1> 
		       <?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('curtains_entry_top_meta') ) {
						    curtains_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer -->
				<?php endif;?>  
		         <?php echo the_content(); ?>
				
			<?php do_action('curtains_before_entry_footer'); ?>
			<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
					<?php if(function_exists('curtains_entry_bottom_meta') ) {
					     curtains_entry_bottom_meta();
					} ?>
				</footer><!-- .entry-footer -->
			<?php endif;?>
             <?php do_action('curtains_after_entry_footer'); ?>
	</div>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'curtains' ),
				'after'  => '</div>',
			) );
		?>
		<br class="clear" />
	</div><!-- .entry-content -->

	
</article><!-- #post-## -->