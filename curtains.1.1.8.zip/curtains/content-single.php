<?php
/**
 * @package curtains
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<div class="entry-content">    
	<div class="post-thumb blog-thumb">
		<?php
			$single_featured_image = get_theme_mod( 'single_featured_image',true );
			$single_featured_image_size = get_theme_mod ('single_featured_image_size','1');
			if( $single_featured_image && $single_featured_image_size != 3 ) : ?>
				<?php if( $single_featured_image_size == 1 ) :
					    if( has_post_thumbnail() && ! post_password_required() ) :   
							the_post_thumbnail('curtains-blog-large-width');   
						else :
							echo '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" />';	
						endif;
					else:
						if( has_post_thumbnail() && ! post_password_required() ) :   
							the_post_thumbnail('curtains-small-featured-image-width');
						else :
							echo '<img src="' . get_template_directory_uri()  . '/images/no-image-small-featured-image-width.png" />';
						endif;
						 
					endif;
				?>
				<span class="date-structure posted-on">				
					<span class="dd"><?php the_time('j'); ?></span>    
					<span class="mm"><?php the_time('M'); ?></span>
				</span>

			<?php else: ?>
				<span class="date-structure posted-on top-date">				
					<span class="dd"><?php the_time('j'); ?></span>
					<span class="mm"><?php the_time('M'); ?></span>
				</span>
			<?php endif; ?>
	</div>

	<header class="entry-header">
     <h3 class="entry-title"><?php the_title( '','' ); ?></h3>
	<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
		    <div class="entry-meta">
		    <?php if(function_exists('curtains_entry_top_meta') ) {
		         curtains_entry_top_meta();
		     } ?>
			</div><!-- .entry-meta -->
	<?php endif; ?>
	</header><!-- .entry-header -->

		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'curtains' ),
				'after'  => '</div>',
			) );
		?>


	<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
	<footer class="entry-footer">
	<?php if(function_exists('curtains_entry_bottom_meta') ) {
		     curtains_entry_bottom_meta();
		} ?>
	</footer><!-- .entry-footer -->
<?php endif;?>
<?php curtains_post_nav(); ?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->

