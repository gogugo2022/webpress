<?php
/**
 * @version 3.1.6
 * @var WC_Payment_Gateway_Stripe_GooglePay $gateway
 */
?>
<div id="wc-stripe-googlepay-container"></div>