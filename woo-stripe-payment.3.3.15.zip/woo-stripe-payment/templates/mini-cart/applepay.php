<?php
/**
 * @version 3.1.8
 * 
 * @var WC_Payment_Gateway_Stripe $gateway
 */
?>
<a class="wc-stripe-applepay-mini-cart button" style="display: none"></a>