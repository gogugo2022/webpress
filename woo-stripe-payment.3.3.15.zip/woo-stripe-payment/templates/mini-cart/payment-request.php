<?php
/**
 * @version 3.2.0
 */
?>
<a class="wc-stripe-payment-request-mini-cart button" style="display: none"></a>
