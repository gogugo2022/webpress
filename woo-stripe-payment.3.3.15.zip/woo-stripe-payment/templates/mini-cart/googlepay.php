<?php
/**
 * @version 3.1.8
 */
?>
<a class="wc-stripe-gpay-mini-cart button" style="display: none"></a>