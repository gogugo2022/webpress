<?php
/**
 * @version 3.0.0
 * 
 * @var WC_Payment_Gateway_Stripe $gateway
 */
?>
<div id="wc-stripe-applepay-container">
	
</div>