<?php
/**
 * @version 3.0.0
 * 
 * @var WC_Payment_Gateway_Stripe $gateway
 */
?>
<div class="wc-stripe-payment-request-container">

</div>