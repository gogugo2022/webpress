import './styles.scss';
import './payment-method'