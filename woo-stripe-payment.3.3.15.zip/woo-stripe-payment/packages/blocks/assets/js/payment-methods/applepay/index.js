import './style.scss';

import './payment-method';