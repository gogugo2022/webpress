import './style.scss';

export * from './payment-method';

import './components/bootstrap';
import './components/simple';
