<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class SofortPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_sofort';
}