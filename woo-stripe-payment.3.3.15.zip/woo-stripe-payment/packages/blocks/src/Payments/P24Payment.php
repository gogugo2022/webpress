<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class P24Payment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_p24';
}