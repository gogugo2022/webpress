<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class BECSPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_becs';
}