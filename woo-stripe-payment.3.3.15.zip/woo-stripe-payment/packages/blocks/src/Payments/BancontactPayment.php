<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class BancontactPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_bancontact';

}