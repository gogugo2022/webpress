<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class MultibancoPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_multibanco';
}