<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class GrabPayPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_grabpay';
}