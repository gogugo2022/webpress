<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class EPSPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_eps';
}