<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class IdealPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_ideal';
}