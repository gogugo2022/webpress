<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class BoletoPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_boleto';
}