<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class AlipayPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_alipay';
}