<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class GiropayPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_giropay';

}