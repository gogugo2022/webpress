<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class OXXOPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_oxxo';
}