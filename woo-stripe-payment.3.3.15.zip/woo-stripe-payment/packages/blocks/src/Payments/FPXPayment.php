<?php


namespace PaymentPlugins\Blocks\Stripe\Payments;


class FPXPayment extends AbstractStripeLocalPayment {

	protected $name = 'stripe_fpx';
}