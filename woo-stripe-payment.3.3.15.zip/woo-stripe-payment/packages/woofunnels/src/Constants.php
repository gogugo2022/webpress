<?php


namespace PaymentPlugins\WooFunnels\Stripe;


class Constants {

	const PAYMENT_INTENT_ID = '_';
}