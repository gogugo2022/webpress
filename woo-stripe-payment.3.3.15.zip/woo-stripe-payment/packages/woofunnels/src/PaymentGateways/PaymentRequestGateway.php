<?php


namespace PaymentPlugins\WooFunnels\Stripe\PaymentGateways;


class PaymentRequestGateway extends BasePaymentGateway {

	protected $key = 'stripe_payment_request';
}