<?php


namespace PaymentPlugins\WooFunnels\Stripe\PaymentGateways;


class GooglePayGateway extends BasePaymentGateway {

	protected $key = 'stripe_googlepay';
}