<?php


namespace PaymentPlugins\WooFunnels\Stripe\PaymentGateways;


class ApplePayGateway extends BasePaymentGateway {

	protected $key = 'stripe_applepay';
}