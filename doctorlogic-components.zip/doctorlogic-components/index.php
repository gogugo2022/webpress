<?php
// Ever notice that the words "silent"  and "listen"  have the same letters?
?>