<?php
function DoctorLogicReviews($atts, $instance)
{

    $ReviewPageName = get_option('dl_review_path');
    $API = get_option('dl_api');

    $label = $_GET[label];
    $personnel = $_GET[dl__personnel];
    $facility = $_GET[facility];
    $procedure = $_GET[dl__procedure];
    $rating = $_GET[dl__rating];
    $testimonialsource = $_GET[dl__source];
    $sort = $_GET[sort];


    $pageNumber = isset($_GET[pagenumber]) ? $_GET[pagenumber] : 1;
    $pageSize = isset($_GET[pagesize]) ? $_GET[pagesize] : 500;

    $apiurl = $API . "/testimonial?isPublished=true";
    //$apiurl .= "&topN=500";
    $apiurl .= "&pagenumber=" . $pageNumber;
    $apiurl .= "&pagesize=" . $pageSize;

    if ($personnel != "") {
        $apiurl .= "&personnel=" . $personnel;
    }
    if ($facility != "") {
        $apiurl .= "&facility=" . $facility;
    }
    if ($procedure != "") {
        $apiurl .= "&procedure=" . $procedure;
    }
    if ($rating != "") {
        $apiurl .= "&rating=" . $rating;
    }
    if ($testimonialsource != "") {
        $apiurl .= "&source=" . $testimonialsource;
    }

    $json = file_get_contents($apiurl);
    $json_Testimonial = json_decode($json);

    $ReviewCount = count($json_Testimonial);
    $TotalCount = $ReviewCount;
    if ($ReviewCount > 0) {
        $TotalCount = $json_Testimonial[0]->TotalCount;
    }

    $apiurl = $API . "/testimonial/filters?isPublished=true";
    $json = file_get_contents($apiurl);
    $json_filter = json_decode($json);
    ob_start();
    ?>

<div class="dl__grid" id="dl__main-grid">

    <div class="dl__col dl__col--1-of-4  dl__filter">
        <div class="dl__heading">
            Show Only:
        </div>
        <?= dl_filter_item($json_filter, 'Rating', 'dl__rating'); ?>
        <?= dl_filter_item($json_filter, 'Source', 'dl__source'); ?>
        <?= dl_filter_item($json_filter, 'Personnel', 'dl__personnel'); ?>
        <?= dl_filter_item($json_filter, 'Procedure', 'dl__procedure'); ?>
    </div>


    <div class="dl__col dl__col--3-of-4 ">
        <div class="dl__grid">
            <div class="dl__col dl__col--3-of-3 dl__heading">
                <?= $TotalCount ?>
                Review<?= ($ReviewCount == 1) ? "" : "s" ?>
                <?php
                    if ($label != "") { ?>
                -
                <?= $label ?>
                <span style="font-weight:normal; font-size:15px;"><a href="/<?= $ReviewPageName ?>">
                        <span style="white-space: nowrap;">&nbsp;(See More Reviews)</span></a></span>
                <?php
                    }
                    ?>
            </div>
        </div>
        <?php
            foreach ($json_Testimonial as $key => $value) {
                $NormalizedRating = number_format($value->NormalizedRating, 1);
                if ($NormalizedRating == "0.0") {
                    $NormalizedRating = "";
                }
                $Rating = number_format($value->Rating, 1);
                if ($Rating == "0.0") {
                    $Rating = "";
                }
                ?>

        <div class="dl__grid dl__review_result_row">
            <div class="dl__col dl__col--1-of-3">
                <?php
                        if ($Rating != "" && $Rating <= 5) {
                            ?>
                <div class="dl__rating">
                    <div class="dl__rating-number">
                        <?= $Rating ?>
                    </div>
                    <div class="dl__stars">
                        <?php
                                    $stars = "";
                                    for ($i = 0; $i < intval($Rating); $i++) {
                                        $stars .= "<span class=\"dashicons dashicons-star-filled  dl__star\"></span>";
                                    }
                                    if (intval($Rating) < $Rating) {
                                        $stars .= "<span class=\"dashicons dashicons-star-half  dl__star\"></span>";
                                    };
                                    ?>
                        <?= $stars; ?>
                    </div>
                </div>
                <?php
                        } else {
                            ?>
                <div class="dl__rating">Patient Story</div>
                <?php
                        }
                        ?>
                <img src="<?= $value->TestimonialSourceLogoPath ?>?mobilewidth=96&w=150" />
            </div>
            <div class="dl__col dl__col--2-of-3">
                <div style="font-weight:bold;">
                    <span class="dl__no-wrap">Review from <?= $value->Author ?></span> -
                    <?php
                            if ($value->Source != 1) {
                                ?>
                    <span class="dl__no-wrap">Source: <a href="<?= $value->ExternalURL ?>" target="_blank"> <?= $value->TestimonialSourceLabel ?> </a></span> -
                    <?php
                            }
                            ?>
                    <span class="dl__no-wrap"><?= date_create($value->DateReviewed)->format("M d, Y") ?></span>
                </div>
                <div>
                    <div class="dl__showhide">
                        <div><?= $value->LongDescription ?></div>
                    </div>
                    <?php

                            foreach ($value->Media as $media) {
                                ?>
                    <img class="dl__modal" name="<?= $media->MediaId ?>" href="#<?= $media->MediaId ?>" src="<?= $media->Url ?>?mobilewidth=96&w=150" />
                    <div style="display:none" id="<?= $media->MediaId ?>">
                        <img src="<?= $media->Url ?>?w=600" />
                    </div>
                    <?php
                            }
                            ?>
                </div>
            </div>
        </div>




        <?php } ?>
        <?php if ($TotalCount > $pageSize) { ?>

        <div class="dl__paging">

            <?php if ($pageNumber > 1) { ?>
            <button class="dl__paging__buttons" onclick="__dl.previousPage()">Previous Page</button>
            <?php } ?>

            <?php if (($pageNumber * $pageSize) <  $TotalCount) { ?>
            <button class="dl__paging__buttons" onclick="__dl.nextPage()">Next Page</button>
            <?php } ?>

        </div>

        <script>
            (function(window) {
                var currentPage = <?php echo $pageNumber ?>;
                var pageSize = <?php echo $pageSize ?>;

                function updateUrlParameter(param, oldValue, newValue) {
                    const newUrl = window.location.href.replace(param + "=" + oldValue, param + "=" + newValue);
                    window.history.pushState("", "", newUrl);
                }

                function addUrlParameter(param, value) {
                    let newUrl = window.location.href;
                    if (location.search.includes("?")) {
                        newUrl = newUrl + "&" + param + "=" + value;
                    } else {
                        newUrl = newUrl + "?" + param + "=" + value;
                    }
                    window.history.pushState("", "", newUrl);
                }

                function addPageSizeIfMissing() {
                    if (!location.search.includes('pagesize')) {
                        addUrlParameter('pagesize', pageSize)
                    }
                }

                function adjustPageNumber(newPageNumber) {

                    if (location.search.includes('pagenumber')) {
                        updateUrlParameter('pagenumber', currentPage, newPageNumber)
                    } else {
                        addUrlParameter('pagenumber', newPageNumber)
                    }
                }

                var dl = {
                    previousPage: function() {
                        addPageSizeIfMissing();
                        adjustPageNumber(currentPage - 1);
                        location.reload();
                    },
                    nextPage: function() {
                        addPageSizeIfMissing();
                        adjustPageNumber(currentPage + 1);
                        location.reload();
                    }
                }
                window.__dl = dl;
            })(window)
        </script>
        <?php } ?>
    </div>

</div>
<?php
    $s = dl__palette();
    $s .= ob_get_contents();
    ob_end_clean();
    return $s;
}

function dl_filter_item($json_filter, $Filter, $QS)
{
    $t = "<div class='dl__subheading'>" . $Filter . "</div>
    <ul class='dl__ul'>";
    if ($Filter == "Rating") {
        $json_filter = array_reverse($json_filter);
    }
    foreach ($json_filter as $f) {
        if ($f->Filter == $Filter) {
            $t .= "<li><a href='?label=" . $f->Label . "&" . $QS . "=" . $f->Id . "'>" .  $f->Label . "</a> (" . $f->Count . ")</li>";
        }
    }
    $t .= "</ul>";
    return $t;
}
?>